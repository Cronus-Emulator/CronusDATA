Navi_Scroll = {

	{
		"Dungeon Teleport Scroll",
		19733,
		-1,
		"mag_dun01",
		125,
		71,
		{ 10878, 376 },
		{ 10879, 376 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19734,
		-1,
		"mjo_dun02",
		80,
		297,
		{ 10515, 398 },
		{ 10516, 398 },
		{ 10518, 398 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19735,
		-1,
		"ein_dun01",
		261,
		262,
		{ 12237, 8 },
		{ 12277, 8 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19736,
		-1,
		"pay_dun03",
		155,
		150,
		{ 10466, 12 },
		{ 10467, 12 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19737,
		-1,
		"xmas_dun01",
		133,
		130,
		{ 18234, 158 },
		{ 18235, 158 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19738,
		-1,
		"gl_prison",
		140,
		15,
		{ 18163, 140 },
		{ 18164, 140 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19739,
		-1,
		"lou_dun03",
		165,
		38,
		{ 11697, 4 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19740,
		-1,
		"gon_dun02",
		251,
		263,
		{ 11517, 73 },
		{ 11532, 73 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19741,
		-1,
		"iz_dun02",
		350,
		335,
		{ 10457, 15 },
		{ 10984, 15 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19742,
		-1,
		"tur_dun02",
		165,
		30,
		{ 10955, 246 },
		{ 10956, 246 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19743,
		-1,
		"alde_dun03",
		275,
		180,
		{ 18136, 296 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19744,
		-1,
		"c_tower3",
		34,
		42,
		{ 18134, 266 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19745,
		-1,
		"gl_sew02",
		292,
		295,
		{ 18169, 865 },
		{ 18170, 865 },
		{ 18171, 865 },
		{ 18172, 865 },
		{ 18173, 865 },
		{ 18174, 865 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19746,
		-1,
		"in_sphinx4",
		120,
		120,
		{ 10485, 471 },
		{ 10486, 471 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19747,
		-1,
		"moc_pryd04",
		195,
		4,
		{ 11059, 216 },
		{ 11061, 216 },
		{ 11063, 216 },
		{ 11065, 216 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19748,
		-1,
		"prt_sewb3",
		20,
		175,
		{ 10314, 530 },
		{ 10315, 530 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19749,
		-1,
		"ama_dun01",
		222,
		144,
		{ 11421, 1298 },
		{ 11486, 1298 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19750,
		-1,
		"lhz_dun01",
		19,
		153,
		{ 12664, 309 },
		{ 12665, 309 },
		{ 12666, 309 },
		{ 12730, 309 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19751,
		-1,
		"ayo_dun02",
		70,
		240,
		{ 11980, 367 },
		{ 11981, 367 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19752,
		-1,
		"thor_v02",
		77,
		208,
		{ 13247, 307 },
		{ 13272, 307 },
		{ 13370, 307 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19753,
		-1,
		"ra_fild01",
		237,
		333,
		{ 13107, 302 },
		{ 13163, 302 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19754,
		-1,
		"ve_fild07",
		127,
		131,
		{ 13252, 376 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19755,
		-1,
		"niflheim",
		206,
		179,
		{ 11631, 188 },
		{ 11632, 188 },
		{ 11633, 188 },
		{ 11634, 188 },
		{ 11635, 188 },
		{ 11636, 188 },
		{ 11637, 188 },
		{ 11638, 188 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19756,
		-1,
		"prt_maze02",
		100,
		174,
		{ 10678, 159 },
		{ 10679, 159 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19757,
		-1,
		"jupe_cave",
		36,
		54,
		{ 12777, 8 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19758,
		-1,
		"anthell02",
		36,
		265,
		{ 10473, 7 },
		{ 19674, 7 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19759,
		-1,
		"yuno_fild08",
		70,
		171,
		{ 10130, 226 },
		{ 10891, 226 },
		{ 10892, 226 },
		{ 10893, 226 },
		{ 10894, 226 },
		{ 10895, 226 },
		{ 10896, 226 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19760,
		-1,
		"hu_fild01",
		140,
		160,
		{ 12794, 279 },
		{ 12870, 279 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19761,
		-1,
		"hu_fild05",
		168,
		302,
		{ 12796, 141 },
		{ 12872, 141 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19762,
		-1,
		"ra_temple",
		117,
		173,
		{ 13100, 8 },
		{ 13118, 8 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19763,
		-1,
		"odin_tem02",
		257,
		374,
		{ 12866, 541 },
		{ 12867, 541 },
		{ 12896, 541 },
		{ 12897, 541 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		0,
		0,
		"NULL",
		0,
		0,
	}
}