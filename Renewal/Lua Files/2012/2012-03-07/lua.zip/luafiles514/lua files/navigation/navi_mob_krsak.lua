Navi_Mob = {

	{
		"abbey01", --map
		17116,
		300,
		1036, --MobID
		"Ghoul", --MobName
		"GHOUL", --SpriteName
		61, -- MobLevel
		3211521
	},

	{
		"abbey01",
		17117,
		300,
		1865,
		"Ragged Zombie",
		"RAGGED_ZOMBIE",
		123,
		4522241
	},

	{
		"abbey01",
		17118,
		300,
		1867,
		"Banshee",
		"BANSHEE",
		130,
		3080454
	},

	{
		"abbey01",
		17119,
		300,
		1864,
		"Zombie Slaughter",
		"ZOMBIE_SLAUGHTER",
		124,
		4522241
	},

	{
		"abbey01",
		17120,
		300,
		1869,
		"Flame Skull",
		"FLAME_SKULL",
		121,
		4456454
	},

	{
		"abbey01",
		17121,
		300,
		1866,
		"Hell Poodle",
		"HELL_POODLE",
		115,
		1769478
	},

	{
		"abbey02",
		17122,
		300,
		1870,
		"Necromancer",
		"NECROMANCER",
		133,
		5832961
	},

	{
		"abbey02",
		17123,
		300,
		1865,
		"Ragged Zombie",
		"RAGGED_ZOMBIE",
		123,
		4522241
	},

	{
		"abbey02",
		17124,
		300,
		1864,
		"Zombie Slaughter",
		"ZOMBIE_SLAUGHTER",
		124,
		4522241
	},

	{
		"abbey02",
		17125,
		300,
		1869,
		"Flame Skull",
		"FLAME_SKULL",
		121,
		4456454
	},

	{
		"abbey02",
		17202,
		301,
		1871,
		"Fallen Bishop",
		"FALLINGBISHOP",
		138,
		3080454
	},

	{
		"abbey03",
		17126,
		300,
		1870,
		"Necromancer",
		"NECROMANCER",
		133,
		5832961
	},

	{
		"abbey03",
		17127,
		300,
		1867,
		"Banshee",
		"BANSHEE",
		130,
		3080454
	},

	{
		"abbey03",
		17128,
		300,
		1869,
		"Flame Skull",
		"FLAME_SKULL",
		121,
		4456454
	},

	{
		"abbey03",
		17203,
		301,
		1873,
		"Beelzebub",
		"BEELZEBUB",
		147,
		5767174
	},

	{
		"abyss_01",
		16958,
		300,
		1715,
		"Novus",
		"NOVUS",
		90,
		1310729
	},

	{
		"abyss_01",
		16959,
		300,
		1718,
		"Novus",
		"NOVUS_",
		84,
		1310729
	},

	{
		"abyss_01",
		16960,
		300,
		1721,
		"Dragon Egg",
		"DRAGON_EGG",
		119,
		2621705
	},

	{
		"abyss_01",
		16961,
		300,
		1191,
		"Mimic",
		"MIMIC",
		56,
		3932416
	},

	{
		"abyss_01",
		16962,
		300,
		1699,
		"Ancient Mimic",
		"ANCIENT_MIMIC",
		112,
		3932672
	},

	{
		"abyss_01",
		16963,
		300,
		1216,
		"Penomena",
		"PENOMENA",
		85,
		1638661
	},

	{
		"abyss_01",
		16964,
		300,
		1714,
		"Ferus",
		"FERUS",
		126,
		2818569
	},

	{
		"abyss_01",
		16965,
		300,
		1717,
		"Ferus",
		"FERUS_",
		126,
		2753033
	},

	{
		"abyss_02",
		16966,
		300,
		1715,
		"Novus",
		"NOVUS",
		90,
		1310729
	},

	{
		"abyss_02",
		16967,
		300,
		1718,
		"Novus",
		"NOVUS_",
		84,
		1310729
	},

	{
		"abyss_02",
		16968,
		300,
		1721,
		"Dragon Egg",
		"DRAGON_EGG",
		119,
		2621705
	},

	{
		"abyss_02",
		16969,
		300,
		1191,
		"Mimic",
		"MIMIC",
		56,
		3932416
	},

	{
		"abyss_02",
		16970,
		300,
		1713,
		"Acidus",
		"ACIDUS",
		130,
		3015177
	},

	{
		"abyss_02",
		16971,
		300,
		1716,
		"Acidus",
		"ACIDUS_",
		130,
		2884105
	},

	{
		"abyss_02",
		16972,
		300,
		1699,
		"Ancient Mimic",
		"ANCIENT_MIMIC",
		112,
		3932672
	},

	{
		"abyss_02",
		16973,
		300,
		1714,
		"Ferus",
		"FERUS",
		126,
		2818569
	},

	{
		"abyss_03",
		16974,
		300,
		1721,
		"Dragon Egg",
		"DRAGON_EGG",
		119,
		2621705
	},

	{
		"abyss_03",
		16975,
		300,
		1191,
		"Mimic",
		"MIMIC",
		56,
		3932416
	},

	{
		"abyss_03",
		16976,
		300,
		1713,
		"Acidus",
		"ACIDUS",
		130,
		3015177
	},

	{
		"abyss_03",
		16977,
		300,
		1716,
		"Acidus",
		"ACIDUS_",
		130,
		2884105
	},

	{
		"abyss_03",
		16978,
		300,
		1699,
		"Ancient Mimic",
		"ANCIENT_MIMIC",
		112,
		3932672
	},

	{
		"abyss_03",
		16979,
		300,
		1714,
		"Ferus",
		"FERUS",
		126,
		2818569
	},

	{
		"abyss_03",
		16980,
		300,
		1717,
		"Ferus",
		"FERUS_",
		126,
		2753033
	},

	{
		"abyss_03",
		16981,
		300,
		1720,
		"Hydro",
		"HYDRO",
		121,
		3080713
	},

	{
		"abyss_03",
		17204,
		301,
		1719,
		"Detale",
		"DETALE",
		135,
		4391433
	},

	{
		"alde_dun01",
		16650,
		300,
		1111,
		"Drainliar",
		"DRAINLIAR",
		47,
		3080194
	},

	{
		"alde_dun01",
		16651,
		300,
		1194,
		"Arclouse",
		"ARCLOUSE",
		107,
		2752772
	},

	{
		"alde_dun02",
		16652,
		300,
		1211,
		"Brilight",
		"BRILIGHT",
		71,
		1507332
	},

	{
		"alde_dun02",
		16653,
		300,
		1194,
		"Arclouse",
		"ARCLOUSE",
		107,
		2752772
	},

	{
		"alde_dun02",
		16654,
		300,
		1189,
		"Orc Archer",
		"ORC_ARCHER",
		78,
		1442055
	},

	{
		"alde_dun02",
		16655,
		300,
		1213,
		"High Orc",
		"HIGH_ORC",
		81,
		2818567
	},

	{
		"alde_dun03",
		16656,
		300,
		1111,
		"Drainliar",
		"DRAINLIAR",
		47,
		3080194
	},

	{
		"alde_dun03",
		16657,
		300,
		1209,
		"Cramp",
		"CRAMP",
		82,
		2949122
	},

	{
		"alde_dun03",
		16658,
		300,
		1216,
		"Penomena",
		"PENOMENA",
		85,
		1638661
	},

	{
		"alde_dun04",
		16659,
		300,
		1102,
		"Bathory",
		"BATHORY",
		86,
		1769735
	},

	{
		"alde_dun04",
		16660,
		300,
		1179,
		"Whisper",
		"WHISPER",
		46,
		4456454
	},

	{
		"alde_dun04",
		16661,
		300,
		1131,
		"Joker",
		"JOKER",
		90,
		5505543
	},

	{
		"ama_dun01",
		16728,
		300,
		1403,
		"Antique Firelock",
		"ANTIQUE_FIRELOCK",
		88,
		3211521
	},

	{
		"ama_dun01",
		16729,
		300,
		1404,
		"Miyabi Ningyo",
		"MIYABI_NINGYO",
		85,
		1769734
	},

	{
		"ama_dun01",
		16730,
		300,
		1401,
		"Shinobi",
		"SHINOBI",
		95,
		4391175
	},

	{
		"ama_dun02",
		16731,
		300,
		1403,
		"Antique Firelock",
		"ANTIQUE_FIRELOCK",
		88,
		3211521
	},

	{
		"ama_dun02",
		16732,
		300,
		1375,
		"The Paper",
		"THE_PAPER",
		97,
		3932416
	},

	{
		"ama_dun02",
		16733,
		300,
		1402,
		"Poison Toad",
		"POISON_TOAD",
		87,
		2949378
	},

	{
		"ama_dun02",
		16734,
		300,
		1404,
		"Miyabi Ningyo",
		"MIYABI_NINGYO",
		85,
		1769734
	},

	{
		"ama_dun02",
		16735,
		300,
		1401,
		"Shinobi",
		"SHINOBI",
		95,
		4391175
	},

	{
		"ama_dun02",
		16736,
		300,
		1129,
		"Horong",
		"HORONG",
		66,
		5439488
	},

	{
		"ama_dun03",
		16737,
		300,
		1403,
		"Antique Firelock",
		"ANTIQUE_FIRELOCK",
		88,
		3211521
	},

	{
		"ama_dun03",
		16738,
		300,
		1375,
		"The Paper",
		"THE_PAPER",
		97,
		3932416
	},

	{
		"ama_dun03",
		16739,
		300,
		1191,
		"Mimic",
		"MIMIC",
		56,
		3932416
	},

	{
		"ama_dun03",
		16740,
		300,
		1404,
		"Miyabi Ningyo",
		"MIYABI_NINGYO",
		85,
		1769734
	},

	{
		"ama_dun03",
		16741,
		300,
		1401,
		"Shinobi",
		"SHINOBI",
		95,
		4391175
	},

	{
		"ama_dun03",
		16742,
		300,
		1405,
		"Tengu",
		"TENGU",
		98,
		2753030
	},

	{
		"ama_dun03",
		17205,
		301,
		1492,
		"Incantation Samurai",
		"INCANTATION_SAMURAI",
		100,
		4391431
	},

	{
		"ama_fild01",
		16301,
		300,
		1060,
		"Bigfoot",
		"BIGFOOT",
		29,
		1442306
	},

	{
		"ama_fild01",
		16302,
		300,
		1400,
		"Karakasa",
		"KARAKASA",
		72,
		3932416
	},

	{
		"ama_fild01",
		16303,
		300,
		1406,
		"Kapha",
		"KAPHA",
		83,
		1376517
	},

	{
		"ama_fild01",
		16304,
		300,
		1404,
		"Miyabi Ningyo",
		"MIYABI_NINGYO",
		85,
		1769734
	},

	{
		"ama_fild01",
		16305,
		300,
		1402,
		"Poison Toad",
		"POISON_TOAD",
		87,
		2949378
	},

	{
		"ama_fild01",
		16306,
		300,
		1068,
		"Hydra",
		"HYDRA",
		34,
		2686979
	},

	{
		"anthell01",
		16331,
		300,
		1121,
		"Giearth",
		"GIEARTH",
		42,
		1441798
	},

	{
		"anthell01",
		16332,
		300,
		1097,
		"Ant Egg",
		"ANT_EGG",
		28,
		3932160
	},

	{
		"anthell01",
		16419,
		300,
		1105,
		"Deniro",
		"DENIRO",
		31,
		1441796
	},

	{
		"anthell01",
		16420,
		300,
		1176,
		"Vitata",
		"VITATA",
		35,
		1441796
	},

	{
		"anthell01",
		16421,
		300,
		1095,
		"Andre",
		"ANDRE",
		33,
		1441796
	},

	{
		"anthell01",
		16422,
		300,
		1005,
		"Familiar",
		"FARMILIAR",
		24,
		1769474
	},

	{
		"anthell01",
		16423,
		300,
		1160,
		"Piere",
		"PIERE",
		32,
		1441796
	},

	{
		"anthell02",
		16424,
		300,
		1121,
		"Giearth",
		"GIEARTH",
		42,
		1441798
	},

	{
		"anthell02",
		16425,
		300,
		1097,
		"Ant Egg",
		"ANT_EGG",
		28,
		3932160
	},

	{
		"anthell02",
		16426,
		300,
		1105,
		"Deniro",
		"DENIRO",
		31,
		1441796
	},

	{
		"anthell02",
		16427,
		300,
		1176,
		"Vitata",
		"VITATA",
		35,
		1441796
	},

	{
		"anthell02",
		16428,
		300,
		1095,
		"Andre",
		"ANDRE",
		33,
		1441796
	},

	{
		"anthell02",
		16429,
		300,
		1005,
		"Familiar",
		"FARMILIAR",
		24,
		1769474
	},

	{
		"anthell02",
		16430,
		300,
		1160,
		"Piere",
		"PIERE",
		32,
		1441796
	},

	{
		"anthell02",
		17206,
		301,
		1147,
		"Maya",
		"MAYA",
		55,
		5374468
	},

	{
		"arug_dun01",
		17322,
		300,
		1974,
		"Banshee Master",
		"BANSHEE_MASTER",
		118,
		3080454
	},

	{
		"arug_dun01",
		17323,
		300,
		1870,
		"Necromancer",
		"NECROMANCER",
		133,
		5832961
	},

	{
		"arug_dun01",
		17324,
		300,
		1975,
		"Beholder Master",
		"BEHOLDER_MASTER",
		106,
		2883840
	},

	{
		"arug_dun01",
		17325,
		300,
		1797,
		"Fanat",
		"FANAT",
		120,
		5243143
	},

	{
		"arug_dun01",
		17326,
		300,
		1796,
		"Aunoe",
		"AUNOE",
		110,
		5243143
	},

	{
		"ayo_dun01",
		16604,
		300,
		1036,
		"Ghoul",
		"GHOUL",
		61,
		3211521
	},

	{
		"ayo_dun01",
		16605,
		300,
		1586,
		"Leaf Cat",
		"LEAF_CAT",
		64,
		1441794
	},

	{
		"ayo_dun01",
		16606,
		300,
		1179,
		"Whisper",
		"WHISPER",
		46,
		4456454
	},

	{
		"ayo_dun01",
		16607,
		300,
		1587,
		"Kraben",
		"KRABEN",
		70,
		3145984
	},

	{
		"ayo_dun02",
		16608,
		300,
		1179,
		"Whisper",
		"WHISPER",
		46,
		4456454
	},

	{
		"ayo_dun02",
		16609,
		300,
		1587,
		"Kraben",
		"KRABEN",
		70,
		3145984
	},

	{
		"ayo_dun02",
		16610,
		300,
		1584,
		"Tamruan",
		"TAMRUAN",
		73,
		4391430
	},

	{
		"ayo_dun02",
		17207,
		301,
		1688,
		"Lady Tanee",
		"LADY_TANEE",
		80,
		4194819
	},

	{
		"ayo_fild01",
		16285,
		300,
		1056,
		"Smokie",
		"SMOKIE",
		29,
		1441794
	},

	{
		"ayo_fild01",
		16286,
		300,
		1104,
		"Coco",
		"COCO",
		38,
		1441794
	},

	{
		"ayo_fild01",
		16287,
		300,
		1057,
		"Yoyo",
		"YOYO",
		38,
		1441794
	},

	{
		"ayo_fild01",
		17576,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"ayo_fild02",
		16288,
		300,
		1586,
		"Leaf Cat",
		"LEAF_CAT",
		64,
		1441794
	},

	{
		"ayo_fild02",
		16289,
		300,
		1057,
		"Yoyo",
		"YOYO",
		38,
		1441794
	},

	{
		"ayo_fild02",
		16290,
		300,
		1587,
		"Kraben",
		"KRABEN",
		70,
		3145984
	},

	{
		"ayo_fild02",
		17577,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"beach_dun",
		16793,
		300,
		1255,
		"Neraid",
		"NERAID",
		98,
		1441794
	},

	{
		"beach_dun",
		16794,
		300,
		1264,
		"Merman",
		"MERMAN",
		60,
		3997959
	},

	{
		"beach_dun",
		16795,
		300,
		1148,
		"Medusa",
		"MEDUSA",
		102,
		2621702
	},

	{
		"beach_dun",
		16796,
		300,
		1256,
		"Pest",
		"PEST",
		89,
		3080194
	},

	{
		"beach_dun",
		17208,
		301,
		1583,
		"Tao Gunka",
		"TAO_GUNKA",
		110,
		3932678
	},

	{
		"beach_dun2",
		16797,
		300,
		1255,
		"Neraid",
		"NERAID",
		98,
		1441794
	},

	{
		"beach_dun2",
		16798,
		300,
		1274,
		"Megalith",
		"MEGALITH",
		65,
		5243392
	},

	{
		"beach_dun2",
		16799,
		300,
		1278,
		"Stalactic Golem",
		"STALACTIC_GOLEM",
		68,
		5243392
	},

	{
		"beach_dun2",
		16800,
		300,
		1279,
		"Tri Joint",
		"TRI_JOINT",
		66,
		1441796
	},

	{
		"beach_dun2",
		16801,
		300,
		1068,
		"Hydra",
		"HYDRA",
		34,
		2686979
	},

	{
		"beach_dun3",
		16802,
		300,
		1255,
		"Neraid",
		"NERAID",
		98,
		1441794
	},

	{
		"beach_dun3",
		16803,
		300,
		1064,
		"Megalodon",
		"MEGALODON",
		46,
		1900801
	},

	{
		"beach_dun3",
		16804,
		300,
		1034,
		"Thara Frog",
		"THARA_FROG",
		40,
		2687237
	},

	{
		"beach_dun3",
		16805,
		300,
		1068,
		"Hydra",
		"HYDRA",
		34,
		2686979
	},

	{
		"bif_fild01",
		15873,
		300,
		1994,
		"Luciola Vespa",
		"LUCIOLA_VESPA",
		109,
		1573124
	},

	{
		"bif_fild01",
		15874,
		300,
		1992,
		"Cornus",
		"CORNUS",
		120,
		4325634
	},

	{
		"bif_fild01",
		15875,
		300,
		2137,
		"Miming",
		"MIMING",
		140,
		1310720
	},

	{
		"bif_fild01",
		15876,
		300,
		2136,
		"Little Fatum",
		"LITTLE_FATUM",
		142,
		2883591
	},

	{
		"bif_fild01",
		15877,
		300,
		2133,
		"Angra Mantis",
		"ANGRA_MANTIS",
		144,
		2752772
	},

	{
		"bif_fild01",
		15878,
		300,
		2132,
		"Pom Spider",
		"POM_SPIDER",
		145,
		4063492
	},

	{
		"bif_fild02",
		15879,
		300,
		1994,
		"Luciola Vespa",
		"LUCIOLA_VESPA",
		109,
		1573124
	},

	{
		"bif_fild02",
		15880,
		300,
		1992,
		"Cornus",
		"CORNUS",
		120,
		4325634
	},

	{
		"bif_fild02",
		15881,
		300,
		2137,
		"Miming",
		"MIMING",
		140,
		1310720
	},

	{
		"bif_fild02",
		15882,
		300,
		2136,
		"Little Fatum",
		"LITTLE_FATUM",
		142,
		2883591
	},

	{
		"bif_fild02",
		15883,
		300,
		2133,
		"Angra Mantis",
		"ANGRA_MANTIS",
		144,
		2752772
	},

	{
		"bif_fild02",
		15884,
		300,
		2132,
		"Pom Spider",
		"POM_SPIDER",
		145,
		4063492
	},

	{
		"bra_dun01",
		15919,
		300,
		2070,
		"Piranha",
		"PIRANHA",
		75,
		3998213
	},

	{
		"bra_dun01",
		15920,
		300,
		2069,
		"Iara",
		"IARA",
		79,
		3997957
	},

	{
		"bra_dun01",
		15921,
		300,
		1084,
		"Black Mushroom",
		"BLACK_MUSHROOM",
		1,
		1441795
	},

	{
		"bra_dun01",
		15922,
		300,
		1141,
		"Marina",
		"MARINA",
		42,
		2686979
	},

	{
		"bra_dun01",
		15923,
		300,
		1070,
		"Kukre",
		"KUKRE",
		42,
		1376261
	},

	{
		"bra_dun01",
		15924,
		300,
		1161,
		"Plankton",
		"PLANKTON",
		40,
		3997699
	},

	{
		"bra_dun01",
		15925,
		300,
		1068,
		"Hydra",
		"HYDRA",
		34,
		2686979
	},

	{
		"bra_dun02",
		15926,
		300,
		2070,
		"Piranha",
		"PIRANHA",
		75,
		3998213
	},

	{
		"bra_dun02",
		15927,
		300,
		2069,
		"Iara",
		"IARA",
		79,
		3997957
	},

	{
		"bra_dun02",
		15928,
		300,
		1141,
		"Marina",
		"MARINA",
		42,
		2686979
	},

	{
		"bra_dun02",
		15929,
		300,
		1070,
		"Kukre",
		"KUKRE",
		42,
		1376261
	},

	{
		"bra_dun02",
		15930,
		300,
		1161,
		"Plankton",
		"PLANKTON",
		40,
		3997699
	},

	{
		"bra_dun02",
		15931,
		300,
		1068,
		"Hydra",
		"HYDRA",
		34,
		2686979
	},

	{
		"bra_dun02",
		15932,
		300,
		1083,
		"Shining Plant",
		"SHINING_PLANT",
		1,
		1703939
	},

	{
		"bra_dun02",
		15933,
		300,
		1084,
		"Black Mushroom",
		"BLACK_MUSHROOM",
		1,
		1441795
	},

	{
		"bra_dun02",
		15934,
		301,
		2068,
		"Boitata",
		"BOITATA",
		93,
		4129282
	},

	{
		"bra_fild01",
		15912,
		300,
		2074,
		"Curupira",
		"CURUPIRA",
		68,
		1442055
	},

	{
		"bra_fild01",
		15913,
		300,
		1110,
		"Dokebi",
		"DOKEBI",
		68,
		1769478
	},

	{
		"bra_fild01",
		15914,
		300,
		1166,
		"Savage",
		"SAVAGE",
		59,
		2753026
	},

	{
		"bra_fild01",
		15915,
		300,
		2071,
		"Headless Mule",
		"HEADLESS_MULE",
		80,
		4129286
	},

	{
		"bra_fild01",
		15916,
		300,
		1085,
		"Red Mushroom",
		"RED_MUSHROOM",
		1,
		1441795
	},

	{
		"bra_fild01",
		15917,
		300,
		2072,
		"Jaguar",
		"JAGUAR",
		71,
		2752770
	},

	{
		"bra_fild01",
		15918,
		300,
		2073,
		"Toucan",
		"TOUCAN",
		70,
		2883842
	},

	{
		"brasilis",
		13800,
		300,
		2057,
		"Suspicious Mouse",
		"E_CRAMP",
		1,
		2949122
	},

	{
		"c_tower1",
		16662,
		300,
		1195,
		"Rideword",
		"RIDEWORD",
		74,
		3932160
	},

	{
		"c_tower1",
		16663,
		300,
		1102,
		"Bathory",
		"BATHORY",
		86,
		1769735
	},

	{
		"c_tower1",
		16664,
		300,
		1270,
		"Clock Tower Manager",
		"C_TOWER_MANAGER",
		90,
		5243392
	},

	{
		"c_tower1",
		16665,
		300,
		1199,
		"Punk",
		"PUNK",
		82,
		1572867
	},

	{
		"c_tower2",
		16666,
		300,
		1195,
		"Rideword",
		"RIDEWORD",
		74,
		3932160
	},

	{
		"c_tower2",
		16667,
		300,
		1191,
		"Mimic",
		"MIMIC",
		56,
		3932416
	},

	{
		"c_tower2",
		16668,
		300,
		1270,
		"Clock Tower Manager",
		"C_TOWER_MANAGER",
		90,
		5243392
	},

	{
		"c_tower2",
		16669,
		300,
		1377,
		"Elder",
		"ELDER",
		92,
		5243399
	},

	{
		"c_tower2",
		16670,
		300,
		1269,
		"Clock",
		"CLOCK",
		81,
		2752768
	},

	{
		"c_tower2",
		16671,
		300,
		1199,
		"Punk",
		"PUNK",
		82,
		1572867
	},

	{
		"c_tower3",
		16672,
		300,
		1195,
		"Rideword",
		"RIDEWORD",
		74,
		3932160
	},

	{
		"c_tower3",
		16673,
		300,
		1191,
		"Mimic",
		"MIMIC",
		56,
		3932416
	},

	{
		"c_tower3",
		16674,
		300,
		1270,
		"Clock Tower Manager",
		"C_TOWER_MANAGER",
		90,
		5243392
	},

	{
		"c_tower3",
		16675,
		300,
		1193,
		"Alarm",
		"ALARM",
		88,
		3932416
	},

	{
		"c_tower4",
		16676,
		300,
		1195,
		"Rideword",
		"RIDEWORD",
		74,
		3932160
	},

	{
		"c_tower4",
		16677,
		300,
		1191,
		"Mimic",
		"MIMIC",
		56,
		3932416
	},

	{
		"c_tower4",
		16678,
		300,
		1270,
		"Clock Tower Manager",
		"C_TOWER_MANAGER",
		90,
		5243392
	},

	{
		"c_tower4",
		16679,
		300,
		1320,
		"Owl Duke",
		"OWL_DUKE",
		92,
		3932678
	},

	{
		"c_tower4",
		16680,
		300,
		1193,
		"Alarm",
		"ALARM",
		88,
		3932416
	},

	{
		"c_tower4",
		16681,
		300,
		1377,
		"Elder",
		"ELDER",
		92,
		5243399
	},

	{
		"c_tower4",
		16682,
		300,
		1179,
		"Whisper",
		"WHISPER",
		46,
		4456454
	},

	{
		"c_tower4",
		16683,
		300,
		1269,
		"Clock",
		"CLOCK",
		81,
		2752768
	},

	{
		"cmd_fild01",
		16106,
		300,
		1687,
		"Green Iguana",
		"GREEN_IGUANA",
		55,
		2752770
	},

	{
		"cmd_fild01",
		16107,
		300,
		1118,
		"Flora",
		"FLORA",
		59,
		1442307
	},

	{
		"cmd_fild01",
		17729,
		300,
		1083,
		"Shining Plant",
		"SHINING_PLANT",
		1,
		1703939
	},

	{
		"cmd_fild01",
		17730,
		300,
		1079,
		"Blue Plant",
		"BLUE_PLANT",
		1,
		1441795
	},

	{
		"cmd_fild01",
		17734,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"cmd_fild02",
		16069,
		300,
		1266,
		"Aster",
		"ASTER",
		50,
		1441797
	},

	{
		"cmd_fild02",
		16070,
		300,
		1317,
		"Fur Seal",
		"FUR_SEAL",
		47,
		1376514
	},

	{
		"cmd_fild02",
		16071,
		300,
		1391,
		"Galapago",
		"GALAPAGO",
		45,
		1441794
	},

	{
		"cmd_fild02",
		16072,
		300,
		1074,
		"Shellfish",
		"SHELLFISH",
		50,
		1376261
	},

	{
		"cmd_fild02",
		16073,
		300,
		1073,
		"Crab",
		"CRAB",
		43,
		1376261
	},

	{
		"cmd_fild02",
		17474,
		300,
		1313,
		"Mobster",
		"MOBSTER",
		58,
		1310983
	},

	{
		"cmd_fild03",
		16108,
		300,
		1271,
		"Alligator",
		"ALLIGATOR",
		57,
		1376514
	},

	{
		"cmd_fild03",
		16109,
		300,
		1118,
		"Flora",
		"FLORA",
		59,
		1442307
	},

	{
		"cmd_fild03",
		17379,
		300,
		1262,
		"Mutant Dragon",
		"MUTANT_DRAGON",
		65,
		2818569
	},

	{
		"cmd_fild03",
		17482,
		300,
		1089,
		"Toad",
		"TOAD",
		27,
		1376517
	},

	{
		"cmd_fild03",
		17735,
		300,
		1083,
		"Shining Plant",
		"SHINING_PLANT",
		1,
		1703939
	},

	{
		"cmd_fild04",
		16074,
		300,
		1266,
		"Aster",
		"ASTER",
		50,
		1441797
	},

	{
		"cmd_fild04",
		16075,
		300,
		1323,
		"Sea Otter",
		"SEE_OTTER",
		48,
		3997954
	},

	{
		"cmd_fild04",
		16076,
		300,
		1391,
		"Galapago",
		"GALAPAGO",
		45,
		1441794
	},

	{
		"cmd_fild04",
		16077,
		300,
		1074,
		"Shellfish",
		"SHELLFISH",
		50,
		1376261
	},

	{
		"cmd_fild04",
		16078,
		300,
		1073,
		"Crab",
		"CRAB",
		43,
		1376261
	},

	{
		"cmd_fild06",
		16110,
		300,
		1058,
		"Metaller",
		"METALLER",
		55,
		1507588
	},

	{
		"cmd_fild06",
		16111,
		300,
		1040,
		"Golem",
		"GOLEM",
		61,
		3932672
	},

	{
		"cmd_fild06",
		17738,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"cmd_fild07",
		16079,
		300,
		1266,
		"Aster",
		"ASTER",
		50,
		1441797
	},

	{
		"cmd_fild07",
		16080,
		300,
		1074,
		"Shellfish",
		"SHELLFISH",
		50,
		1376261
	},

	{
		"cmd_fild07",
		16081,
		300,
		1254,
		"Raggler",
		"RAGGLER",
		48,
		1572866
	},

	{
		"cmd_fild07",
		16082,
		300,
		1073,
		"Crab",
		"CRAB",
		43,
		1376261
	},

	{
		"cmd_fild08",
		16051,
		300,
		1097,
		"Ant Egg",
		"ANT_EGG",
		28,
		3932160
	},

	{
		"cmd_fild08",
		16052,
		300,
		1040,
		"Golem",
		"GOLEM",
		61,
		3932672
	},

	{
		"cmd_fild08",
		16053,
		300,
		1105,
		"Deniro",
		"DENIRO",
		31,
		1441796
	},

	{
		"cmd_fild08",
		16054,
		300,
		1160,
		"Piere",
		"PIERE",
		32,
		1441796
	},

	{
		"cmd_fild08",
		16055,
		300,
		1095,
		"Andre",
		"ANDRE",
		33,
		1441796
	},

	{
		"cmd_fild08",
		17740,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"cmd_fild09",
		16112,
		300,
		1097,
		"Ant Egg",
		"ANT_EGG",
		28,
		3932160
	},

	{
		"cmd_fild09",
		16113,
		300,
		1105,
		"Deniro",
		"DENIRO",
		31,
		1441796
	},

	{
		"cmd_fild09",
		16114,
		300,
		1160,
		"Piere",
		"PIERE",
		32,
		1441796
	},

	{
		"cmd_fild09",
		16115,
		300,
		1095,
		"Andre",
		"ANDRE",
		33,
		1441796
	},

	{
		"cmd_fild09",
		16116,
		300,
		1058,
		"Metaller",
		"METALLER",
		55,
		1507588
	},

	{
		"dew_dun01",
		15865,
		300,
		2152,
		"Comodo",
		"COMODO",
		81,
		4260098
	},

	{
		"dew_dun01",
		15866,
		300,
		1305,
		"Ancient Worm",
		"ANCIENT_WORM",
		121,
		1638916
	},

	{
		"dew_dun01",
		15867,
		300,
		1311,
		"Gullinbursti",
		"GULLINBURSTI",
		120,
		2753026
	},

	{
		"dew_dun01",
		15868,
		301,
		2156,
		"Leak",
		"LEAK",
		94,
		3080710
	},

	{
		"dew_dun02",
		15869,
		300,
		2154,
		"Banaspaty",
		"BANASPATY",
		85,
		4128768
	},

	{
		"dew_dun02",
		15870,
		300,
		1309,
		"Gajomart",
		"GAJOMART",
		140,
		5439488
	},

	{
		"dew_dun02",
		15871,
		300,
		1301,
		"Am Mut",
		"AM_MUT",
		141,
		1769478
	},

	{
		"dew_dun02",
		15872,
		300,
		2155,
		"Butoijo",
		"BUTOIJO",
		88,
		2818566
	},

	{
		"dew_fild01",
		15862,
		300,
		2151,
		"Alnoldi",
		"ALNOLDI",
		80,
		1442051
	},

	{
		"dew_fild01",
		15863,
		300,
		1099,
		"Argiope",
		"ARGIOPE",
		75,
		1638916
	},

	{
		"dew_fild01",
		15864,
		300,
		2153,
		"Cendrawasih",
		"CENDRAWASIH",
		84,
		1573128
	},

	{
		"dic_dun01",
		15885,
		300,
		2083,
		"Scaraba",
		"HORN_SCARABA",
		130,
		1441796
	},

	{
		"dic_dun01",
		15886,
		300,
		2084,
		"Scaraba",
		"HORN_SCARABA2",
		134,
		1441796
	},

	{
		"dic_dun01",
		15887,
		300,
		2088,
		"Scaraba Egg",
		"HORN_SCARABA_EGG",
		125,
		1310724
	},

	{
		"dic_dun01",
		15888,
		300,
		2089,
		"Scaraba Egg",
		"HORN_SCARABA2_EGG",
		126,
		1310724
	},

	{
		"dic_dun02",
		15889,
		300,
		2085,
		"Antler Scaraba",
		"ANTLER_SCARABA",
		136,
		2752772
	},

	{
		"dic_dun02",
		15890,
		300,
		2086,
		"Rake Scaraba",
		"RAKE_SCARABA",
		139,
		2752772
	},

	{
		"dic_dun02",
		15891,
		300,
		2090,
		"Antler Scaraba Egg",
		"ANTLER_SCARABA_EGG",
		127,
		1310724
	},

	{
		"dic_dun02",
		15892,
		300,
		2091,
		"Rake Scaraba Egg",
		"RAKE_SCARABA_EGG",
		128,
		1310724
	},

	{
		"dic_dun02",
		15893,
		301,
		2087,
		"Queen Scaraba",
		"QUEEN_SCARABA",
		140,
		4063748
	},

	{
		"dic_dun03",
		15894,
		300,
		2166,
		"Gold One-Horn Scaraba Egg",
		"I_HORN_SCARABA_EGG",
		125,
		1441796
	},

	{
		"dic_dun03",
		15895,
		300,
		2167,
		"Gold Two-Horn Scaraba Egg",
		"I_HORN_SCARABA2_EGG",
		126,
		1441796
	},

	{
		"dic_dun03",
		15896,
		300,
		2168,
		"Gold Antler Scaraba Egg",
		"I_ANTLER_SCARABA_EGG",
		127,
		1441796
	},

	{
		"dic_dun03",
		15897,
		300,
		2169,
		"Gold Rake Scaraba Egg",
		"I_RAKE_SCARABA_EGG",
		128,
		1441796
	},

	{
		"dic_dun03",
		15898,
		300,
		2161,
		"Gold One-Horn Scaraba",
		"I_HORN_SCARABA",
		130,
		1441796
	},

	{
		"dic_dun03",
		15899,
		300,
		2162,
		"Gold Two-Horn Scaraba",
		"I_HORN_SCARABA2",
		134,
		1441796
	},

	{
		"dic_dun03",
		15900,
		300,
		2163,
		"Gold Antler Scaraba",
		"I_ANTLER_SCARABA",
		136,
		2752772
	},

	{
		"dic_dun03",
		15901,
		300,
		2164,
		"Gold Rake Scaraba",
		"I_RAKE_SCARABA",
		139,
		2752772
	},

	{
		"dic_dun03",
		15902,
		301,
		2165,
		"Gold Queen Scaraba",
		"I_QUEEN_SCARABA",
		140,
		4063748
	},

	{
		"dic_fild01",
		15903,
		300,
		1987,
		"Centipede",
		"CENTIPEDE",
		125,
		2949380
	},

	{
		"dic_fild01",
		15904,
		300,
		1999,
		"Centipede Larva",
		"CENTIPEDE_LARVA",
		118,
		1638404
	},

	{
		"dic_fild01",
		15905,
		300,
		1986,
		"Tatacho",
		"TATACHO",
		128,
		1442050
	},

	{
		"dic_fild01",
		15906,
		300,
		2092,
		"Dolomedes",
		"DOLOMEDES",
		132,
		3998212
	},

	{
		"dic_fild02",
		15907,
		300,
		2024,
		"Bradium Golem",
		"BRADIUM_GOLEM",
		133,
		2753024
	},

	{
		"dic_fild02",
		15908,
		300,
		1987,
		"Centipede",
		"CENTIPEDE",
		125,
		2949380
	},

	{
		"dic_fild02",
		15909,
		300,
		1999,
		"Centipede Larva",
		"CENTIPEDE_LARVA",
		118,
		1638404
	},

	{
		"dic_fild02",
		15910,
		300,
		1986,
		"Tatacho",
		"TATACHO",
		128,
		1442050
	},

	{
		"dic_fild02",
		15911,
		300,
		2092,
		"Dolomedes",
		"DOLOMEDES",
		132,
		3998212
	},

	{
		"ein_dun01",
		16743,
		300,
		1617,
		"Waste Stove",
		"WASTE_STOVE",
		92,
		1311232
	},

	{
		"ein_dun01",
		16744,
		300,
		1620,
		"Noxious",
		"NOXIOUS",
		87,
		4456704
	},

	{
		"ein_dun01",
		16745,
		300,
		1621,
		"Venomous",
		"VENOMOUS",
		87,
		1638656
	},

	{
		"ein_dun01",
		16746,
		300,
		1619,
		"Porcellio",
		"PORCELLIO",
		85,
		4063236
	},

	{
		"ein_dun01",
		16747,
		300,
		1616,
		"Pitman",
		"PITMAN",
		90,
		2753025
	},

	{
		"ein_dun01",
		17470,
		300,
		1618,
		"Ungoliant",
		"UNGOLIANT",
		94,
		2949636
	},

	{
		"ein_dun02",
		16748,
		300,
		1617,
		"Waste Stove",
		"WASTE_STOVE",
		92,
		1311232
	},

	{
		"ein_dun02",
		16749,
		300,
		1622,
		"Teddy Bear",
		"TEDDY_BEAR",
		91,
		3932160
	},

	{
		"ein_dun02",
		16750,
		300,
		1614,
		"Mineral",
		"MINERAL",
		96,
		2621440
	},

	{
		"ein_dun02",
		16751,
		300,
		1615,
		"Obsidian",
		"OBSIDIAN",
		97,
		2752512
	},

	{
		"ein_dun02",
		17209,
		301,
		1623,
		"RSX 0806",
		"RSX_0806",
		100,
		3932672
	},

	{
		"ein_fild03",
		16205,
		300,
		1622,
		"Teddy Bear",
		"TEDDY_BEAR",
		91,
		3932160
	},

	{
		"ein_fild03",
		16206,
		300,
		1621,
		"Venomous",
		"VENOMOUS",
		87,
		1638656
	},

	{
		"ein_fild03",
		16207,
		300,
		1620,
		"Noxious",
		"NOXIOUS",
		87,
		4456704
	},

	{
		"ein_fild03",
		16208,
		300,
		1616,
		"Pitman",
		"PITMAN",
		90,
		2753025
	},

	{
		"ein_fild03",
		17550,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"ein_fild03",
		17551,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"ein_fild04",
		16209,
		300,
		1621,
		"Venomous",
		"VENOMOUS",
		87,
		1638656
	},

	{
		"ein_fild04",
		16210,
		300,
		1620,
		"Noxious",
		"NOXIOUS",
		87,
		4456704
	},

	{
		"ein_fild04",
		16211,
		300,
		1616,
		"Pitman",
		"PITMAN",
		90,
		2753025
	},

	{
		"ein_fild04",
		16212,
		300,
		1622,
		"Teddy Bear",
		"TEDDY_BEAR",
		91,
		3932160
	},

	{
		"ein_fild04",
		17363,
		300,
		1378,
		"Demon Pungus",
		"DEMON_PUNGUS",
		91,
		4259846
	},

	{
		"ein_fild04",
		17552,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"ein_fild04",
		17553,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"ein_fild04",
		17554,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"ein_fild05",
		16213,
		300,
		1620,
		"Noxious",
		"NOXIOUS",
		87,
		4456704
	},

	{
		"ein_fild05",
		16214,
		300,
		1621,
		"Venomous",
		"VENOMOUS",
		87,
		1638656
	},

	{
		"ein_fild05",
		16215,
		300,
		1616,
		"Pitman",
		"PITMAN",
		90,
		2753025
	},

	{
		"ein_fild05",
		16216,
		300,
		1622,
		"Teddy Bear",
		"TEDDY_BEAR",
		91,
		3932160
	},

	{
		"ein_fild05",
		17364,
		300,
		1378,
		"Demon Pungus",
		"DEMON_PUNGUS",
		91,
		4259846
	},

	{
		"ein_fild06",
		16217,
		300,
		1628,
		"Mole",
		"MOLE",
		85,
		2752514
	},

	{
		"ein_fild06",
		16218,
		300,
		1613,
		"Metaling",
		"METALING",
		81,
		1310720
	},

	{
		"ein_fild06",
		17555,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"ein_fild06",
		17556,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"ein_fild07",
		16219,
		300,
		1613,
		"Metaling",
		"METALING",
		81,
		1310720
	},

	{
		"ein_fild07",
		16220,
		300,
		1628,
		"Mole",
		"MOLE",
		85,
		2752514
	},

	{
		"ein_fild07",
		16221,
		300,
		1619,
		"Porcellio",
		"PORCELLIO",
		85,
		4063236
	},

	{
		"ein_fild07",
		17409,
		300,
		1085,
		"Red Mushroom",
		"RED_MUSHROOM",
		1,
		1441795
	},

	{
		"ein_fild07",
		17469,
		300,
		1618,
		"Ungoliant",
		"UNGOLIANT",
		94,
		2949636
	},

	{
		"ein_fild07",
		17557,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"ein_fild07",
		17558,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"ein_fild08",
		16222,
		300,
		1613,
		"Metaling",
		"METALING",
		81,
		1310720
	},

	{
		"ein_fild08",
		16223,
		300,
		1619,
		"Porcellio",
		"PORCELLIO",
		85,
		4063236
	},

	{
		"ein_fild08",
		17410,
		300,
		1085,
		"Red Mushroom",
		"RED_MUSHROOM",
		1,
		1441795
	},

	{
		"ein_fild08",
		17559,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"ein_fild08",
		17560,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"ein_fild09",
		16224,
		300,
		1619,
		"Porcellio",
		"PORCELLIO",
		85,
		4063236
	},

	{
		"ein_fild09",
		16225,
		300,
		1613,
		"Metaling",
		"METALING",
		81,
		1310720
	},

	{
		"ein_fild09",
		17411,
		300,
		1085,
		"Red Mushroom",
		"RED_MUSHROOM",
		1,
		1441795
	},

	{
		"ein_fild09",
		17561,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"ein_fild09",
		17562,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"gef_dun00",
		16528,
		300,
		1084,
		"Black Mushroom",
		"BLACK_MUSHROOM",
		1,
		1441795
	},

	{
		"gef_dun00",
		16529,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"gef_dun00",
		16530,
		300,
		1083,
		"Shining Plant",
		"SHINING_PLANT",
		1,
		1703939
	},

	{
		"gef_dun00",
		16531,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"gef_dun00",
		16532,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"gef_dun00",
		16533,
		300,
		1077,
		"Poison Spore",
		"POISON_SPORE",
		26,
		1638659
	},

	{
		"gef_dun00",
		16534,
		300,
		1031,
		"Poporing",
		"POPORING",
		30,
		1638659
	},

	{
		"gef_dun00",
		16535,
		300,
		1035,
		"Hunter Fly",
		"HUNTER_FLY",
		63,
		2883588
	},

	{
		"gef_dun01",
		16536,
		300,
		1084,
		"Black Mushroom",
		"BLACK_MUSHROOM",
		1,
		1441795
	},

	{
		"gef_dun01",
		16537,
		300,
		1036,
		"Ghoul",
		"GHOUL",
		61,
		3211521
	},

	{
		"gef_dun01",
		16538,
		300,
		1061,
		"Nightmare",
		"NIGHTMARE",
		69,
		4456966
	},

	{
		"gef_dun01",
		16539,
		300,
		1111,
		"Drainliar",
		"DRAINLIAR",
		47,
		3080194
	},

	{
		"gef_dun01",
		16540,
		300,
		1130,
		"Jakk",
		"JAKK",
		63,
		2818304
	},

	{
		"gef_dun01",
		16541,
		300,
		1015,
		"Zombie",
		"ZOMBIE",
		17,
		1900801
	},

	{
		"gef_dun01",
		16542,
		300,
		1079,
		"Blue Plant",
		"BLUE_PLANT",
		1,
		1441795
	},

	{
		"gef_dun01",
		16543,
		300,
		1082,
		"White Plant",
		"WHITE_PLANT",
		1,
		1441795
	},

	{
		"gef_dun01",
		17210,
		301,
		1389,
		"Dracula",
		"DRACULA",
		75,
		5702150
	},

	{
		"gef_dun02",
		16544,
		300,
		1036,
		"Ghoul",
		"GHOUL",
		61,
		3211521
	},

	{
		"gef_dun02",
		16545,
		300,
		1061,
		"Nightmare",
		"NIGHTMARE",
		69,
		4456966
	},

	{
		"gef_dun02",
		16546,
		300,
		1109,
		"Deviruchi",
		"DEVIRUCHI",
		93,
		1769478
	},

	{
		"gef_dun02",
		16547,
		300,
		1143,
		"Marionette",
		"MARIONETTE",
		90,
		4456454
	},

	{
		"gef_dun02",
		16548,
		300,
		1083,
		"Shining Plant",
		"SHINING_PLANT",
		1,
		1703939
	},

	{
		"gef_dun02",
		16549,
		300,
		1179,
		"Whisper",
		"WHISPER",
		46,
		4456454
	},

	{
		"gef_dun02",
		16550,
		300,
		1082,
		"White Plant",
		"WHITE_PLANT",
		1,
		1441795
	},

	{
		"gef_dun02",
		16551,
		300,
		1035,
		"Hunter Fly",
		"HUNTER_FLY",
		63,
		2883588
	},

	{
		"gef_dun02",
		17211,
		301,
		1046,
		"Doppelganger",
		"DOPPELGANGER",
		77,
		4391174
	},

	{
		"gef_dun03",
		16552,
		300,
		1291,
		"Wraith Dead",
		"WRAITH_DEAD",
		121,
		5833217
	},

	{
		"gef_dun03",
		16553,
		300,
		1192,
		"Wraith",
		"WRAITH",
		77,
		5833217
	},

	{
		"gef_dun03",
		16554,
		300,
		1083,
		"Shining Plant",
		"SHINING_PLANT",
		1,
		1703939
	},

	{
		"gef_dun03",
		16555,
		300,
		1263,
		"Wind Ghost",
		"WIND_GHOST",
		80,
		4194566
	},

	{
		"gef_dun03",
		16556,
		300,
		1082,
		"White Plant",
		"WHITE_PLANT",
		1,
		1441795
	},

	{
		"gef_dun03",
		17360,
		300,
		1626,
		"Hellion Revenant",
		"G_DARK_PRIEST",
		79,
		4522246
	},

	{
		"gef_fild00",
		15944,
		300,
		1002,
		"Poring",
		"PORING",
		1,
		1376515
	},

	{
		"gef_fild00",
		15945,
		300,
		1007,
		"Fabre",
		"FABRE",
		6,
		1441796
	},

	{
		"gef_fild00",
		15946,
		300,
		1011,
		"Chonchon",
		"CHONCHON",
		5,
		1572868
	},

	{
		"gef_fild00",
		17650,
		300,
		1079,
		"Blue Plant",
		"BLUE_PLANT",
		1,
		1441795
	},

	{
		"gef_fild00",
		17652,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"gef_fild01",
		15975,
		300,
		1012,
		"Roda Frog",
		"RODA_FROG",
		13,
		1376517
	},

	{
		"gef_fild01",
		15976,
		300,
		1094,
		"Ambernite",
		"AMBERNITE",
		19,
		1376772
	},

	{
		"gef_fild01",
		17481,
		300,
		1089,
		"Toad",
		"TOAD",
		27,
		1376517
	},

	{
		"gef_fild01",
		17594,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"gef_fild02",
		16040,
		300,
		1031,
		"Poporing",
		"POPORING",
		30,
		1638659
	},

	{
		"gef_fild02",
		16041,
		300,
		1128,
		"Horn",
		"HORN",
		32,
		1442052
	},

	{
		"gef_fild02",
		16042,
		300,
		1033,
		"Elder Willow",
		"ELDER_WILOW",
		34,
		2818307
	},

	{
		"gef_fild02",
		16043,
		300,
		1104,
		"Coco",
		"COCO",
		38,
		1441794
	},

	{
		"gef_fild02",
		17413,
		300,
		1085,
		"Red Mushroom",
		"RED_MUSHROOM",
		1,
		1441795
	},

	{
		"gef_fild02",
		17589,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"gef_fild02",
		17590,
		300,
		1079,
		"Blue Plant",
		"BLUE_PLANT",
		1,
		1441795
	},

	{
		"gef_fild02",
		17593,
		300,
		1083,
		"Shining Plant",
		"SHINING_PLANT",
		1,
		1703939
	},

	{
		"gef_fild03",
		16062,
		300,
		1686,
		"Orc Baby",
		"ORC_BABY",
		43,
		1441799
	},

	{
		"gef_fild03",
		16063,
		300,
		1023,
		"Orc Warrior",
		"ORK_WARRIOR",
		44,
		1442055
	},

	{
		"gef_fild03",
		16064,
		300,
		1273,
		"Orc Lady",
		"ORC_LADY",
		45,
		2752775
	},

	{
		"gef_fild03",
		17489,
		301,
		1087,
		"Orc Hero",
		"ORK_HERO",
		50,
		2753031
	},

	{
		"gef_fild03",
		17599,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"gef_fild04",
		15985,
		300,
		1020,
		"Mandragora",
		"MANDRAGORA",
		13,
		4063491
	},

	{
		"gef_fild04",
		15986,
		300,
		1063,
		"Lunatic",
		"LUNATIC",
		3,
		3932162
	},

	{
		"gef_fild04",
		15987,
		300,
		1007,
		"Fabre",
		"FABRE",
		6,
		1441796
	},

	{
		"gef_fild04",
		15988,
		300,
		1011,
		"Chonchon",
		"CHONCHON",
		5,
		1572868
	},

	{
		"gef_fild04",
		17644,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"gef_fild05",
		16011,
		300,
		1048,
		"Thief Bug Egg",
		"THIEF_BUG_EGG",
		20,
		1769476
	},

	{
		"gef_fild05",
		16012,
		300,
		1006,
		"Thief Bug Larva",
		"THIEF_BUG_LARVA",
		0,
		0
	},

	{
		"gef_fild05",
		16013,
		300,
		1174,
		"Stainer",
		"STAINER",
		21,
		1572868
	},

	{
		"gef_fild05",
		16014,
		300,
		1018,
		"Creamy",
		"CREAMY",
		23,
		1572868
	},

	{
		"gef_fild05",
		16015,
		300,
		1056,
		"Smokie",
		"SMOKIE",
		29,
		1441794
	},

	{
		"gef_fild05",
		17620,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"gef_fild06",
		16141,
		300,
		1155,
		"Petite",
		"PETIT",
		86,
		1442057
	},

	{
		"gef_fild06",
		16142,
		300,
		1139,
		"Mantis",
		"MANTIS",
		65,
		1442052
	},

	{
		"gef_fild06",
		16143,
		300,
		1037,
		"Side Winder",
		"SIDE_WINDER",
		70,
		1638658
	},

	{
		"gef_fild06",
		17643,
		300,
		1083,
		"Shining Plant",
		"SHINING_PLANT",
		1,
		1703939
	},

	{
		"gef_fild07",
		15947,
		300,
		1002,
		"Poring",
		"PORING",
		1,
		1376515
	},

	{
		"gef_fild07",
		15948,
		300,
		1008,
		"Pupa",
		"PUPA",
		4,
		1441796
	},

	{
		"gef_fild07",
		15949,
		300,
		1007,
		"Fabre",
		"FABRE",
		6,
		1441796
	},

	{
		"gef_fild07",
		15950,
		300,
		1011,
		"Chonchon",
		"CHONCHON",
		5,
		1572868
	},

	{
		"gef_fild07",
		17646,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"gef_fild07",
		17647,
		300,
		1083,
		"Shining Plant",
		"SHINING_PLANT",
		1,
		1703939
	},

	{
		"gef_fild07",
		17648,
		300,
		1079,
		"Blue Plant",
		"BLUE_PLANT",
		1,
		1441795
	},

	{
		"gef_fild08",
		16144,
		300,
		1156,
		"Petite",
		"PETIT_",
		79,
		1573129
	},

	{
		"gef_fild08",
		16145,
		300,
		1139,
		"Mantis",
		"MANTIS",
		65,
		1442052
	},

	{
		"gef_fild08",
		16146,
		300,
		1118,
		"Flora",
		"FLORA",
		59,
		1442307
	},

	{
		"gef_fild08",
		17635,
		300,
		1079,
		"Blue Plant",
		"BLUE_PLANT",
		1,
		1441795
	},

	{
		"gef_fild09",
		15973,
		300,
		1094,
		"Ambernite",
		"AMBERNITE",
		19,
		1376772
	},

	{
		"gef_fild09",
		15974,
		300,
		1012,
		"Roda Frog",
		"RODA_FROG",
		13,
		1376517
	},

	{
		"gef_fild09",
		17414,
		300,
		1085,
		"Red Mushroom",
		"RED_MUSHROOM",
		1,
		1441795
	},

	{
		"gef_fild09",
		17595,
		300,
		1079,
		"Blue Plant",
		"BLUE_PLANT",
		1,
		1441795
	},

	{
		"gef_fild10",
		16059,
		300,
		1686,
		"Orc Baby",
		"ORC_BABY",
		43,
		1441799
	},

	{
		"gef_fild10",
		16060,
		300,
		1023,
		"Orc Warrior",
		"ORK_WARRIOR",
		44,
		1442055
	},

	{
		"gef_fild10",
		16061,
		300,
		1273,
		"Orc Lady",
		"ORC_LADY",
		45,
		2752775
	},

	{
		"gef_fild10",
		17212,
		301,
		1190,
		"Orc Lord",
		"ORC_LORD",
		55,
		5374471
	},

	{
		"gef_fild10",
		17596,
		300,
		1079,
		"Blue Plant",
		"BLUE_PLANT",
		1,
		1441795
	},

	{
		"gef_fild10",
		17598,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"gef_fild11",
		16065,
		300,
		1122,
		"Goblin",
		"GOBLIN_1",
		48,
		1573127
	},

	{
		"gef_fild11",
		16066,
		300,
		1123,
		"Goblin",
		"GOBLIN_2",
		44,
		1507591
	},

	{
		"gef_fild11",
		16067,
		300,
		1124,
		"Goblin",
		"GOBLIN_3",
		44,
		1638663
	},

	{
		"gef_fild11",
		16068,
		300,
		1125,
		"Goblin",
		"GOBLIN_4",
		49,
		1442055
	},

	{
		"gef_fild11",
		17351,
		300,
		1299,
		"Goblin Leader",
		"GOBLIN_LEADER",
		55,
		1573127
	},

	{
		"gefenia01",
		16982,
		300,
		1292,
		"Mini Demon",
		"MINI_DEMON",
		117,
		1769478
	},

	{
		"gefenia01",
		16983,
		300,
		1390,
		"Violy",
		"VIOLY",
		118,
		2621703
	},

	{
		"gefenia01",
		16984,
		300,
		1370,
		"Succubus",
		"SUCCUBUS",
		119,
		4391174
	},

	{
		"gefenia01",
		16985,
		300,
		1219,
		"Knight of Abyss",
		"KNIGHT_OF_ABYSS",
		122,
		5702151
	},

	{
		"gefenia01",
		16986,
		300,
		1374,
		"Incubus",
		"INCUBUS",
		120,
		4391174
	},

	{
		"gefenia01",
		16987,
		300,
		1371,
		"Fake Angel",
		"FAKE_ANGEL",
		105,
		4325384
	},

	{
		"gefenia01",
		17383,
		300,
		1203,
		"Mysteltainn",
		"MYSTELTAINN",
		130,
		5702144
	},

	{
		"gefenia01",
		17389,
		300,
		1205,
		"Executioner",
		"EXECUTIONER",
		101,
		3080704
	},

	{
		"gefenia01",
		17393,
		300,
		1204,
		"Tirfing",
		"TIRFING",
		114,
		4391168
	},

	{
		"gefenia01",
		17475,
		300,
		1268,
		"Bloody Knight",
		"BLOODY_KNIGHT",
		116,
		5702144
	},

	{
		"gefenia02",
		16988,
		300,
		1292,
		"Mini Demon",
		"MINI_DEMON",
		117,
		1769478
	},

	{
		"gefenia02",
		16989,
		300,
		1390,
		"Violy",
		"VIOLY",
		118,
		2621703
	},

	{
		"gefenia02",
		16990,
		300,
		1370,
		"Succubus",
		"SUCCUBUS",
		119,
		4391174
	},

	{
		"gefenia02",
		16991,
		300,
		1219,
		"Knight of Abyss",
		"KNIGHT_OF_ABYSS",
		122,
		5702151
	},

	{
		"gefenia02",
		16992,
		300,
		1374,
		"Incubus",
		"INCUBUS",
		120,
		4391174
	},

	{
		"gefenia02",
		16993,
		300,
		1371,
		"Fake Angel",
		"FAKE_ANGEL",
		105,
		4325384
	},

	{
		"gefenia02",
		17384,
		300,
		1203,
		"Mysteltainn",
		"MYSTELTAINN",
		130,
		5702144
	},

	{
		"gefenia02",
		17390,
		300,
		1205,
		"Executioner",
		"EXECUTIONER",
		101,
		3080704
	},

	{
		"gefenia02",
		17394,
		300,
		1204,
		"Tirfing",
		"TIRFING",
		114,
		4391168
	},

	{
		"gefenia02",
		17476,
		300,
		1268,
		"Bloody Knight",
		"BLOODY_KNIGHT",
		116,
		5702144
	},

	{
		"gefenia03",
		16994,
		300,
		1292,
		"Mini Demon",
		"MINI_DEMON",
		117,
		1769478
	},

	{
		"gefenia03",
		16995,
		300,
		1390,
		"Violy",
		"VIOLY",
		118,
		2621703
	},

	{
		"gefenia03",
		16996,
		300,
		1370,
		"Succubus",
		"SUCCUBUS",
		119,
		4391174
	},

	{
		"gefenia03",
		16997,
		300,
		1219,
		"Knight of Abyss",
		"KNIGHT_OF_ABYSS",
		122,
		5702151
	},

	{
		"gefenia03",
		16998,
		300,
		1374,
		"Incubus",
		"INCUBUS",
		120,
		4391174
	},

	{
		"gefenia03",
		16999,
		300,
		1371,
		"Fake Angel",
		"FAKE_ANGEL",
		105,
		4325384
	},

	{
		"gefenia03",
		17385,
		300,
		1203,
		"Mysteltainn",
		"MYSTELTAINN",
		130,
		5702144
	},

	{
		"gefenia03",
		17391,
		300,
		1205,
		"Executioner",
		"EXECUTIONER",
		101,
		3080704
	},

	{
		"gefenia03",
		17395,
		300,
		1204,
		"Tirfing",
		"TIRFING",
		114,
		4391168
	},

	{
		"gefenia03",
		17477,
		300,
		1268,
		"Bloody Knight",
		"BLOODY_KNIGHT",
		116,
		5702144
	},

	{
		"gefenia04",
		17000,
		300,
		1292,
		"Mini Demon",
		"MINI_DEMON",
		117,
		1769478
	},

	{
		"gefenia04",
		17001,
		300,
		1390,
		"Violy",
		"VIOLY",
		118,
		2621703
	},

	{
		"gefenia04",
		17002,
		300,
		1370,
		"Succubus",
		"SUCCUBUS",
		119,
		4391174
	},

	{
		"gefenia04",
		17003,
		300,
		1219,
		"Knight of Abyss",
		"KNIGHT_OF_ABYSS",
		122,
		5702151
	},

	{
		"gefenia04",
		17004,
		300,
		1374,
		"Incubus",
		"INCUBUS",
		120,
		4391174
	},

	{
		"gefenia04",
		17005,
		300,
		1371,
		"Fake Angel",
		"FAKE_ANGEL",
		105,
		4325384
	},

	{
		"gefenia04",
		17386,
		300,
		1203,
		"Mysteltainn",
		"MYSTELTAINN",
		130,
		5702144
	},

	{
		"gefenia04",
		17392,
		300,
		1205,
		"Executioner",
		"EXECUTIONER",
		101,
		3080704
	},

	{
		"gefenia04",
		17396,
		300,
		1204,
		"Tirfing",
		"TIRFING",
		114,
		4391168
	},

	{
		"gefenia04",
		17478,
		300,
		1268,
		"Bloody Knight",
		"BLOODY_KNIGHT",
		116,
		5702144
	},

	{
		"gl_cas01",
		16927,
		300,
		1260,
		"Dark Frame",
		"DARK_FRAME",
		76,
		4391174
	},

	{
		"gl_cas01",
		16928,
		300,
		1195,
		"Rideword",
		"RIDEWORD",
		74,
		3932160
	},

	{
		"gl_cas01",
		16929,
		300,
		1281,
		"Sage Worm",
		"SAGEWORM",
		70,
		3932162
	},

	{
		"gl_cas01",
		16930,
		300,
		1320,
		"Owl Duke",
		"OWL_DUKE",
		92,
		3932678
	},

	{
		"gl_cas01",
		16931,
		300,
		1295,
		"Owl Baron",
		"OWL_BARON",
		120,
		3932678
	},

	{
		"gl_cas01",
		16932,
		300,
		1275,
		"Alice",
		"ALICE",
		100,
		3932423
	},

	{
		"gl_cas01",
		16933,
		300,
		1179,
		"Whisper",
		"WHISPER",
		46,
		4456454
	},

	{
		"gl_cas01",
		16934,
		300,
		1267,
		"Carat",
		"CARAT",
		103,
		2883846
	},

	{
		"gl_cas02",
		16935,
		300,
		1195,
		"Rideword",
		"RIDEWORD",
		74,
		3932160
	},

	{
		"gl_cas02",
		16936,
		300,
		1163,
		"Raydric",
		"RAYDRIC",
		115,
		3080711
	},

	{
		"gl_cas02",
		16937,
		300,
		1276,
		"Raydric Archer",
		"RAYDRIC_ARCHER",
		82,
		3080454
	},

	{
		"gl_cas02",
		16938,
		300,
		1191,
		"Mimic",
		"MIMIC",
		56,
		3932416
	},

	{
		"gl_cas02",
		16939,
		300,
		1208,
		"Wander Man",
		"WANDER_MAN",
		120,
		1573126
	},

	{
		"gl_cas02",
		16940,
		300,
		1219,
		"Knight of Abyss",
		"KNIGHT_OF_ABYSS",
		122,
		5702151
	},

	{
		"gl_cas02",
		16941,
		300,
		1275,
		"Alice",
		"ALICE",
		100,
		3932423
	},

	{
		"gl_cas02",
		16942,
		300,
		1185,
		"Whisper",
		"WHISPER_",
		34,
		1835009
	},

	{
		"gl_cas02",
		16943,
		300,
		1117,
		"Evil Druid",
		"EVIL_DRUID",
		80,
		5833217
	},

	{
		"gl_cas02",
		16944,
		300,
		1132,
		"Khalitzburg",
		"KHALITZBURG",
		118,
		1901057
	},

	{
		"gl_cas02",
		16945,
		300,
		1283,
		"Chimera",
		"CHIMERA",
		70,
		4129282
	},

	{
		"gl_cas02",
		17387,
		300,
		1203,
		"Mysteltainn",
		"MYSTELTAINN",
		130,
		5702144
	},

	{
		"gl_cas02",
		17397,
		300,
		1204,
		"Tirfing",
		"TIRFING",
		114,
		4391168
	},

	{
		"gl_church",
		16639,
		300,
		1192,
		"Wraith",
		"WRAITH",
		77,
		5833217
	},

	{
		"gl_church",
		16640,
		300,
		1191,
		"Mimic",
		"MIMIC",
		56,
		3932416
	},

	{
		"gl_church",
		16641,
		300,
		1117,
		"Evil Druid",
		"EVIL_DRUID",
		80,
		5833217
	},

	{
		"gl_church",
		16643,
		300,
		1291,
		"Wraith Dead",
		"WRAITH_DEAD",
		121,
		5833217
	},

	{
		"gl_chyard",
		16644,
		300,
		1198,
		"Dark Priest",
		"DARK_PRIEST",
		98,
		5832966
	},

	{
		"gl_chyard",
		16645,
		300,
		1192,
		"Wraith",
		"WRAITH",
		77,
		5833217
	},

	{
		"gl_chyard",
		16646,
		300,
		1191,
		"Mimic",
		"MIMIC",
		56,
		3932416
	},

	{
		"gl_chyard",
		16647,
		300,
		1117,
		"Evil Druid",
		"EVIL_DRUID",
		80,
		5833217
	},

	{
		"gl_chyard",
		16648,
		300,
		1035,
		"Hunter Fly",
		"HUNTER_FLY",
		63,
		2883588
	},

	{
		"gl_chyard",
		16649,
		300,
		1302,
		"Dark Illusion",
		"DARK_ILLUSION",
		96,
		5833222
	},

	{
		"gl_chyard",
		17213,
		301,
		1272,
		"Dark Lord",
		"DARK_LORD",
		96,
		5833222
	},

	{
		"gl_dun01",
		16819,
		300,
		1207,
		"Sting",
		"STING",
		104,
		4063488
	},

	{
		"gl_dun01",
		16820,
		300,
		1194,
		"Arclouse",
		"ARCLOUSE",
		107,
		2752772
	},

	{
		"gl_dun02",
		16821,
		300,
		1253,
		"Gargoyle",
		"GARGOYLE",
		100,
		4194566
	},

	{
		"gl_dun02",
		16822,
		300,
		1310,
		"Majoruros",
		"MAJORUROS",
		107,
		2818562
	},

	{
		"gl_in01",
		16611,
		300,
		1260,
		"Dark Frame",
		"DARK_FRAME",
		76,
		4391174
	},

	{
		"gl_in01",
		16612,
		300,
		1195,
		"Rideword",
		"RIDEWORD",
		74,
		3932160
	},

	{
		"gl_in01",
		16613,
		300,
		1143,
		"Marionette",
		"MARIONETTE",
		90,
		4456454
	},

	{
		"gl_in01",
		16614,
		300,
		1208,
		"Wander Man",
		"WANDER_MAN",
		120,
		1573126
	},

	{
		"gl_in01",
		16615,
		300,
		1281,
		"Sage Worm",
		"SAGEWORM",
		70,
		3932162
	},

	{
		"gl_in01",
		16616,
		300,
		1275,
		"Alice",
		"ALICE",
		100,
		3932423
	},

	{
		"gl_knt01",
		16946,
		300,
		1084,
		"Black Mushroom",
		"BLACK_MUSHROOM",
		1,
		1441795
	},

	{
		"gl_knt01",
		16947,
		300,
		1195,
		"Rideword",
		"RIDEWORD",
		74,
		3932160
	},

	{
		"gl_knt01",
		16948,
		300,
		1163,
		"Raydric",
		"RAYDRIC",
		115,
		3080711
	},

	{
		"gl_knt01",
		16949,
		300,
		1276,
		"Raydric Archer",
		"RAYDRIC_ARCHER",
		82,
		3080454
	},

	{
		"gl_knt01",
		16950,
		300,
		1219,
		"Knight of Abyss",
		"KNIGHT_OF_ABYSS",
		122,
		5702151
	},

	{
		"gl_knt01",
		16951,
		300,
		1275,
		"Alice",
		"ALICE",
		100,
		3932423
	},

	{
		"gl_knt01",
		16952,
		300,
		1132,
		"Khalitzburg",
		"KHALITZBURG",
		118,
		1901057
	},

	{
		"gl_knt01",
		17253,
		300,
		1186,
		"Giant Whisper",
		"WHISPER_BOSS",
		66,
		3145734
	},

	{
		"gl_knt02",
		16953,
		300,
		1163,
		"Raydric",
		"RAYDRIC",
		115,
		3080711
	},

	{
		"gl_knt02",
		16954,
		300,
		1276,
		"Raydric Archer",
		"RAYDRIC_ARCHER",
		82,
		3080454
	},

	{
		"gl_knt02",
		16955,
		300,
		1219,
		"Knight of Abyss",
		"KNIGHT_OF_ABYSS",
		122,
		5702151
	},

	{
		"gl_knt02",
		16956,
		300,
		1275,
		"Alice",
		"ALICE",
		100,
		3932423
	},

	{
		"gl_knt02",
		16957,
		300,
		1132,
		"Khalitzburg",
		"KHALITZBURG",
		118,
		1901057
	},

	{
		"gl_knt02",
		17388,
		300,
		1203,
		"Mysteltainn",
		"MYSTELTAINN",
		130,
		5702144
	},

	{
		"gl_knt02",
		17479,
		300,
		1268,
		"Bloody Knight",
		"BLOODY_KNIGHT",
		116,
		5702144
	},

	{
		"gl_prison",
		16772,
		300,
		1201,
		"Rybio",
		"RYBIO",
		98,
		2621958
	},

	{
		"gl_prison",
		16773,
		300,
		1257,
		"Injustice",
		"INJUSTICE",
		95,
		3080449
	},

	{
		"gl_prison",
		16774,
		300,
		1197,
		"Zombie Prisoner",
		"ZOMBIE_PRISONER",
		89,
		4522241
	},

	{
		"gl_prison",
		16775,
		300,
		1035,
		"Hunter Fly",
		"HUNTER_FLY",
		63,
		2883588
	},

	{
		"gl_prison1",
		16776,
		300,
		1201,
		"Rybio",
		"RYBIO",
		98,
		2621958
	},

	{
		"gl_prison1",
		16777,
		300,
		1196,
		"Skeleton Prisoner",
		"SKEL_PRISONER",
		91,
		4522241
	},

	{
		"gl_prison1",
		16778,
		300,
		1257,
		"Injustice",
		"INJUSTICE",
		95,
		3080449
	},

	{
		"gl_prison1",
		16779,
		300,
		1209,
		"Cramp",
		"CRAMP",
		82,
		2949122
	},

	{
		"gl_prison1",
		16780,
		300,
		1202,
		"Phendark",
		"PHENDARK",
		102,
		2621959
	},

	{
		"gl_prison1",
		16781,
		300,
		1035,
		"Hunter Fly",
		"HUNTER_FLY",
		63,
		2883588
	},

	{
		"gl_prison1",
		17471,
		300,
		1200,
		"Zherlthsh",
		"ZHERLTHSH",
		105,
		3932423
	},

	{
		"gl_sew01",
		16823,
		300,
		1253,
		"Gargoyle",
		"GARGOYLE",
		100,
		4194566
	},

	{
		"gl_sew01",
		16824,
		300,
		1194,
		"Arclouse",
		"ARCLOUSE",
		107,
		2752772
	},

	{
		"gl_sew01",
		16825,
		300,
		1179,
		"Whisper",
		"WHISPER",
		46,
		4456454
	},

	{
		"gl_sew02",
		16826,
		300,
		1253,
		"Gargoyle",
		"GARGOYLE",
		100,
		4194566
	},

	{
		"gl_sew02",
		16827,
		300,
		1209,
		"Cramp",
		"CRAMP",
		82,
		2949122
	},

	{
		"gl_sew03",
		16828,
		300,
		1253,
		"Gargoyle",
		"GARGOYLE",
		100,
		4194566
	},

	{
		"gl_sew03",
		16829,
		300,
		1207,
		"Sting",
		"STING",
		104,
		4063488
	},

	{
		"gl_sew04",
		16830,
		300,
		1253,
		"Gargoyle",
		"GARGOYLE",
		100,
		4194566
	},

	{
		"gl_sew04",
		16831,
		300,
		1111,
		"Drainliar",
		"DRAINLIAR",
		47,
		3080194
	},

	{
		"gl_sew04",
		16832,
		300,
		1206,
		"Anolian",
		"ANOLIAN",
		109,
		2687237
	},

	{
		"gl_step",
		16617,
		300,
		1276,
		"Raydric Archer",
		"RAYDRIC_ARCHER",
		82,
		3080454
	},

	{
		"gl_step",
		16618,
		300,
		1191,
		"Mimic",
		"MIMIC",
		56,
		3932416
	},

	{
		"gl_step",
		16619,
		300,
		1263,
		"Wind Ghost",
		"WIND_GHOST",
		80,
		4194566
	},

	{
		"glast_01",
		17171,
		300,
		1253,
		"Gargoyle",
		"GARGOYLE",
		100,
		4194566
	},

	{
		"glast_01",
		17172,
		300,
		1219,
		"Knight of Abyss",
		"KNIGHT_OF_ABYSS",
		122,
		5702151
	},

	{
		"glast_01",
		17173,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"glast_01",
		17174,
		300,
		1079,
		"Blue Plant",
		"BLUE_PLANT",
		1,
		1441795
	},

	{
		"gld_dun01",
		17327,
		300,
		1290,
		"Skeleton General",
		"SKELETON_GENERAL",
		139,
		1900801
	},

	{
		"gld_dun01",
		17328,
		300,
		1301,
		"Am Mut",
		"AM_MUT",
		141,
		1769478
	},

	{
		"gld_dun01",
		17329,
		300,
		1307,
		"Cat o' Nine Tails",
		"CAT_O_NINE_TAIL",
		79,
		4129030
	},

	{
		"gld_dun01",
		17330,
		300,
		1309,
		"Gajomart",
		"GAJOMART",
		140,
		5439488
	},

	{
		"gld_dun01",
		17331,
		301,
		1115,
		"Eddga",
		"EDDGA",
		65,
		1507842
	},

	{
		"gld_dun01",
		17332,
		300,
		1092,
		"Vagabond Wolf",
		"VAGABOND_WOLF",
		93,
		1442050
	},

	{
		"gld_dun02",
		17333,
		300,
		1295,
		"Owl Baron",
		"OWL_BARON",
		120,
		3932678
	},

	{
		"gld_dun02",
		17334,
		300,
		1304,
		"Giant Spider",
		"GIANT_SPIDER",
		117,
		1638916
	},

	{
		"gld_dun02",
		17335,
		300,
		1305,
		"Ancient Worm",
		"ANCIENT_WORM",
		121,
		1638916
	},

	{
		"gld_dun02",
		17336,
		300,
		1294,
		"Killer Mantis",
		"KILLER_MANTIS",
		141,
		1442052
	},

	{
		"gld_dun02",
		17337,
		300,
		1303,
		"Giant Hornet",
		"GIANT_HONET",
		120,
		1572868
	},

	{
		"gld_dun02",
		17338,
		301,
		1046,
		"Doppelganger",
		"DOPPELGANGER",
		77,
		4391174
	},

	{
		"gld_dun03",
		17339,
		300,
		1289,
		"Maya Purple",
		"MAYA_PUPLE",
		81,
		5374468
	},

	{
		"gld_dun03",
		17340,
		300,
		1300,
		"Caterpillar",
		"CATERPILLAR",
		121,
		1441796
	},

	{
		"gld_dun03",
		17341,
		300,
		1311,
		"Gullinbursti",
		"GULLINBURSTI",
		120,
		2753026
	},

	{
		"gld_dun03",
		17342,
		300,
		1293,
		"Creamy Fear",
		"CREMY_FEAR",
		117,
		1572868
	},

	{
		"gld_dun03",
		17343,
		300,
		1306,
		"Leib Olmai",
		"LEIB_OLMAI",
		118,
		1442306
	},

	{
		"gld_dun03",
		17344,
		301,
		1147,
		"Maya",
		"MAYA",
		55,
		5374468
	},

	{
		"gld_dun04",
		17345,
		300,
		1291,
		"Wraith Dead",
		"WRAITH_DEAD",
		121,
		5833217
	},

	{
		"gld_dun04",
		17346,
		300,
		1292,
		"Mini Demon",
		"MINI_DEMON",
		117,
		1769478
	},

	{
		"gld_dun04",
		17347,
		300,
		1298,
		"Zombie Master",
		"ZOMBIE_MASTER",
		119,
		1900801
	},

	{
		"gld_dun04",
		17348,
		300,
		1302,
		"Dark Illusion",
		"DARK_ILLUSION",
		96,
		5833222
	},

	{
		"gld_dun04",
		17349,
		301,
		1272,
		"Dark Lord",
		"DARK_LORD",
		96,
		5833222
	},

	{
		"gld_dun04",
		17350,
		300,
		1120,
		"Ghostring",
		"GHOSTRING",
		90,
		5767430
	},

	{
		"gon_dun01",
		16713,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"gon_dun01",
		16714,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"gon_dun01",
		16715,
		300,
		1410,
		"Live Peach Tree",
		"LIVE_PEACH_TREE",
		92,
		2752771
	},

	{
		"gon_dun01",
		16716,
		300,
		1417,
		"Zipper Bear",
		"ZIPPER_BEAR",
		90,
		1769730
	},

	{
		"gon_dun01",
		16717,
		300,
		1082,
		"White Plant",
		"WHITE_PLANT",
		1,
		1441795
	},

	{
		"gon_dun01",
		16718,
		300,
		1408,
		"Bloody Butterfly",
		"BLOOD_BUTTERFLY",
		94,
		2883844
	},

	{
		"gon_dun02",
		16719,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"gon_dun02",
		16720,
		300,
		1410,
		"Live Peach Tree",
		"LIVE_PEACH_TREE",
		92,
		2752771
	},

	{
		"gon_dun02",
		16721,
		300,
		1415,
		"Baby Leopard",
		"BABY_LEOPARD",
		68,
		1835010
	},

	{
		"gon_dun02",
		16722,
		300,
		1412,
		"Evil Cloud Hermit",
		"EVIL_CLOUD_HERMIT",
		96,
		2621952
	},

	{
		"gon_dun02",
		16723,
		300,
		1408,
		"Bloody Butterfly",
		"BLOOD_BUTTERFLY",
		94,
		2883844
	},

	{
		"gon_dun03",
		16724,
		300,
		1413,
		"Wild Ginseng",
		"WILD_GINSENG",
		90,
		2818051
	},

	{
		"gon_dun03",
		16725,
		300,
		1416,
		"Wicked Nymph",
		"WICKED_NYMPH",
		97,
		4391174
	},

	{
		"gon_dun03",
		16726,
		300,
		1412,
		"Evil Cloud Hermit",
		"EVIL_CLOUD_HERMIT",
		96,
		2621952
	},

	{
		"gon_dun03",
		16727,
		300,
		1082,
		"White Plant",
		"WHITE_PLANT",
		1,
		1441795
	},

	{
		"gon_dun03",
		17214,
		301,
		1418,
		"Evil Snake Lord",
		"DARK_SNAKE_LORD",
		105,
		4456962
	},

	{
		"gon_fild01",
		16291,
		300,
		1409,
		"Rice Cake Boy",
		"RICE_CAKE_BOY",
		60,
		1310727
	},

	{
		"gon_fild01",
		16292,
		300,
		1415,
		"Baby Leopard",
		"BABY_LEOPARD",
		68,
		1835010
	},

	{
		"gon_fild01",
		16293,
		300,
		1037,
		"Side Winder",
		"SIDE_WINDER",
		70,
		1638658
	},

	{
		"gon_fild01",
		17579,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"gon_fild01",
		17580,
		300,
		1083,
		"Shining Plant",
		"SHINING_PLANT",
		1,
		1703939
	},

	{
		"hu_fild01",
		16189,
		300,
		1715,
		"Novus",
		"NOVUS",
		90,
		1310729
	},

	{
		"hu_fild01",
		16190,
		300,
		1718,
		"Novus",
		"NOVUS_",
		84,
		1310729
	},

	{
		"hu_fild01",
		16191,
		300,
		1368,
		"Geographer",
		"GEOGRAPHER",
		73,
		4063491
	},

	{
		"hu_fild01",
		16192,
		300,
		1721,
		"Dragon Egg",
		"DRAGON_EGG",
		119,
		2621705
	},

	{
		"hu_fild02",
		16193,
		300,
		1715,
		"Novus",
		"NOVUS",
		90,
		1310729
	},

	{
		"hu_fild02",
		16194,
		300,
		1718,
		"Novus",
		"NOVUS_",
		84,
		1310729
	},

	{
		"hu_fild02",
		16195,
		300,
		1368,
		"Geographer",
		"GEOGRAPHER",
		73,
		4063491
	},

	{
		"hu_fild02",
		16196,
		300,
		1721,
		"Dragon Egg",
		"DRAGON_EGG",
		119,
		2621705
	},

	{
		"hu_fild02",
		17359,
		300,
		1259,
		"Gryphon",
		"GRYPHON",
		105,
		5505538
	},

	{
		"hu_fild04",
		16197,
		300,
		1718,
		"Novus",
		"NOVUS_",
		84,
		1310729
	},

	{
		"hu_fild04",
		16198,
		300,
		1721,
		"Dragon Egg",
		"DRAGON_EGG",
		119,
		2621705
	},

	{
		"hu_fild04",
		16199,
		300,
		1368,
		"Geographer",
		"GEOGRAPHER",
		73,
		4063491
	},

	{
		"hu_fild04",
		17570,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"hu_fild04",
		17571,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"hu_fild04",
		17572,
		300,
		1079,
		"Blue Plant",
		"BLUE_PLANT",
		1,
		1441795
	},

	{
		"hu_fild05",
		16200,
		300,
		1718,
		"Novus",
		"NOVUS_",
		84,
		1310729
	},

	{
		"hu_fild05",
		16201,
		300,
		1721,
		"Dragon Egg",
		"DRAGON_EGG",
		119,
		2621705
	},

	{
		"hu_fild06",
		16202,
		300,
		1074,
		"Shellfish",
		"SHELLFISH",
		50,
		1376261
	},

	{
		"hu_fild06",
		16203,
		300,
		1073,
		"Crab",
		"CRAB",
		43,
		1376261
	},

	{
		"hu_fild06",
		16204,
		300,
		1266,
		"Aster",
		"ASTER",
		50,
		1441797
	},

	{
		"hu_fild06",
		17574,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"hu_fild06",
		17575,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"ice_dun01",
		16806,
		300,
		1778,
		"Gazeti",
		"GAZETI",
		106,
		1376518
	},

	{
		"ice_dun01",
		16807,
		300,
		1782,
		"Roween",
		"ROWEEN",
		95,
		1573122
	},

	{
		"ice_dun01",
		16808,
		300,
		1780,
		"Muscipular",
		"MUSCIPULAR",
		105,
		1442051
	},

	{
		"ice_dun01",
		16809,
		300,
		1776,
		"Siroma",
		"SIROMA",
		98,
		3997696
	},

	{
		"ice_dun02",
		16810,
		300,
		1778,
		"Gazeti",
		"GAZETI",
		106,
		1376518
	},

	{
		"ice_dun02",
		16811,
		300,
		1789,
		"Iceicle",
		"ICEICLE",
		100,
		2686976
	},

	{
		"ice_dun02",
		16812,
		300,
		1775,
		"Snowier",
		"SNOWIER",
		103,
		2687488
	},

	{
		"ice_dun02",
		16813,
		300,
		1776,
		"Siroma",
		"SIROMA",
		98,
		3997696
	},

	{
		"ice_dun02",
		16814,
		300,
		1777,
		"Ice Titan",
		"ICE_TITAN",
		110,
		3998208
	},

	{
		"ice_dun02",
		18854,
		300,
		2077,
		"Skogul",
		"S_SKOGUL",
		105,
		4391174
	},

	{
		"ice_dun03",
		16815,
		300,
		1778,
		"Gazeti",
		"GAZETI",
		106,
		1376518
	},

	{
		"ice_dun03",
		16816,
		300,
		1789,
		"Iceicle",
		"ICEICLE",
		100,
		2686976
	},

	{
		"ice_dun03",
		16817,
		300,
		1775,
		"Snowier",
		"SNOWIER",
		103,
		2687488
	},

	{
		"ice_dun03",
		16818,
		300,
		1777,
		"Ice Titan",
		"ICE_TITAN",
		110,
		3998208
	},

	{
		"in_sphinx1",
		16620,
		300,
		1111,
		"Drainliar",
		"DRAINLIAR",
		47,
		3080194
	},

	{
		"in_sphinx1",
		16621,
		300,
		1164,
		"Requiem",
		"REQUIEM",
		71,
		1769735
	},

	{
		"in_sphinx1",
		16622,
		300,
		1146,
		"Matyr",
		"MATYR",
		58,
		1769730
	},

	{
		"in_sphinx1",
		16623,
		300,
		1178,
		"Zerom",
		"ZEROM",
		70,
		1507591
	},

	{
		"in_sphinx2",
		16624,
		300,
		1111,
		"Drainliar",
		"DRAINLIAR",
		47,
		3080194
	},

	{
		"in_sphinx2",
		16625,
		300,
		1164,
		"Requiem",
		"REQUIEM",
		71,
		1769735
	},

	{
		"in_sphinx2",
		16626,
		300,
		1146,
		"Matyr",
		"MATYR",
		58,
		1769730
	},

	{
		"in_sphinx2",
		16627,
		300,
		1178,
		"Zerom",
		"ZEROM",
		70,
		1507591
	},

	{
		"in_sphinx3",
		16628,
		300,
		1140,
		"Marduk",
		"MARDUK",
		73,
		1507847
	},

	{
		"in_sphinx3",
		16629,
		300,
		1146,
		"Matyr",
		"MATYR",
		58,
		1769730
	},

	{
		"in_sphinx3",
		16630,
		300,
		1191,
		"Mimic",
		"MIMIC",
		56,
		3932416
	},

	{
		"in_sphinx3",
		16631,
		300,
		1154,
		"Pasana",
		"PASANA",
		79,
		2818311
	},

	{
		"in_sphinx4",
		16632,
		300,
		1149,
		"Minorous",
		"MINOROUS",
		58,
		2818562
	},

	{
		"in_sphinx4",
		16633,
		300,
		1191,
		"Mimic",
		"MIMIC",
		56,
		3932416
	},

	{
		"in_sphinx4",
		16634,
		300,
		1154,
		"Pasana",
		"PASANA",
		79,
		2818311
	},

	{
		"in_sphinx4",
		17380,
		300,
		1098,
		"Anubis",
		"ANUBIS",
		105,
		3211783
	},

	{
		"in_sphinx5",
		16635,
		300,
		1146,
		"Matyr",
		"MATYR",
		58,
		1769730
	},

	{
		"in_sphinx5",
		16636,
		300,
		1191,
		"Mimic",
		"MIMIC",
		56,
		3932416
	},

	{
		"in_sphinx5",
		16637,
		300,
		1037,
		"Side Winder",
		"SIDE_WINDER",
		70,
		1638658
	},

	{
		"in_sphinx5",
		16638,
		300,
		1154,
		"Pasana",
		"PASANA",
		79,
		2818311
	},

	{
		"in_sphinx5",
		17215,
		301,
		1157,
		"Pharaoh",
		"PHARAOH",
		85,
		4391431
	},

	{
		"in_sphinx5",
		17381,
		300,
		1098,
		"Anubis",
		"ANUBIS",
		105,
		3211783
	},

	{
		"iz_dun00",
		16497,
		300,
		1084,
		"Black Mushroom",
		"BLACK_MUSHROOM",
		1,
		1441795
	},

	{
		"iz_dun00",
		16498,
		300,
		1141,
		"Marina",
		"MARINA",
		42,
		2686979
	},

	{
		"iz_dun00",
		16499,
		300,
		1066,
		"Vadon",
		"VADON",
		45,
		1376261
	},

	{
		"iz_dun00",
		16500,
		300,
		1070,
		"Kukre",
		"KUKRE",
		42,
		1376261
	},

	{
		"iz_dun00",
		16501,
		300,
		1161,
		"Plankton",
		"PLANKTON",
		40,
		3997699
	},

	{
		"iz_dun00",
		16502,
		300,
		1068,
		"Hydra",
		"HYDRA",
		34,
		2686979
	},

	{
		"iz_dun01",
		16503,
		300,
		1084,
		"Black Mushroom",
		"BLACK_MUSHROOM",
		1,
		1441795
	},

	{
		"iz_dun01",
		16504,
		300,
		1141,
		"Marina",
		"MARINA",
		42,
		2686979
	},

	{
		"iz_dun01",
		16505,
		300,
		1066,
		"Vadon",
		"VADON",
		45,
		1376261
	},

	{
		"iz_dun01",
		16506,
		300,
		1067,
		"Cornutus",
		"CORNUTUS",
		48,
		1376261
	},

	{
		"iz_dun01",
		16507,
		300,
		1070,
		"Kukre",
		"KUKRE",
		42,
		1376261
	},

	{
		"iz_dun01",
		16508,
		300,
		1161,
		"Plankton",
		"PLANKTON",
		40,
		3997699
	},

	{
		"iz_dun01",
		16509,
		300,
		1068,
		"Hydra",
		"HYDRA",
		34,
		2686979
	},

	{
		"iz_dun02",
		16510,
		300,
		1084,
		"Black Mushroom",
		"BLACK_MUSHROOM",
		1,
		1441795
	},

	{
		"iz_dun02",
		16511,
		300,
		1144,
		"Marse",
		"MARSE",
		47,
		2686981
	},

	{
		"iz_dun02",
		16512,
		300,
		1264,
		"Merman",
		"MERMAN",
		60,
		3997959
	},

	{
		"iz_dun02",
		16513,
		300,
		1044,
		"Obeaune",
		"OBEAUNE",
		53,
		2687237
	},

	{
		"iz_dun02",
		16514,
		300,
		1067,
		"Cornutus",
		"CORNUTUS",
		48,
		1376261
	},

	{
		"iz_dun02",
		16515,
		300,
		1068,
		"Hydra",
		"HYDRA",
		34,
		2686979
	},

	{
		"iz_dun03",
		16516,
		300,
		1045,
		"Marc",
		"MARC",
		56,
		2687237
	},

	{
		"iz_dun03",
		16517,
		300,
		1142,
		"Marine Sphere",
		"MARINE_SPHERE",
		51,
		2686979
	},

	{
		"iz_dun03",
		16518,
		300,
		1264,
		"Merman",
		"MERMAN",
		60,
		3997959
	},

	{
		"iz_dun03",
		16519,
		300,
		1069,
		"Swordfish",
		"SWORD_FISH",
		57,
		2687493
	},

	{
		"iz_dun03",
		16520,
		300,
		1158,
		"Phen",
		"PHEN",
		52,
		2687237
	},

	{
		"iz_dun03",
		16521,
		300,
		1068,
		"Hydra",
		"HYDRA",
		34,
		2686979
	},

	{
		"iz_dun04",
		16522,
		300,
		1108,
		"Deviace",
		"DEVIACE",
		60,
		5308677
	},

	{
		"iz_dun04",
		16523,
		300,
		1142,
		"Marine Sphere",
		"MARINE_SPHERE",
		51,
		2686979
	},

	{
		"iz_dun04",
		16524,
		300,
		1264,
		"Merman",
		"MERMAN",
		60,
		3997959
	},

	{
		"iz_dun04",
		16525,
		300,
		1069,
		"Swordfish",
		"SWORD_FISH",
		57,
		2687493
	},

	{
		"iz_dun04",
		16526,
		300,
		1065,
		"Strouf",
		"STROUF",
		61,
		3998213
	},

	{
		"iz_dun04",
		16527,
		300,
		1068,
		"Hydra",
		"HYDRA",
		34,
		2686979
	},

	{
		"iz_ng01",
		19090,
		300,
		1031,
		"Poporing",
		"POPORING",
		30,
		1638659
	},

	{
		"jawaii_in",
		17412,
		300,
		1085,
		"Red Mushroom",
		"RED_MUSHROOM",
		1,
		1441795
	},

	{
		"job3_gen01",
		18929,
		300,
		1428,
		"Poison Spore",
		"G_POISON_SPORE",
		26,
		1638659
	},

	{
		"job_monk",
		18641,
		300,
		1182,
		"Thief Mushroom",
		"THIEF_MUSHROOM",
		1,
		1441795
	},

	{
		"jupe_core",
		16906,
		300,
		1670,
		"Dimik",
		"DIMIK_1",
		116,
		2883840
	},

	{
		"jupe_core",
		16907,
		300,
		1671,
		"Dimik",
		"DIMIK_2",
		116,
		2687232
	},

	{
		"jupe_core",
		16908,
		300,
		1672,
		"Dimik",
		"DIMIK_3",
		116,
		2752768
	},

	{
		"jupe_core",
		16909,
		300,
		1673,
		"Dimik",
		"DIMIK_4",
		116,
		2818304
	},

	{
		"jupe_core",
		16910,
		300,
		1676,
		"Venatu",
		"VENATU_1",
		113,
		2621696
	},

	{
		"jupe_core",
		16911,
		300,
		1677,
		"Venatu",
		"VENATU_2",
		113,
		2883840
	},

	{
		"jupe_core",
		16912,
		300,
		1678,
		"Venatu",
		"VENATU_3",
		113,
		2752768
	},

	{
		"jupe_core",
		16913,
		300,
		1668,
		"Archdam",
		"ARCHDAM",
		119,
		3932679
	},

	{
		"jupe_core",
		17216,
		301,
		1685,
		"Vesper",
		"APOCALIPS_H",
		128,
		3015170
	},

	{
		"jupe_core2",
		18785,
		300,
		2053,
		"Dimik",
		"NC_DIMIK",
		77,
		2621696
	},

	{
		"juperos_01",
		16914,
		300,
		1670,
		"Dimik",
		"DIMIK_1",
		116,
		2883840
	},

	{
		"juperos_01",
		16915,
		300,
		1671,
		"Dimik",
		"DIMIK_2",
		116,
		2687232
	},

	{
		"juperos_01",
		16916,
		300,
		1672,
		"Dimik",
		"DIMIK_3",
		116,
		2752768
	},

	{
		"juperos_01",
		16917,
		300,
		1673,
		"Dimik",
		"DIMIK_4",
		116,
		2818304
	},

	{
		"juperos_01",
		16918,
		300,
		1676,
		"Venatu",
		"VENATU_1",
		113,
		2621696
	},

	{
		"juperos_01",
		16919,
		300,
		1677,
		"Venatu",
		"VENATU_2",
		113,
		2883840
	},

	{
		"juperos_01",
		16920,
		300,
		1678,
		"Venatu",
		"VENATU_3",
		113,
		2752768
	},

	{
		"juperos_01",
		16921,
		300,
		1679,
		"Venatu",
		"VENATU_4",
		113,
		2687232
	},

	{
		"juperos_02",
		16922,
		300,
		1676,
		"Venatu",
		"VENATU_1",
		113,
		2621696
	},

	{
		"juperos_02",
		16923,
		300,
		1677,
		"Venatu",
		"VENATU_2",
		113,
		2883840
	},

	{
		"juperos_02",
		16924,
		300,
		1678,
		"Venatu",
		"VENATU_3",
		113,
		2752768
	},

	{
		"juperos_02",
		16925,
		300,
		1679,
		"Venatu",
		"VENATU_4",
		113,
		2687232
	},

	{
		"juperos_02",
		16926,
		300,
		1365,
		"Apocalypse",
		"APOCALIPS",
		121,
		3932672
	},

	{
		"kh_dun01",
		16849,
		300,
		1735,
		"Alicel",
		"ALICEL",
		115,
		3932422
	},

	{
		"kh_dun01",
		16850,
		300,
		1275,
		"Alice",
		"ALICE",
		100,
		3932423
	},

	{
		"kh_dun01",
		16851,
		300,
		1736,
		"Aliot",
		"ALIOT",
		112,
		3932422
	},

	{
		"kh_dun01",
		16852,
		300,
		1737,
		"Aliza",
		"ALIZA",
		112,
		3932423
	},

	{
		"kh_dun01",
		16853,
		300,
		1738,
		"Constant",
		"CONSTANT",
		108,
		4390912
	},

	{
		"kh_dun01",
		16854,
		300,
		1745,
		"Constant",
		"G_CONSTANT",
		108,
		4390918
	},

	{
		"kh_dun02",
		16855,
		300,
		1735,
		"Alicel",
		"ALICEL",
		115,
		3932422
	},

	{
		"kh_dun02",
		16856,
		300,
		1736,
		"Aliot",
		"ALIOT",
		112,
		3932422
	},

	{
		"kh_dun02",
		16857,
		300,
		1737,
		"Aliza",
		"ALIZA",
		112,
		3932423
	},

	{
		"kh_dun02",
		16858,
		300,
		1738,
		"Constant",
		"CONSTANT",
		108,
		4390912
	},

	{
		"kh_dun02",
		16859,
		300,
		1745,
		"Constant",
		"G_CONSTANT",
		108,
		4390918
	},

	{
		"kh_dun02",
		17217,
		301,
		1734,
		"Kiel D-01",
		"KIEL_",
		125,
		3080448
	},

	{
		"kh_kiehl01",
		17301,
		300,
		1745,
		"Constant",
		"G_CONSTANT",
		108,
		4390918
	},

	{
		"kh_kiehl01",
		17302,
		300,
		1740,
		"Aliot",
		"G_ALIOT",
		112,
		3932422
	},

	{
		"kh_kiehl01",
		17303,
		300,
		1746,
		"Aliza",
		"G_ALIZA",
		112,
		3932423
	},

	{
		"kh_kiehl01",
		17304,
		300,
		1739,
		"Alicel",
		"G_ALICEL",
		115,
		3932422
	},

	{
		"lhz_dun01",
		17146,
		300,
		1657,
		"Rawrel",
		"RAWREL",
		133,
		3145991
	},

	{
		"lhz_dun01",
		17147,
		300,
		1682,
		"Removal",
		"REMOVAL",
		121,
		3211521
	},

	{
		"lhz_dun01",
		17148,
		300,
		1613,
		"Metaling",
		"METALING",
		81,
		1310720
	},

	{
		"lhz_dun01",
		17149,
		300,
		1654,
		"Armaia",
		"ARMAIA",
		134,
		4063495
	},

	{
		"lhz_dun01",
		17150,
		300,
		1627,
		"Anopheles",
		"ANOPHELES",
		95,
		4194308
	},

	{
		"lhz_dun01",
		17151,
		300,
		1652,
		"Ygnizem",
		"YGNIZEM",
		136,
		2818311
	},

	{
		"lhz_dun01",
		17152,
		300,
		1655,
		"Erend",
		"EREND",
		133,
		3014919
	},

	{
		"lhz_dun01",
		17153,
		300,
		1681,
		"Gemini-S58",
		"GEMINI",
		135,
		1376512
	},

	{
		"lhz_dun01",
		17154,
		300,
		1656,
		"Kavac",
		"KAVAC",
		135,
		2883847
	},

	{
		"lhz_dun01",
		17155,
		300,
		1653,
		"Whikebain",
		"WHIKEBAIN",
		132,
		4260103
	},

	{
		"lhz_dun02",
		17156,
		300,
		1657,
		"Rawrel",
		"RAWREL",
		133,
		3145991
	},

	{
		"lhz_dun02",
		17157,
		300,
		1682,
		"Removal",
		"REMOVAL",
		121,
		3211521
	},

	{
		"lhz_dun02",
		17158,
		300,
		1654,
		"Armaia",
		"ARMAIA",
		134,
		4063495
	},

	{
		"lhz_dun02",
		17159,
		300,
		1635,
		"Eremes",
		"EREMES",
		140,
		5570822
	},

	{
		"lhz_dun02",
		17160,
		300,
		1652,
		"Ygnizem",
		"YGNIZEM",
		136,
		2818311
	},

	{
		"lhz_dun02",
		17161,
		300,
		1655,
		"Erend",
		"EREND",
		133,
		3014919
	},

	{
		"lhz_dun02",
		17162,
		300,
		1681,
		"Gemini-S58",
		"GEMINI",
		135,
		1376512
	},

	{
		"lhz_dun02",
		17163,
		300,
		1656,
		"Kavac",
		"KAVAC",
		135,
		2883847
	},

	{
		"lhz_dun02",
		17164,
		300,
		1653,
		"Whikebain",
		"WHIKEBAIN",
		132,
		4260103
	},

	{
		"lhz_dun02",
		17218,
		301,
		1658,
		"Ygnizem",
		"B_YGNIZEM",
		141,
		2818311
	},

	{
		"lhz_dun03",
		17165,
		300,
		1637,
		"Magaleta",
		"MAGALETA",
		140,
		4325639
	},

	{
		"lhz_dun03",
		17166,
		300,
		1634,
		"Seyren",
		"SEYREN",
		142,
		4129030
	},

	{
		"lhz_dun03",
		17167,
		300,
		1638,
		"Shecil",
		"SHECIL",
		141,
		4194567
	},

	{
		"lhz_dun03",
		17168,
		300,
		1635,
		"Eremes",
		"EREMES",
		140,
		5570822
	},

	{
		"lhz_dun03",
		17169,
		300,
		1639,
		"Katrinn",
		"KATRINN",
		141,
		4456711
	},

	{
		"lhz_dun03",
		17170,
		300,
		1636,
		"Harword",
		"HARWORD",
		142,
		5308679
	},

	{
		"lhz_dun03",
		17353,
		300,
		1643,
		"High Priest Magaleta",
		"G_MAGALETA",
		160,
		5636359
	},

	{
		"lhz_dun03",
		17354,
		300,
		1640,
		"Lord Knight Seyren",
		"G_SEYREN",
		160,
		5439751
	},

	{
		"lhz_dun03",
		17355,
		300,
		1644,
		"Sniper Shecil",
		"G_SHECIL",
		160,
		5505287
	},

	{
		"lhz_dun03",
		17356,
		300,
		1641,
		"Assassin Cross Eremes",
		"G_EREMES",
		160,
		5570823
	},

	{
		"lhz_dun03",
		17357,
		300,
		1645,
		"High Wizard Katrinn",
		"G_KATRINN",
		160,
		4456711
	},

	{
		"lhz_dun03",
		17358,
		300,
		1642,
		"Whitesmith Harword",
		"G_HARWORD",
		160,
		5374215
	},

	{
		"lhz_fild01",
		16226,
		300,
		1162,
		"Rafflesia",
		"RAFFLESIA",
		86,
		1441795
	},

	{
		"lhz_fild01",
		16227,
		300,
		1215,
		"Stem Worm",
		"STEM_WORM",
		84,
		1573123
	},

	{
		"lhz_fild01",
		16228,
		300,
		1613,
		"Metaling",
		"METALING",
		81,
		1310720
	},

	{
		"lhz_fild01",
		17563,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"lhz_fild01",
		17564,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"lhz_fild01",
		17565,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"lhz_fild02",
		16229,
		300,
		1215,
		"Stem Worm",
		"STEM_WORM",
		84,
		1573123
	},

	{
		"lhz_fild02",
		16230,
		300,
		1692,
		"Breeze",
		"BREEZE",
		92,
		4194560
	},

	{
		"lhz_fild02",
		16231,
		300,
		1162,
		"Rafflesia",
		"RAFFLESIA",
		86,
		1441795
	},

	{
		"lhz_fild02",
		16232,
		300,
		1613,
		"Metaling",
		"METALING",
		81,
		1310720
	},

	{
		"lhz_fild02",
		17361,
		300,
		1378,
		"Demon Pungus",
		"DEMON_PUNGUS",
		91,
		4259846
	},

	{
		"lhz_fild02",
		17566,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"lhz_fild02",
		17567,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"lhz_fild03",
		16233,
		300,
		1692,
		"Breeze",
		"BREEZE",
		92,
		4194560
	},

	{
		"lhz_fild03",
		16234,
		300,
		1215,
		"Stem Worm",
		"STEM_WORM",
		84,
		1573123
	},

	{
		"lhz_fild03",
		16235,
		300,
		1162,
		"Rafflesia",
		"RAFFLESIA",
		86,
		1441795
	},

	{
		"lhz_fild03",
		16236,
		300,
		1613,
		"Metaling",
		"METALING",
		81,
		1310720
	},

	{
		"lhz_fild03",
		17362,
		300,
		1378,
		"Demon Pungus",
		"DEMON_PUNGUS",
		91,
		4259846
	},

	{
		"lhz_fild03",
		17568,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"lhz_fild03",
		17569,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"lhz_in01",
		12458,
		300,
		1085,
		"Red Mushroom",
		"RED_MUSHROOM",
		1,
		1441795
	},

	{
		"lou_dun01",
		16684,
		300,
		1084,
		"Black Mushroom",
		"BLACK_MUSHROOM",
		1,
		1441795
	},

	{
		"lou_dun01",
		16685,
		300,
		1381,
		"Grizzly",
		"GRIZZLY",
		66,
		4129282
	},

	{
		"lou_dun01",
		16686,
		300,
		1083,
		"Shining Plant",
		"SHINING_PLANT",
		1,
		1703939
	},

	{
		"lou_dun01",
		16687,
		300,
		1037,
		"Side Winder",
		"SIDE_WINDER",
		70,
		1638658
	},

	{
		"lou_dun01",
		16688,
		300,
		1516,
		"Increase Soil",
		"INCREASE_SOIL",
		83,
		4063488
	},

	{
		"lou_dun01",
		16689,
		300,
		1517,
		"Li Me Mang Ryang",
		"LI_ME_MANG_RYANG",
		80,
		4063494
	},

	{
		"lou_dun01",
		16690,
		300,
		1129,
		"Horong",
		"HORONG",
		66,
		5439488
	},

	{
		"lou_dun01",
		17246,
		300,
		1306,
		"Leib Olmai",
		"LEIB_OLMAI",
		118,
		1442306
	},

	{
		"lou_dun02",
		16691,
		300,
		1026,
		"Munak",
		"MUNAK",
		58,
		1900801
	},

	{
		"lou_dun02",
		16692,
		300,
		1191,
		"Mimic",
		"MIMIC",
		56,
		3932416
	},

	{
		"lou_dun02",
		16693,
		300,
		1514,
		"Dancing Dragon",
		"DANCING_DRAGON",
		82,
		2883849
	},

	{
		"lou_dun02",
		16694,
		300,
		1512,
		"Hyegun",
		"HYEGUN",
		87,
		3211521
	},

	{
		"lou_dun03",
		16695,
		300,
		1513,
		"Civil Servant",
		"CIVIL_SERVANT",
		89,
		2883842
	},

	{
		"lou_dun03",
		16696,
		300,
		1514,
		"Dancing Dragon",
		"DANCING_DRAGON",
		82,
		2883849
	},

	{
		"lou_dun03",
		16697,
		300,
		1631,
		"Chung E",
		"CHUNG_E_",
		82,
		2883847
	},

	{
		"lou_dun03",
		16698,
		300,
		1512,
		"Hyegun",
		"HYEGUN",
		87,
		3211521
	},

	{
		"lou_dun03",
		17219,
		301,
		1630,
		"Bacsojin",
		"BACSOJIN_",
		97,
		4194823
	},

	{
		"lou_fild01",
		16298,
		300,
		1516,
		"Increase Soil",
		"INCREASE_SOIL",
		83,
		4063488
	},

	{
		"lou_fild01",
		16299,
		300,
		1139,
		"Mantis",
		"MANTIS",
		65,
		1442052
	},

	{
		"lou_fild01",
		16300,
		300,
		1368,
		"Geographer",
		"GEOGRAPHER",
		73,
		4063491
	},

	{
		"lou_fild01",
		17578,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"mag_dun01",
		16782,
		300,
		1381,
		"Grizzly",
		"GRIZZLY",
		66,
		4129282
	},

	{
		"mag_dun01",
		16783,
		300,
		1366,
		"Lava Golem",
		"LAVA_GOLEM",
		103,
		5440000
	},

	{
		"mag_dun01",
		16784,
		300,
		1367,
		"Blazer",
		"BLAZZER",
		101,
		2818310
	},

	{
		"mag_dun01",
		16785,
		300,
		1383,
		"Explosion",
		"EXPLOSION",
		100,
		4128770
	},

	{
		"mag_dun01",
		16786,
		300,
		1072,
		"Kaho",
		"KAHO",
		98,
		5439750
	},

	{
		"mag_dun02",
		16787,
		300,
		1387,
		"Gig",
		"GIG",
		100,
		2818050
	},

	{
		"mag_dun02",
		16788,
		300,
		1379,
		"Nightmare Terror",
		"NIGHTMARE_TERROR",
		107,
		4391430
	},

	{
		"mag_dun02",
		16789,
		300,
		1382,
		"Diabolic",
		"DIABOLIC",
		104,
		3080198
	},

	{
		"mag_dun02",
		16790,
		300,
		1384,
		"Deleter",
		"DELETER",
		105,
		2818313
	},

	{
		"mag_dun02",
		16792,
		300,
		1367,
		"Blazer",
		"BLAZZER",
		101,
		2818310
	},

	{
		"man_fild01",
		17186,
		300,
		1988,
		"Nepenthes",
		"NEPENTHES",
		114,
		2949379
	},

	{
		"man_fild01",
		17187,
		300,
		1989,
		"Hillslion",
		"HILLSRION",
		123,
		1441794
	},

	{
		"man_fild01",
		17188,
		300,
		1999,
		"Centipede Larva",
		"CENTIPEDE_LARVA",
		118,
		1638404
	},

	{
		"man_fild01",
		17189,
		300,
		1987,
		"Centipede",
		"CENTIPEDE",
		125,
		2949380
	},

	{
		"man_fild02",
		17178,
		300,
		2024,
		"Bradium Golem",
		"BRADIUM_GOLEM",
		133,
		2753024
	},

	{
		"man_fild02",
		17179,
		300,
		1987,
		"Centipede",
		"CENTIPEDE",
		125,
		2949380
	},

	{
		"man_fild02",
		17180,
		300,
		1986,
		"Tatacho",
		"TATACHO",
		128,
		1442050
	},

	{
		"man_fild03",
		17190,
		300,
		1989,
		"Hillslion",
		"HILLSRION",
		123,
		1441794
	},

	{
		"man_fild03",
		17191,
		300,
		1986,
		"Tatacho",
		"TATACHO",
		128,
		1442050
	},

	{
		"man_fild03",
		17192,
		300,
		1987,
		"Centipede",
		"CENTIPEDE",
		125,
		2949380
	},

	{
		"man_fild03",
		17193,
		300,
		1990,
		"Hardrock Mammoth",
		"HARDROCK_MOMMOTH",
		137,
		4063746
	},

	{
		"mjo_dun01",
		16440,
		300,
		1145,
		"Martin",
		"MARTIN",
		39,
		2752514
	},

	{
		"mjo_dun01",
		16441,
		300,
		1175,
		"Tarou",
		"TAROU",
		22,
		1769474
	},

	{
		"mjo_dun01",
		16442,
		300,
		1005,
		"Familiar",
		"FARMILIAR",
		24,
		1769474
	},

	{
		"mjo_dun02",
		16443,
		300,
		1121,
		"Giearth",
		"GIEARTH",
		42,
		1441798
	},

	{
		"mjo_dun02",
		16444,
		300,
		1111,
		"Drainliar",
		"DRAINLIAR",
		47,
		3080194
	},

	{
		"mjo_dun02",
		16445,
		300,
		1145,
		"Martin",
		"MARTIN",
		39,
		2752514
	},

	{
		"mjo_dun02",
		16446,
		300,
		1169,
		"Skeleton Worker",
		"SKEL_WORKER",
		44,
		1900801
	},

	{
		"mjo_dun03",
		16447,
		300,
		1121,
		"Giearth",
		"GIEARTH",
		42,
		1441798
	},

	{
		"mjo_dun03",
		16448,
		300,
		1145,
		"Martin",
		"MARTIN",
		39,
		2752514
	},

	{
		"mjo_dun03",
		16449,
		300,
		1151,
		"Myst",
		"MYST",
		49,
		1638912
	},

	{
		"mjo_dun03",
		16450,
		300,
		1169,
		"Skeleton Worker",
		"SKEL_WORKER",
		44,
		1900801
	},

	{
		"mjo_dun03",
		16451,
		300,
		1209,
		"Cramp",
		"CRAMP",
		82,
		2949122
	},

	{
		"mjolnir_01",
		16004,
		300,
		1174,
		"Stainer",
		"STAINER",
		21,
		1572868
	},

	{
		"mjolnir_01",
		16005,
		300,
		1018,
		"Creamy",
		"CREAMY",
		23,
		1572868
	},

	{
		"mjolnir_01",
		16006,
		300,
		1103,
		"Caramel",
		"CARAMEL",
		25,
		1441794
	},

	{
		"mjolnir_01",
		16007,
		300,
		1060,
		"Bigfoot",
		"BIGFOOT",
		29,
		1442306
	},

	{
		"mjolnir_02",
		16033,
		300,
		1031,
		"Poporing",
		"POPORING",
		30,
		1638659
	},

	{
		"mjolnir_02",
		16034,
		300,
		1128,
		"Horn",
		"HORN",
		32,
		1442052
	},

	{
		"mjolnir_02",
		16035,
		300,
		1033,
		"Elder Willow",
		"ELDER_WILOW",
		34,
		2818307
	},

	{
		"mjolnir_02",
		16036,
		300,
		1057,
		"Yoyo",
		"YOYO",
		38,
		1441794
	},

	{
		"mjolnir_03",
		16129,
		300,
		1380,
		"Driller",
		"DRILLER",
		65,
		1442050
	},

	{
		"mjolnir_03",
		16130,
		300,
		1139,
		"Mantis",
		"MANTIS",
		65,
		1442052
	},

	{
		"mjolnir_03",
		16131,
		300,
		1037,
		"Side Winder",
		"SIDE_WINDER",
		70,
		1638658
	},

	{
		"mjolnir_04",
		16132,
		300,
		1380,
		"Driller",
		"DRILLER",
		65,
		1442050
	},

	{
		"mjolnir_04",
		16133,
		300,
		1139,
		"Mantis",
		"MANTIS",
		65,
		1442052
	},

	{
		"mjolnir_04",
		16134,
		300,
		1037,
		"Side Winder",
		"SIDE_WINDER",
		70,
		1638658
	},

	{
		"mjolnir_04",
		17220,
		301,
		1059,
		"Mistress",
		"MISTRESS",
		78,
		5505028
	},

	{
		"mjolnir_05",
		16135,
		300,
		1099,
		"Argiope",
		"ARGIOPE",
		75,
		1638916
	},

	{
		"mjolnir_05",
		16136,
		300,
		1139,
		"Mantis",
		"MANTIS",
		65,
		1442052
	},

	{
		"mjolnir_05",
		16137,
		300,
		1380,
		"Driller",
		"DRILLER",
		65,
		1442050
	},

	{
		"mjolnir_06",
		16008,
		300,
		1018,
		"Creamy",
		"CREAMY",
		23,
		1572868
	},

	{
		"mjolnir_06",
		16009,
		300,
		1077,
		"Poison Spore",
		"POISON_SPORE",
		26,
		1638659
	},

	{
		"mjolnir_06",
		16010,
		300,
		1056,
		"Smokie",
		"SMOKIE",
		29,
		1441794
	},

	{
		"mjolnir_06",
		17437,
		300,
		1085,
		"Red Mushroom",
		"RED_MUSHROOM",
		1,
		1441795
	},

	{
		"mjolnir_07",
		16093,
		300,
		1494,
		"Beetle King",
		"KIND_OF_BEETLE",
		55,
		1441796
	},

	{
		"mjolnir_07",
		16094,
		300,
		1166,
		"Savage",
		"SAVAGE",
		59,
		2753026
	},

	{
		"mjolnir_07",
		16095,
		300,
		1118,
		"Flora",
		"FLORA",
		59,
		1442307
	},

	{
		"mjolnir_07",
		17445,
		300,
		1085,
		"Red Mushroom",
		"RED_MUSHROOM",
		1,
		1441795
	},

	{
		"mjolnir_08",
		16096,
		300,
		1494,
		"Beetle King",
		"KIND_OF_BEETLE",
		55,
		1441796
	},

	{
		"mjolnir_08",
		16097,
		300,
		1166,
		"Savage",
		"SAVAGE",
		59,
		2753026
	},

	{
		"mjolnir_08",
		16098,
		300,
		1118,
		"Flora",
		"FLORA",
		59,
		1442307
	},

	{
		"mjolnir_09",
		15982,
		300,
		1010,
		"Willow",
		"WILOW",
		8,
		1442051
	},

	{
		"mjolnir_09",
		15983,
		300,
		1004,
		"Hornet",
		"HORNET",
		11,
		1572868
	},

	{
		"mjolnir_09",
		15984,
		300,
		1167,
		"Savage Babe",
		"SAVAGE_BABE",
		14,
		1441794
	},

	{
		"mjolnir_09",
		17447,
		300,
		1085,
		"Red Mushroom",
		"RED_MUSHROOM",
		1,
		1441795
	},

	{
		"mjolnir_10",
		16056,
		300,
		1494,
		"Beetle King",
		"KIND_OF_BEETLE",
		55,
		1441796
	},

	{
		"mjolnir_10",
		16057,
		300,
		1118,
		"Flora",
		"FLORA",
		59,
		1442307
	},

	{
		"mjolnir_10",
		16058,
		300,
		1100,
		"Argos",
		"ARGOS",
		47,
		1638916
	},

	{
		"mjolnir_11",
		16138,
		300,
		1099,
		"Argiope",
		"ARGIOPE",
		75,
		1638916
	},

	{
		"mjolnir_11",
		16139,
		300,
		1100,
		"Argos",
		"ARGOS",
		47,
		1638916
	},

	{
		"mjolnir_11",
		16140,
		300,
		1118,
		"Flora",
		"FLORA",
		59,
		1442307
	},

	{
		"mjolnir_12",
		16126,
		300,
		1114,
		"Dustiness",
		"DUSTINESS",
		62,
		2883588
	},

	{
		"mjolnir_12",
		16127,
		300,
		1035,
		"Hunter Fly",
		"HUNTER_FLY",
		63,
		2883588
	},

	{
		"mjolnir_12",
		16128,
		300,
		1139,
		"Mantis",
		"MANTIS",
		65,
		1442052
	},

	{
		"moc_fild01",
		16019,
		300,
		1055,
		"Muka",
		"MUKA",
		23,
		1442307
	},

	{
		"moc_fild01",
		16020,
		300,
		1047,
		"Peco Peco Egg",
		"PECOPECO_EGG",
		7,
		3932160
	},

	{
		"moc_fild01",
		16021,
		300,
		1019,
		"Peco Peco",
		"PECOPECO",
		25,
		1507842
	},

	{
		"moc_fild01",
		17655,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"moc_fild02",
		16022,
		300,
		1055,
		"Muka",
		"MUKA",
		23,
		1442307
	},

	{
		"moc_fild02",
		16023,
		300,
		1047,
		"Peco Peco Egg",
		"PECOPECO_EGG",
		7,
		3932160
	},

	{
		"moc_fild02",
		16024,
		300,
		1019,
		"Peco Peco",
		"PECOPECO",
		25,
		1507842
	},

	{
		"moc_fild02",
		17656,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"moc_fild02",
		17663,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"moc_fild03",
		16085,
		300,
		1013,
		"Wolf",
		"WOLF",
		45,
		1442050
	},

	{
		"moc_fild03",
		16086,
		300,
		1100,
		"Argos",
		"ARGOS",
		47,
		1638916
	},

	{
		"moc_fild03",
		16087,
		300,
		1042,
		"Steel Chonchon",
		"STEEL_CHONCHON",
		48,
		1572868
	},

	{
		"moc_fild03",
		17679,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"moc_fild07",
		15958,
		300,
		1113,
		"Drops",
		"DROPS",
		2,
		1507587
	},

	{
		"moc_fild07",
		15959,
		300,
		1011,
		"Chonchon",
		"CHONCHON",
		5,
		1572868
	},

	{
		"moc_fild07",
		15960,
		300,
		1047,
		"Peco Peco Egg",
		"PECOPECO_EGG",
		7,
		3932160
	},

	{
		"moc_fild07",
		15961,
		300,
		1049,
		"Picky",
		"PICKY",
		9,
		1507330
	},

	{
		"moc_fild07",
		15962,
		300,
		1050,
		"Picky",
		"PICKY_",
		10,
		1507330
	},

	{
		"moc_fild07",
		17654,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"moc_fild11",
		15989,
		300,
		1009,
		"Condor",
		"CONDOR",
		12,
		1573122
	},

	{
		"moc_fild11",
		15990,
		300,
		1107,
		"Desert Wolf Baby",
		"DESERT_WOLF_B",
		14,
		1507330
	},

	{
		"moc_fild11",
		15991,
		300,
		1001,
		"Scorpion",
		"SCORPION",
		16,
		1507332
	},

	{
		"moc_fild12",
		15963,
		300,
		1113,
		"Drops",
		"DROPS",
		2,
		1507587
	},

	{
		"moc_fild12",
		15964,
		300,
		1047,
		"Peco Peco Egg",
		"PECOPECO_EGG",
		7,
		3932160
	},

	{
		"moc_fild12",
		15965,
		300,
		1049,
		"Picky",
		"PICKY",
		9,
		1507330
	},

	{
		"moc_fild12",
		15966,
		300,
		1050,
		"Picky",
		"PICKY_",
		10,
		1507330
	},

	{
		"moc_fild12",
		15967,
		300,
		1009,
		"Condor",
		"CONDOR",
		12,
		1573122
	},

	{
		"moc_fild12",
		17686,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"moc_fild13",
		16088,
		300,
		1013,
		"Wolf",
		"WOLF",
		45,
		1442050
	},

	{
		"moc_fild13",
		16089,
		300,
		1100,
		"Argos",
		"ARGOS",
		47,
		1638916
	},

	{
		"moc_fild13",
		16090,
		300,
		1042,
		"Steel Chonchon",
		"STEEL_CHONCHON",
		48,
		1572868
	},

	{
		"moc_fild13",
		16091,
		300,
		1058,
		"Metaller",
		"METALLER",
		55,
		1507588
	},

	{
		"moc_fild13",
		16092,
		300,
		1138,
		"Magnolia",
		"MAGNOLIA",
		53,
		1376262
	},

	{
		"moc_fild13",
		17424,
		300,
		1085,
		"Red Mushroom",
		"RED_MUSHROOM",
		1,
		1441795
	},

	{
		"moc_fild13",
		17670,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"moc_fild16",
		16120,
		300,
		1119,
		"Frilldora",
		"FRILLDORA",
		57,
		1507586
	},

	{
		"moc_fild16",
		16121,
		300,
		1165,
		"Sandman",
		"SAND_MAN",
		61,
		4063488
	},

	{
		"moc_fild16",
		16122,
		300,
		1127,
		"Hode",
		"HODE",
		63,
		2752770
	},

	{
		"moc_fild17",
		16123,
		300,
		1119,
		"Frilldora",
		"FRILLDORA",
		57,
		1507586
	},

	{
		"moc_fild17",
		16124,
		300,
		1165,
		"Sandman",
		"SAND_MAN",
		61,
		4063488
	},

	{
		"moc_fild17",
		16125,
		300,
		1127,
		"Hode",
		"HODE",
		63,
		2752770
	},

	{
		"moc_fild17",
		17221,
		301,
		1159,
		"Phreeoni",
		"PHREEONI",
		71,
		3932674
	},

	{
		"moc_fild17",
		17695,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"moc_fild17",
		17698,
		300,
		1079,
		"Blue Plant",
		"BLUE_PLANT",
		1,
		1441795
	},

	{
		"moc_fild18",
		15992,
		300,
		1009,
		"Condor",
		"CONDOR",
		12,
		1573122
	},

	{
		"moc_fild18",
		15993,
		300,
		1107,
		"Desert Wolf Baby",
		"DESERT_WOLF_B",
		14,
		1507330
	},

	{
		"moc_fild18",
		15994,
		300,
		1001,
		"Scorpion",
		"SCORPION",
		16,
		1507332
	},

	{
		"moc_fild18",
		17480,
		300,
		1091,
		"Dragon Fly",
		"DRAGON_FLY",
		47,
		1572868
	},

	{
		"moc_fild18",
		17687,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"moc_fild20",
		17367,
		300,
		1918,
		"Incarnation of Morroc",
		"MOROCC_1",
		132,
		1769992
	},

	{
		"moc_fild20",
		17370,
		300,
		1919,
		"Incarnation of Morroc",
		"MOROCC_2",
		132,
		4391174
	},

	{
		"moc_fild20",
		17373,
		300,
		1920,
		"Incarnation of Morroc",
		"MOROCC_3",
		133,
		4522246
	},

	{
		"moc_fild20",
		17376,
		300,
		1921,
		"Incarnation of Morroc",
		"MOROCC_4",
		134,
		4456710
	},

	{
		"moc_fild21",
		17368,
		300,
		1918,
		"Incarnation of Morroc",
		"MOROCC_1",
		132,
		1769992
	},

	{
		"moc_fild21",
		17371,
		300,
		1919,
		"Incarnation of Morroc",
		"MOROCC_2",
		132,
		4391174
	},

	{
		"moc_fild21",
		17374,
		300,
		1920,
		"Incarnation of Morroc",
		"MOROCC_3",
		133,
		4522246
	},

	{
		"moc_fild21",
		17377,
		300,
		1921,
		"Incarnation of Morroc",
		"MOROCC_4",
		134,
		4456710
	},

	{
		"moc_fild22",
		17366,
		301,
		1917,
		"Wounded Morroc",
		"MOROCC_",
		151,
		5702150
	},

	{
		"moc_fild22",
		17369,
		300,
		1918,
		"Incarnation of Morroc",
		"MOROCC_1",
		132,
		1769992
	},

	{
		"moc_fild22",
		17372,
		300,
		1919,
		"Incarnation of Morroc",
		"MOROCC_2",
		132,
		4391174
	},

	{
		"moc_fild22",
		17375,
		300,
		1920,
		"Incarnation of Morroc",
		"MOROCC_3",
		133,
		4522246
	},

	{
		"moc_fild22",
		17378,
		300,
		1921,
		"Incarnation of Morroc",
		"MOROCC_4",
		134,
		4456710
	},

	{
		"moc_pryd01",
		16479,
		300,
		1005,
		"Familiar",
		"FARMILIAR",
		24,
		1769474
	},

	{
		"moc_pryd01",
		16480,
		300,
		1031,
		"Poporing",
		"POPORING",
		30,
		1638659
	},

	{
		"moc_pryd02",
		16481,
		300,
		1111,
		"Drainliar",
		"DRAINLIAR",
		47,
		3080194
	},

	{
		"moc_pryd02",
		16482,
		300,
		1041,
		"Mummy",
		"MUMMY",
		55,
		3211521
	},

	{
		"moc_pryd02",
		16483,
		300,
		1028,
		"Soldier Skeleton",
		"SOLDIER_SKELETON",
		34,
		1900801
	},

	{
		"moc_pryd02",
		16484,
		300,
		1016,
		"Archer Skeleton",
		"ARCHER_SKELETON",
		50,
		1900801
	},

	{
		"moc_pryd02",
		16485,
		300,
		1029,
		"Isis",
		"ISIS",
		59,
		1769990
	},

	{
		"moc_pryd02",
		16486,
		300,
		1031,
		"Poporing",
		"POPORING",
		30,
		1638659
	},

	{
		"moc_pryd03",
		16487,
		300,
		1111,
		"Drainliar",
		"DRAINLIAR",
		47,
		3080194
	},

	{
		"moc_pryd03",
		16488,
		300,
		1146,
		"Matyr",
		"MATYR",
		58,
		1769730
	},

	{
		"moc_pryd03",
		16489,
		300,
		1191,
		"Mimic",
		"MIMIC",
		56,
		3932416
	},

	{
		"moc_pryd03",
		16490,
		300,
		1041,
		"Mummy",
		"MUMMY",
		55,
		3211521
	},

	{
		"moc_pryd03",
		16491,
		300,
		1032,
		"Verit",
		"VERIT",
		52,
		1900801
	},

	{
		"moc_pryd04",
		16492,
		300,
		1146,
		"Matyr",
		"MATYR",
		58,
		1769730
	},

	{
		"moc_pryd04",
		16493,
		300,
		1191,
		"Mimic",
		"MIMIC",
		56,
		3932416
	},

	{
		"moc_pryd04",
		16494,
		300,
		1041,
		"Mummy",
		"MUMMY",
		55,
		3211521
	},

	{
		"moc_pryd04",
		16495,
		300,
		1297,
		"Ancient Mummy",
		"ANCIENT_MUMMY",
		114,
		3211521
	},

	{
		"moc_pryd04",
		16496,
		300,
		1029,
		"Isis",
		"ISIS",
		59,
		1769990
	},

	{
		"moc_pryd04",
		17222,
		301,
		1038,
		"Osiris",
		"OSIRIS",
		68,
		5832961
	},

	{
		"moc_pryd05",
		16860,
		300,
		1149,
		"Minorous",
		"MINOROUS",
		58,
		2818562
	},

	{
		"moc_pryd05",
		16861,
		300,
		1041,
		"Mummy",
		"MUMMY",
		55,
		3211521
	},

	{
		"moc_pryd05",
		16862,
		300,
		1032,
		"Verit",
		"VERIT",
		52,
		1900801
	},

	{
		"moc_pryd06",
		16863,
		300,
		1191,
		"Mimic",
		"MIMIC",
		56,
		3932416
	},

	{
		"moc_pryd06",
		16864,
		300,
		1032,
		"Verit",
		"VERIT",
		52,
		1900801
	},

	{
		"moc_pryd06",
		16865,
		300,
		1194,
		"Arclouse",
		"ARCLOUSE",
		107,
		2752772
	},

	{
		"moc_pryd06",
		16866,
		300,
		1297,
		"Ancient Mummy",
		"ANCIENT_MUMMY",
		114,
		3211521
	},

	{
		"moc_pryd06",
		17223,
		301,
		1511,
		"Amon Ra",
		"AMON_RA",
		69,
		4063751
	},

	{
		"monk_test",
		18665,
		300,
		1015,
		"Zombie",
		"ZOMBIE",
		17,
		1900801
	},

	{
		"mosk_dun01",
		16699,
		300,
		1881,
		"Les",
		"LES",
		82,
		5374211
	},

	{
		"mosk_dun01",
		16700,
		300,
		1139,
		"Mantis",
		"MANTIS",
		65,
		1442052
	},

	{
		"mosk_dun01",
		16701,
		300,
		1880,
		"Wood Goblin",
		"WOOD_GOBLIN",
		81,
		4063491
	},

	{
		"mosk_dun01",
		16702,
		300,
		1031,
		"Poporing",
		"POPORING",
		30,
		1638659
	},

	{
		"mosk_dun02",
		16703,
		300,
		1881,
		"Les",
		"LES",
		82,
		5374211
	},

	{
		"mosk_dun02",
		16704,
		300,
		1882,
		"Baba Yaga",
		"VAVAYAGA",
		87,
		1376519
	},

	{
		"mosk_dun02",
		16705,
		300,
		1880,
		"Wood Goblin",
		"WOOD_GOBLIN",
		81,
		4063491
	},

	{
		"mosk_dun02",
		16706,
		300,
		1883,
		"Uzhas",
		"UZHAS",
		85,
		3997959
	},

	{
		"mosk_dun03",
		16707,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"mosk_dun03",
		16708,
		300,
		1884,
		"Mavka",
		"MAVKA",
		84,
		4063491
	},

	{
		"mosk_dun03",
		16709,
		300,
		1882,
		"Baba Yaga",
		"VAVAYAGA",
		87,
		1376519
	},

	{
		"mosk_dun03",
		16710,
		300,
		1083,
		"Shining Plant",
		"SHINING_PLANT",
		1,
		1703939
	},

	{
		"mosk_dun03",
		16711,
		300,
		1883,
		"Uzhas",
		"UZHAS",
		85,
		3997959
	},

	{
		"mosk_dun03",
		16712,
		300,
		1082,
		"White Plant",
		"WHITE_PLANT",
		1,
		1441795
	},

	{
		"mosk_dun03",
		17224,
		301,
		1885,
		"Gopinich",
		"GOPINICH",
		97,
		4063746
	},

	{
		"mosk_fild02",
		16294,
		300,
		1368,
		"Geographer",
		"GEOGRAPHER",
		73,
		4063491
	},

	{
		"mosk_fild02",
		16295,
		300,
		1037,
		"Side Winder",
		"SIDE_WINDER",
		70,
		1638658
	},

	{
		"mosk_fild02",
		16296,
		300,
		1099,
		"Argiope",
		"ARGIOPE",
		75,
		1638916
	},

	{
		"mosk_fild02",
		16297,
		300,
		1139,
		"Mantis",
		"MANTIS",
		65,
		1442052
	},

	{
		"mosk_fild02",
		17500,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"mosk_fild02",
		17501,
		300,
		1082,
		"White Plant",
		"WHITE_PLANT",
		1,
		1441795
	},

	{
		"nameless_n",
		17110,
		300,
		1036,
		"Ghoul",
		"GHOUL",
		61,
		3211521
	},

	{
		"nameless_n",
		17111,
		300,
		1865,
		"Ragged Zombie",
		"RAGGED_ZOMBIE",
		123,
		4522241
	},

	{
		"nameless_n",
		17112,
		300,
		1867,
		"Banshee",
		"BANSHEE",
		130,
		3080454
	},

	{
		"nameless_n",
		17113,
		300,
		1864,
		"Zombie Slaughter",
		"ZOMBIE_SLAUGHTER",
		124,
		4522241
	},

	{
		"nameless_n",
		17114,
		300,
		1869,
		"Flame Skull",
		"FLAME_SKULL",
		121,
		4456454
	},

	{
		"nameless_n",
		17115,
		300,
		1866,
		"Hell Poodle",
		"HELL_POODLE",
		115,
		1769478
	},

	{
		"nif_fild01",
		16833,
		300,
		1504,
		"Dullahan",
		"DULLAHAN",
		108,
		3211521
	},

	{
		"nif_fild01",
		16834,
		300,
		1506,
		"Disguise",
		"DISGUISE",
		103,
		5374214
	},

	{
		"nif_fild01",
		16835,
		300,
		1503,
		"Gibbet",
		"GIBBET",
		105,
		1769990
	},

	{
		"nif_fild01",
		16836,
		300,
		1508,
		"Quve",
		"QUVE",
		100,
		1900545
	},

	{
		"nif_fild01",
		16837,
		300,
		1510,
		"Hylozoist",
		"HYLOZOIST",
		102,
		3080198
	},

	{
		"nif_fild02",
		16838,
		300,
		1504,
		"Dullahan",
		"DULLAHAN",
		108,
		3211521
	},

	{
		"nif_fild02",
		16839,
		300,
		1505,
		"Loli Ruri",
		"LOLI_RURI",
		109,
		5702150
	},

	{
		"nif_fild02",
		16840,
		300,
		1509,
		"Lude",
		"LUDE",
		101,
		1900545
	},

	{
		"nif_fild02",
		16841,
		300,
		1507,
		"Bloody Murderer",
		"BLOODY_MURDERER",
		110,
		4391431
	},

	{
		"nif_fild02",
		16842,
		300,
		1503,
		"Gibbet",
		"GIBBET",
		105,
		1769990
	},

	{
		"nif_fild02",
		16843,
		300,
		1510,
		"Hylozoist",
		"HYLOZOIST",
		102,
		3080198
	},

	{
		"niflheim",
		16844,
		300,
		1504,
		"Dullahan",
		"DULLAHAN",
		108,
		3211521
	},

	{
		"niflheim",
		16845,
		300,
		1509,
		"Lude",
		"LUDE",
		101,
		1900545
	},

	{
		"niflheim",
		16846,
		300,
		1503,
		"Gibbet",
		"GIBBET",
		105,
		1769990
	},

	{
		"niflheim",
		16847,
		300,
		1508,
		"Quve",
		"QUVE",
		100,
		1900545
	},

	{
		"niflheim",
		16848,
		300,
		1510,
		"Hylozoist",
		"HYLOZOIST",
		102,
		3080198
	},

	{
		"niflheim",
		18855,
		300,
		2078,
		"Succubus",
		"S_SUCCUBUS",
		105,
		4391174
	},

	{
		"nyd_dun01",
		17181,
		300,
		2013,
		"Draco",
		"DRACO",
		114,
		1442057
	},

	{
		"nyd_dun01",
		17182,
		300,
		2016,
		"Aqua Elemental",
		"AQUA_ELEMENTAL",
		121,
		5308928
	},

	{
		"nyd_dun01",
		17183,
		300,
		2015,
		"Dark Pinguicula",
		"PINGUICULA_D",
		113,
		2949379
	},

	{
		"nyd_dun01",
		17184,
		300,
		2017,
		"Rata",
		"RATA",
		131,
		4063495
	},

	{
		"nyd_dun01",
		17185,
		300,
		2018,
		"Duneyrr",
		"DUNEYRR",
		135,
		4063495
	},

	{
		"nyd_dun01",
		17490,
		300,
		2014,
		"Draco Egg",
		"DRACO_EGG",
		101,
		5374217
	},

	{
		"odin_tem01",
		17081,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"odin_tem01",
		17082,
		300,
		1692,
		"Breeze",
		"BREEZE",
		92,
		4194560
	},

	{
		"odin_tem01",
		17083,
		300,
		1752,
		"Skogul",
		"SKOGUL",
		126,
		4391174
	},

	{
		"odin_tem01",
		17084,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"odin_tem01",
		17085,
		300,
		1079,
		"Blue Plant",
		"BLUE_PLANT",
		1,
		1441795
	},

	{
		"odin_tem01",
		17086,
		300,
		1753,
		"Frus",
		"FRUS",
		128,
		4391174
	},

	{
		"odin_tem01",
		17087,
		300,
		1697,
		"Plasma",
		"PLASMA_B",
		115,
		5308416
	},

	{
		"odin_tem01",
		17088,
		300,
		1695,
		"Plasma",
		"PLASMA_G",
		116,
		5373952
	},

	{
		"odin_tem01",
		17089,
		300,
		1696,
		"Plasma",
		"PLASMA_P",
		117,
		5701632
	},

	{
		"odin_tem01",
		17090,
		300,
		1694,
		"Plasma",
		"PLASMA_R",
		118,
		5439488
	},

	{
		"odin_tem01",
		17091,
		300,
		1693,
		"Plasma",
		"PLASMA_Y",
		119,
		5767168
	},

	{
		"odin_tem02",
		17092,
		300,
		1754,
		"Skeggiold",
		"SKEGGIOLD",
		131,
		3014664
	},

	{
		"odin_tem02",
		17094,
		300,
		1752,
		"Skogul",
		"SKOGUL",
		126,
		4391174
	},

	{
		"odin_tem02",
		17096,
		300,
		1079,
		"Blue Plant",
		"BLUE_PLANT",
		1,
		1441795
	},

	{
		"odin_tem02",
		17097,
		300,
		1753,
		"Frus",
		"FRUS",
		128,
		4391174
	},

	{
		"odin_tem02",
		17099,
		300,
		1693,
		"Plasma",
		"PLASMA_Y",
		119,
		5767168
	},

	{
		"odin_tem03",
		17100,
		300,
		1765,
		"Valkyrie",
		"G_RANDGRIS",
		141,
		5636616
	},

	{
		"odin_tem03",
		17101,
		300,
		1083,
		"Shining Plant",
		"SHINING_PLANT",
		1,
		1703939
	},

	{
		"odin_tem03",
		17102,
		300,
		1754,
		"Skeggiold",
		"SKEGGIOLD",
		131,
		3014664
	},

	{
		"odin_tem03",
		17104,
		300,
		1752,
		"Skogul",
		"SKOGUL",
		126,
		4391174
	},

	{
		"odin_tem03",
		17106,
		300,
		1079,
		"Blue Plant",
		"BLUE_PLANT",
		1,
		1441795
	},

	{
		"odin_tem03",
		17107,
		300,
		1753,
		"Frus",
		"FRUS",
		128,
		4391174
	},

	{
		"odin_tem03",
		17109,
		300,
		1693,
		"Plasma",
		"PLASMA_Y",
		119,
		5767168
	},

	{
		"odin_tem03",
		17225,
		301,
		1751,
		"Valkyrie Randgris",
		"RANDGRIS",
		141,
		5636616
	},

	{
		"orcsdun01",
		16465,
		300,
		1084,
		"Black Mushroom",
		"BLACK_MUSHROOM",
		1,
		1441795
	},

	{
		"orcsdun01",
		16466,
		300,
		1111,
		"Drainliar",
		"DRAINLIAR",
		47,
		3080194
	},

	{
		"orcsdun01",
		16467,
		300,
		1042,
		"Steel Chonchon",
		"STEEL_CHONCHON",
		48,
		1572868
	},

	{
		"orcsdun01",
		16468,
		300,
		1152,
		"Orc Skeleton",
		"ORC_SKELETON",
		53,
		1900801
	},

	{
		"orcsdun01",
		16469,
		300,
		1153,
		"Orc Zombie",
		"ORC_ZOMBIE",
		51,
		1900801
	},

	{
		"orcsdun01",
		16470,
		300,
		1005,
		"Familiar",
		"FARMILIAR",
		24,
		1769474
	},

	{
		"orcsdun01",
		16471,
		300,
		1082,
		"White Plant",
		"WHITE_PLANT",
		1,
		1441795
	},

	{
		"orcsdun02",
		16472,
		300,
		1084,
		"Black Mushroom",
		"BLACK_MUSHROOM",
		1,
		1441795
	},

	{
		"orcsdun02",
		16473,
		300,
		1111,
		"Drainliar",
		"DRAINLIAR",
		47,
		3080194
	},

	{
		"orcsdun02",
		16474,
		300,
		1042,
		"Steel Chonchon",
		"STEEL_CHONCHON",
		48,
		1572868
	},

	{
		"orcsdun02",
		16475,
		300,
		1152,
		"Orc Skeleton",
		"ORC_SKELETON",
		53,
		1900801
	},

	{
		"orcsdun02",
		16476,
		300,
		1189,
		"Orc Archer",
		"ORC_ARCHER",
		78,
		1442055
	},

	{
		"orcsdun02",
		16477,
		300,
		1177,
		"Zenorc",
		"ZENORC",
		54,
		1769735
	},

	{
		"orcsdun02",
		16478,
		300,
		1082,
		"White Plant",
		"WHITE_PLANT",
		1,
		1441795
	},

	{
		"pay_dun00",
		16557,
		300,
		1084,
		"Black Mushroom",
		"BLACK_MUSHROOM",
		1,
		1441795
	},

	{
		"pay_dun00",
		16558,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"pay_dun00",
		16559,
		300,
		1076,
		"Skeleton",
		"SKELETON",
		27,
		1900801
	},

	{
		"pay_dun00",
		16560,
		300,
		1015,
		"Zombie",
		"ZOMBIE",
		17,
		1900801
	},

	{
		"pay_dun00",
		16561,
		300,
		1005,
		"Familiar",
		"FARMILIAR",
		24,
		1769474
	},

	{
		"pay_dun00",
		16562,
		300,
		1031,
		"Poporing",
		"POPORING",
		30,
		1638659
	},

	{
		"pay_dun01",
		16563,
		300,
		1084,
		"Black Mushroom",
		"BLACK_MUSHROOM",
		1,
		1441795
	},

	{
		"pay_dun01",
		16564,
		300,
		1111,
		"Drainliar",
		"DRAINLIAR",
		47,
		3080194
	},

	{
		"pay_dun01",
		16565,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"pay_dun01",
		16566,
		300,
		1028,
		"Soldier Skeleton",
		"SOLDIER_SKELETON",
		34,
		1900801
	},

	{
		"pay_dun01",
		16567,
		300,
		1016,
		"Archer Skeleton",
		"ARCHER_SKELETON",
		50,
		1900801
	},

	{
		"pay_dun01",
		16568,
		300,
		1116,
		"Eggyra",
		"EGGYRA",
		53,
		3145984
	},

	{
		"pay_dun02",
		16569,
		300,
		1084,
		"Black Mushroom",
		"BLACK_MUSHROOM",
		1,
		1441795
	},

	{
		"pay_dun02",
		16570,
		300,
		1180,
		"Nine Tail",
		"NINE_TAIL",
		72,
		4129026
	},

	{
		"pay_dun02",
		16571,
		300,
		1020,
		"Mandragora",
		"MANDRAGORA",
		13,
		4063491
	},

	{
		"pay_dun02",
		16572,
		300,
		1026,
		"Munak",
		"MUNAK",
		58,
		1900801
	},

	{
		"pay_dun02",
		16573,
		300,
		1188,
		"Bongun",
		"BON_GUN",
		59,
		1900801
	},

	{
		"pay_dun02",
		16574,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"pay_dun02",
		16575,
		300,
		1028,
		"Soldier Skeleton",
		"SOLDIER_SKELETON",
		34,
		1900801
	},

	{
		"pay_dun02",
		16576,
		300,
		1016,
		"Archer Skeleton",
		"ARCHER_SKELETON",
		50,
		1900801
	},

	{
		"pay_dun02",
		16577,
		300,
		1031,
		"Poporing",
		"POPORING",
		30,
		1638659
	},

	{
		"pay_dun02",
		16578,
		300,
		1082,
		"White Plant",
		"WHITE_PLANT",
		1,
		1441795
	},

	{
		"pay_dun02",
		16579,
		300,
		1068,
		"Hydra",
		"HYDRA",
		34,
		2686979
	},

	{
		"pay_dun03",
		16580,
		300,
		1180,
		"Nine Tail",
		"NINE_TAIL",
		72,
		4129026
	},

	{
		"pay_dun03",
		16581,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"pay_dun03",
		16582,
		300,
		1020,
		"Mandragora",
		"MANDRAGORA",
		13,
		4063491
	},

	{
		"pay_dun03",
		16583,
		300,
		1026,
		"Munak",
		"MUNAK",
		58,
		1900801
	},

	{
		"pay_dun03",
		16584,
		300,
		1188,
		"Bongun",
		"BON_GUN",
		59,
		1900801
	},

	{
		"pay_dun03",
		16585,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"pay_dun03",
		16586,
		300,
		1170,
		"Sohee",
		"SOHEE",
		64,
		1376518
	},

	{
		"pay_dun03",
		16587,
		300,
		1185,
		"Whisper",
		"WHISPER_",
		34,
		1835009
	},

	{
		"pay_dun03",
		16591,
		300,
		1277,
		"Greatest General",
		"GREATEST_GENERAL",
		55,
		2818304
	},

	{
		"pay_dun03",
		16592,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"pay_dun03",
		16593,
		300,
		1079,
		"Blue Plant",
		"BLUE_PLANT",
		1,
		1441795
	},

	{
		"pay_dun03",
		16594,
		300,
		1082,
		"White Plant",
		"WHITE_PLANT",
		1,
		1441795
	},

	{
		"pay_dun03",
		16595,
		300,
		1068,
		"Hydra",
		"HYDRA",
		34,
		2686979
	},

	{
		"pay_dun03",
		17252,
		300,
		1186,
		"Giant Whisper",
		"WHISPER_BOSS",
		66,
		3145734
	},

	{
		"pay_dun04",
		16596,
		300,
		1180,
		"Nine Tail",
		"NINE_TAIL",
		72,
		4129026
	},

	{
		"pay_dun04",
		16597,
		300,
		1110,
		"Dokebi",
		"DOKEBI",
		68,
		1769478
	},

	{
		"pay_dun04",
		16598,
		300,
		1083,
		"Shining Plant",
		"SHINING_PLANT",
		1,
		1703939
	},

	{
		"pay_dun04",
		16599,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"pay_dun04",
		16600,
		300,
		1016,
		"Archer Skeleton",
		"ARCHER_SKELETON",
		50,
		1900801
	},

	{
		"pay_dun04",
		16601,
		300,
		1277,
		"Greatest General",
		"GREATEST_GENERAL",
		55,
		2818304
	},

	{
		"pay_dun04",
		16602,
		300,
		1082,
		"White Plant",
		"WHITE_PLANT",
		1,
		1441795
	},

	{
		"pay_dun04",
		16603,
		300,
		1129,
		"Horong",
		"HORONG",
		66,
		5439488
	},

	{
		"pay_dun04",
		17226,
		301,
		1150,
		"Moonlight Flower",
		"MOONLIGHT",
		79,
		4129030
	},

	{
		"pay_dun04",
		17238,
		300,
		1301,
		"Am Mut",
		"AM_MUT",
		141,
		1769478
	},

	{
		"pay_dun04",
		17243,
		300,
		1307,
		"Cat o' Nine Tails",
		"CAT_O_NINE_TAIL",
		79,
		4129030
	},

	{
		"pay_dun04",
		17247,
		300,
		1290,
		"Skeleton General",
		"SKELETON_GENERAL",
		139,
		1900801
	},

	{
		"pay_fild01",
		15951,
		300,
		1002,
		"Poring",
		"PORING",
		1,
		1376515
	},

	{
		"pay_fild01",
		15952,
		300,
		1007,
		"Fabre",
		"FABRE",
		6,
		1441796
	},

	{
		"pay_fild01",
		15953,
		300,
		1010,
		"Willow",
		"WILOW",
		8,
		1442051
	},

	{
		"pay_fild01",
		17702,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"pay_fild02",
		15995,
		300,
		1024,
		"Wormtail",
		"WORM_TAIL",
		17,
		1442051
	},

	{
		"pay_fild02",
		15996,
		300,
		1025,
		"Snake",
		"SNAKE",
		18,
		1442050
	},

	{
		"pay_fild02",
		15997,
		300,
		1014,
		"Spore",
		"SPORE",
		18,
		1376515
	},

	{
		"pay_fild02",
		17458,
		300,
		1085,
		"Red Mushroom",
		"RED_MUSHROOM",
		1,
		1441795
	},

	{
		"pay_fild02",
		17706,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"pay_fild03",
		15954,
		300,
		1002,
		"Poring",
		"PORING",
		1,
		1376515
	},

	{
		"pay_fild03",
		15955,
		300,
		1010,
		"Willow",
		"WILOW",
		8,
		1442051
	},

	{
		"pay_fild03",
		15956,
		300,
		1007,
		"Fabre",
		"FABRE",
		6,
		1441796
	},

	{
		"pay_fild03",
		15957,
		300,
		1008,
		"Pupa",
		"PUPA",
		4,
		1441796
	},

	{
		"pay_fild03",
		17459,
		300,
		1085,
		"Red Mushroom",
		"RED_MUSHROOM",
		1,
		1441795
	},

	{
		"pay_fild03",
		17707,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"pay_fild04",
		16025,
		300,
		1002,
		"Poring",
		"PORING",
		1,
		1376515
	},

	{
		"pay_fild04",
		16026,
		300,
		1113,
		"Drops",
		"DROPS",
		2,
		1507587
	},

	{
		"pay_fild04",
		16027,
		300,
		1031,
		"Poporing",
		"POPORING",
		30,
		1638659
	},

	{
		"pay_fild04",
		16028,
		300,
		1242,
		"Marin",
		"MARIN",
		37,
		2687235
	},

	{
		"pay_fild04",
		17400,
		300,
		1582,
		"Deviling",
		"DEVILING",
		66,
		5701894
	},

	{
		"pay_fild04",
		17402,
		300,
		1096,
		"Angeling",
		"ANGELING",
		77,
		5636360
	},

	{
		"pay_fild04",
		17404,
		300,
		1120,
		"Ghostring",
		"GHOSTRING",
		90,
		5767430
	},

	{
		"pay_fild04",
		17407,
		300,
		1090,
		"Mastering",
		"MASTERING",
		42,
		1376515
	},

	{
		"pay_fild04",
		17710,
		300,
		1083,
		"Shining Plant",
		"SHINING_PLANT",
		1,
		1703939
	},

	{
		"pay_fild04",
		17711,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"pay_fild06",
		15998,
		300,
		1024,
		"Wormtail",
		"WORM_TAIL",
		17,
		1442051
	},

	{
		"pay_fild06",
		15999,
		300,
		1025,
		"Snake",
		"SNAKE",
		18,
		1442050
	},

	{
		"pay_fild06",
		16000,
		300,
		1014,
		"Spore",
		"SPORE",
		18,
		1376515
	},

	{
		"pay_fild06",
		17460,
		300,
		1085,
		"Red Mushroom",
		"RED_MUSHROOM",
		1,
		1441795
	},

	{
		"pay_fild06",
		17708,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"pay_fild06",
		17709,
		300,
		1083,
		"Shining Plant",
		"SHINING_PLANT",
		1,
		1703939
	},

	{
		"pay_fild07",
		16029,
		300,
		1174,
		"Stainer",
		"STAINER",
		21,
		1572868
	},

	{
		"pay_fild07",
		16030,
		300,
		1018,
		"Creamy",
		"CREAMY",
		23,
		1572868
	},

	{
		"pay_fild07",
		16031,
		300,
		1103,
		"Caramel",
		"CARAMEL",
		25,
		1441794
	},

	{
		"pay_fild07",
		16032,
		300,
		1060,
		"Bigfoot",
		"BIGFOOT",
		29,
		1442306
	},

	{
		"pay_fild07",
		17705,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"pay_fild08",
		16001,
		300,
		1024,
		"Wormtail",
		"WORM_TAIL",
		17,
		1442051
	},

	{
		"pay_fild08",
		16002,
		300,
		1025,
		"Snake",
		"SNAKE",
		18,
		1442050
	},

	{
		"pay_fild08",
		16003,
		300,
		1014,
		"Spore",
		"SPORE",
		18,
		1376515
	},

	{
		"pay_fild08",
		17703,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"pay_fild08",
		17704,
		300,
		1083,
		"Shining Plant",
		"SHINING_PLANT",
		1,
		1703939
	},

	{
		"pay_fild09",
		16048,
		300,
		1033,
		"Elder Willow",
		"ELDER_WILOW",
		34,
		2818307
	},

	{
		"pay_fild09",
		16049,
		300,
		1128,
		"Horn",
		"HORN",
		32,
		1442052
	},

	{
		"pay_fild09",
		16050,
		300,
		1104,
		"Coco",
		"COCO",
		38,
		1441794
	},

	{
		"pay_fild09",
		17581,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"pay_fild09",
		17582,
		300,
		1083,
		"Shining Plant",
		"SHINING_PLANT",
		1,
		1703939
	},

	{
		"pay_fild10",
		16117,
		300,
		1277,
		"Greatest General",
		"GREATEST_GENERAL",
		55,
		2818304
	},

	{
		"pay_fild10",
		16118,
		300,
		1494,
		"Beetle King",
		"KIND_OF_BEETLE",
		55,
		1441796
	},

	{
		"pay_fild10",
		16119,
		300,
		1166,
		"Savage",
		"SAVAGE",
		59,
		2753026
	},

	{
		"pay_fild10",
		17382,
		301,
		1115,
		"Eddga",
		"EDDGA",
		65,
		1507842
	},

	{
		"pay_fild10",
		17583,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"pay_fild10",
		17586,
		300,
		1079,
		"Blue Plant",
		"BLUE_PLANT",
		1,
		1441795
	},

	{
		"prt_fild00",
		15968,
		300,
		1012,
		"Roda Frog",
		"RODA_FROG",
		13,
		1376517
	},

	{
		"prt_fild00",
		15969,
		300,
		1094,
		"Ambernite",
		"AMBERNITE",
		19,
		1376772
	},

	{
		"prt_fild00",
		15970,
		300,
		1167,
		"Savage Babe",
		"SAVAGE_BABE",
		14,
		1441794
	},

	{
		"prt_fild00",
		17725,
		300,
		1083,
		"Shining Plant",
		"SHINING_PLANT",
		1,
		1703939
	},

	{
		"prt_fild00",
		17726,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"prt_fild01",
		15935,
		300,
		1002,
		"Poring",
		"PORING",
		1,
		1376515
	},

	{
		"prt_fild01",
		15936,
		300,
		1063,
		"Lunatic",
		"LUNATIC",
		3,
		3932162
	},

	{
		"prt_fild01",
		15937,
		300,
		1007,
		"Fabre",
		"FABRE",
		6,
		1441796
	},

	{
		"prt_fild01",
		17716,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"prt_fild01",
		17717,
		300,
		1079,
		"Blue Plant",
		"BLUE_PLANT",
		1,
		1441795
	},

	{
		"prt_fild02",
		16016,
		300,
		1174,
		"Stainer",
		"STAINER",
		21,
		1572868
	},

	{
		"prt_fild02",
		16017,
		300,
		1018,
		"Creamy",
		"CREAMY",
		23,
		1572868
	},

	{
		"prt_fild02",
		16018,
		300,
		1031,
		"Poporing",
		"POPORING",
		30,
		1638659
	},

	{
		"prt_fild02",
		17485,
		300,
		1093,
		"Eclipse",
		"ECLIPSE",
		31,
		3932418
	},

	{
		"prt_fild02",
		17718,
		300,
		1083,
		"Shining Plant",
		"SHINING_PLANT",
		1,
		1703939
	},

	{
		"prt_fild03",
		16037,
		300,
		1031,
		"Poporing",
		"POPORING",
		30,
		1638659
	},

	{
		"prt_fild03",
		16038,
		300,
		1128,
		"Horn",
		"HORN",
		32,
		1442052
	},

	{
		"prt_fild03",
		16039,
		300,
		1057,
		"Yoyo",
		"YOYO",
		38,
		1441794
	},

	{
		"prt_fild03",
		17488,
		300,
		1214,
		"Choco",
		"CHOCO",
		48,
		1507330
	},

	{
		"prt_fild03",
		17720,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"prt_fild03",
		17721,
		300,
		1079,
		"Blue Plant",
		"BLUE_PLANT",
		1,
		1441795
	},

	{
		"prt_fild04",
		15971,
		300,
		1094,
		"Ambernite",
		"AMBERNITE",
		19,
		1376772
	},

	{
		"prt_fild04",
		15972,
		300,
		1012,
		"Roda Frog",
		"RODA_FROG",
		13,
		1376517
	},

	{
		"prt_fild04",
		17483,
		300,
		1088,
		"Vocal",
		"VOCAL",
		18,
		1442052
	},

	{
		"prt_fild04",
		17712,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"prt_fild05",
		15977,
		300,
		1004,
		"Hornet",
		"HORNET",
		11,
		1572868
	},

	{
		"prt_fild05",
		15978,
		300,
		1048,
		"Thief Bug Egg",
		"THIEF_BUG_EGG",
		20,
		1769476
	},

	{
		"prt_fild05",
		15979,
		300,
		1006,
		"Thief Bug Larva",
		"THIEF_BUG_LARVA",
		0,
		0
	},

	{
		"prt_fild05",
		17713,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"prt_fild05",
		17714,
		300,
		1079,
		"Blue Plant",
		"BLUE_PLANT",
		1,
		1441795
	},

	{
		"prt_fild06",
		15938,
		300,
		1002,
		"Poring",
		"PORING",
		1,
		1376515
	},

	{
		"prt_fild06",
		15939,
		300,
		1063,
		"Lunatic",
		"LUNATIC",
		3,
		3932162
	},

	{
		"prt_fild06",
		15940,
		300,
		1007,
		"Fabre",
		"FABRE",
		6,
		1441796
	},

	{
		"prt_fild06",
		17715,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"prt_fild07",
		15980,
		300,
		1167,
		"Savage Babe",
		"SAVAGE_BABE",
		14,
		1441794
	},

	{
		"prt_fild07",
		15981,
		300,
		1052,
		"Rocker",
		"ROCKER",
		15,
		1442052
	},

	{
		"prt_fild07",
		17484,
		300,
		1088,
		"Vocal",
		"VOCAL",
		18,
		1442052
	},

	{
		"prt_fild08",
		15941,
		300,
		1002,
		"Poring",
		"PORING",
		1,
		1376515
	},

	{
		"prt_fild08",
		15942,
		300,
		1063,
		"Lunatic",
		"LUNATIC",
		3,
		3932162
	},

	{
		"prt_fild08",
		15943,
		300,
		1007,
		"Fabre",
		"FABRE",
		6,
		1441796
	},

	{
		"prt_fild09",
		16083,
		300,
		1138,
		"Magnolia",
		"MAGNOLIA",
		53,
		1376262
	},

	{
		"prt_fild09",
		16084,
		300,
		1058,
		"Metaller",
		"METALLER",
		55,
		1507588
	},

	{
		"prt_fild09",
		17727,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"prt_fild10",
		16044,
		300,
		1031,
		"Poporing",
		"POPORING",
		30,
		1638659
	},

	{
		"prt_fild10",
		16045,
		300,
		1128,
		"Horn",
		"HORN",
		32,
		1442052
	},

	{
		"prt_fild10",
		16046,
		300,
		1033,
		"Elder Willow",
		"ELDER_WILOW",
		34,
		2818307
	},

	{
		"prt_fild10",
		16047,
		300,
		1104,
		"Coco",
		"COCO",
		38,
		1441794
	},

	{
		"prt_fild10",
		17461,
		300,
		1085,
		"Red Mushroom",
		"RED_MUSHROOM",
		1,
		1441795
	},

	{
		"prt_fild10",
		17728,
		300,
		1083,
		"Shining Plant",
		"SHINING_PLANT",
		1,
		1703939
	},

	{
		"prt_fild11",
		16099,
		300,
		1258,
		"Goblin Archer",
		"GOBLIN_ARCHER",
		55,
		1638407
	},

	{
		"prt_fild11",
		16100,
		300,
		1122,
		"Goblin",
		"GOBLIN_1",
		48,
		1573127
	},

	{
		"prt_fild11",
		16101,
		300,
		1123,
		"Goblin",
		"GOBLIN_2",
		44,
		1507591
	},

	{
		"prt_fild11",
		16102,
		300,
		1124,
		"Goblin",
		"GOBLIN_3",
		44,
		1638663
	},

	{
		"prt_fild11",
		16103,
		300,
		1125,
		"Goblin",
		"GOBLIN_4",
		49,
		1442055
	},

	{
		"prt_fild11",
		16104,
		300,
		1126,
		"Goblin",
		"GOBLIN_5",
		56,
		1376519
	},

	{
		"prt_fild11",
		16105,
		300,
		1392,
		"Rotar Zairo",
		"ROTAR_ZAIRO",
		48,
		2884096
	},

	{
		"prt_fild11",
		17352,
		300,
		1280,
		"Steam Goblin",
		"STEAM_GOBLIN",
		66,
		2883847
	},

	{
		"prt_fild11",
		17462,
		300,
		1085,
		"Red Mushroom",
		"RED_MUSHROOM",
		1,
		1441795
	},

	{
		"prt_fild11",
		17473,
		300,
		1308,
		"Panzer Goblin",
		"PANZER_GOBLIN",
		52,
		2883847
	},

	{
		"prt_maze01",
		17255,
		300,
		1002,
		"Poring",
		"PORING",
		1,
		1376515
	},

	{
		"prt_maze01",
		17256,
		300,
		1063,
		"Lunatic",
		"LUNATIC",
		3,
		3932162
	},

	{
		"prt_maze01",
		17257,
		300,
		1007,
		"Fabre",
		"FABRE",
		6,
		1441796
	},

	{
		"prt_maze01",
		17258,
		300,
		1018,
		"Creamy",
		"CREAMY",
		23,
		1572868
	},

	{
		"prt_maze01",
		17259,
		300,
		1008,
		"Pupa",
		"PUPA",
		4,
		1441796
	},

	{
		"prt_maze01",
		17260,
		300,
		1031,
		"Poporing",
		"POPORING",
		30,
		1638659
	},

	{
		"prt_maze01",
		17261,
		300,
		1052,
		"Rocker",
		"ROCKER",
		15,
		1442052
	},

	{
		"prt_maze01",
		17262,
		300,
		1060,
		"Bigfoot",
		"BIGFOOT",
		29,
		1442306
	},

	{
		"prt_maze01",
		17263,
		300,
		1056,
		"Smokie",
		"SMOKIE",
		29,
		1441794
	},

	{
		"prt_maze01",
		17264,
		300,
		1025,
		"Snake",
		"SNAKE",
		18,
		1442050
	},

	{
		"prt_maze01",
		17265,
		300,
		1013,
		"Wolf",
		"WOLF",
		45,
		1442050
	},

	{
		"prt_maze01",
		17266,
		300,
		1099,
		"Argiope",
		"ARGIOPE",
		75,
		1638916
	},

	{
		"prt_maze01",
		17267,
		300,
		1100,
		"Argos",
		"ARGOS",
		47,
		1638916
	},

	{
		"prt_maze01",
		17268,
		300,
		1011,
		"Chonchon",
		"CHONCHON",
		5,
		1572868
	},

	{
		"prt_maze01",
		17269,
		300,
		1128,
		"Horn",
		"HORN",
		32,
		1442052
	},

	{
		"prt_maze01",
		17270,
		300,
		1035,
		"Hunter Fly",
		"HUNTER_FLY",
		63,
		2883588
	},

	{
		"prt_maze01",
		17271,
		300,
		1139,
		"Mantis",
		"MANTIS",
		65,
		1442052
	},

	{
		"prt_maze01",
		17272,
		300,
		1174,
		"Stainer",
		"STAINER",
		21,
		1572868
	},

	{
		"prt_maze01",
		17273,
		300,
		1037,
		"Side Winder",
		"SIDE_WINDER",
		70,
		1638658
	},

	{
		"prt_maze01",
		17274,
		300,
		1057,
		"Yoyo",
		"YOYO",
		38,
		1441794
	},

	{
		"prt_maze01",
		17275,
		300,
		1214,
		"Choco",
		"CHOCO",
		48,
		1507330
	},

	{
		"prt_maze01",
		17276,
		300,
		1042,
		"Steel Chonchon",
		"STEEL_CHONCHON",
		48,
		1572868
	},

	{
		"prt_maze01",
		17277,
		300,
		1104,
		"Coco",
		"COCO",
		38,
		1441794
	},

	{
		"prt_maze01",
		17278,
		300,
		1103,
		"Caramel",
		"CARAMEL",
		25,
		1441794
	},

	{
		"prt_maze01",
		17279,
		300,
		1114,
		"Dustiness",
		"DUSTINESS",
		62,
		2883588
	},

	{
		"prt_maze01",
		17280,
		300,
		1145,
		"Martin",
		"MARTIN",
		39,
		2752514
	},

	{
		"prt_maze01",
		17281,
		300,
		1166,
		"Savage",
		"SAVAGE",
		59,
		2753026
	},

	{
		"prt_maze01",
		17283,
		300,
		1092,
		"Vagabond Wolf",
		"VAGABOND_WOLF",
		93,
		1442050
	},

	{
		"prt_maze01",
		17463,
		300,
		1085,
		"Red Mushroom",
		"RED_MUSHROOM",
		1,
		1441795
	},

	{
		"prt_maze02",
		17284,
		300,
		1031,
		"Poporing",
		"POPORING",
		30,
		1638659
	},

	{
		"prt_maze02",
		17285,
		300,
		1060,
		"Bigfoot",
		"BIGFOOT",
		29,
		1442306
	},

	{
		"prt_maze02",
		17286,
		300,
		1243,
		"Sasquatch",
		"SASQUATCH",
		72,
		3932674
	},

	{
		"prt_maze02",
		17287,
		300,
		1306,
		"Leib Olmai",
		"LEIB_OLMAI",
		118,
		1442306
	},

	{
		"prt_maze03",
		17288,
		300,
		1037,
		"Side Winder",
		"SIDE_WINDER",
		70,
		1638658
	},

	{
		"prt_maze03",
		17289,
		300,
		1035,
		"Hunter Fly",
		"HUNTER_FLY",
		63,
		2883588
	},

	{
		"prt_maze03",
		17290,
		300,
		1120,
		"Ghostring",
		"GHOSTRING",
		90,
		5767430
	},

	{
		"prt_maze03",
		17291,
		300,
		1294,
		"Killer Mantis",
		"KILLER_MANTIS",
		141,
		1442052
	},

	{
		"prt_maze03",
		17293,
		300,
		1088,
		"Vocal",
		"VOCAL",
		18,
		1442052
	},

	{
		"prt_maze03",
		17294,
		300,
		1215,
		"Stem Worm",
		"STEM_WORM",
		84,
		1573123
	},

	{
		"prt_maze03",
		17295,
		300,
		1092,
		"Vagabond Wolf",
		"VAGABOND_WOLF",
		93,
		1442050
	},

	{
		"prt_maze03",
		17296,
		300,
		1139,
		"Mantis",
		"MANTIS",
		65,
		1442052
	},

	{
		"prt_maze03",
		17297,
		300,
		1093,
		"Eclipse",
		"ECLIPSE",
		31,
		3932418
	},

	{
		"prt_maze03",
		17298,
		300,
		1090,
		"Mastering",
		"MASTERING",
		42,
		1376515
	},

	{
		"prt_maze03",
		17299,
		300,
		1101,
		"Baphomet Jr.",
		"BAPHOMET_",
		57,
		1769478
	},

	{
		"prt_maze03",
		17300,
		301,
		1039,
		"Baphomet",
		"BAPHOMET",
		81,
		4391430
	},

	{
		"prt_maze03",
		17465,
		300,
		1085,
		"Red Mushroom",
		"RED_MUSHROOM",
		1,
		1441795
	},

	{
		"prt_sewb1",
		16307,
		300,
		1006,
		"Thief Bug Larva",
		"THIEF_BUG_LARVA",
		0,
		0
	},

	{
		"prt_sewb1",
		16308,
		300,
		1048,
		"Thief Bug Egg",
		"THIEF_BUG_EGG",
		20,
		1769476
	},

	{
		"prt_sewb1",
		16309,
		300,
		1175,
		"Tarou",
		"TAROU",
		22,
		1769474
	},

	{
		"prt_sewb1",
		16310,
		300,
		1005,
		"Familiar",
		"FARMILIAR",
		24,
		1769474
	},

	{
		"prt_sewb2",
		16311,
		300,
		1006,
		"Thief Bug Larva",
		"THIEF_BUG_LARVA",
		0,
		0
	},

	{
		"prt_sewb2",
		16313,
		300,
		1048,
		"Thief Bug Egg",
		"THIEF_BUG_EGG",
		20,
		1769476
	},

	{
		"prt_sewb2",
		16314,
		300,
		1014,
		"Spore",
		"SPORE",
		18,
		1376515
	},

	{
		"prt_sewb2",
		16315,
		300,
		1175,
		"Tarou",
		"TAROU",
		22,
		1769474
	},

	{
		"prt_sewb2",
		16316,
		300,
		1005,
		"Familiar",
		"FARMILIAR",
		24,
		1769474
	},

	{
		"prt_sewb2",
		16317,
		300,
		1161,
		"Plankton",
		"PLANKTON",
		40,
		3997699
	},

	{
		"prt_sewb3",
		16318,
		300,
		1006,
		"Thief Bug Larva",
		"THIEF_BUG_LARVA",
		0,
		0
	},

	{
		"prt_sewb3",
		16321,
		300,
		1048,
		"Thief Bug Egg",
		"THIEF_BUG_EGG",
		20,
		1769476
	},

	{
		"prt_sewb3",
		16322,
		300,
		1175,
		"Tarou",
		"TAROU",
		22,
		1769474
	},

	{
		"prt_sewb3",
		16323,
		300,
		1005,
		"Familiar",
		"FARMILIAR",
		24,
		1769474
	},

	{
		"prt_sewb3",
		16324,
		300,
		1077,
		"Poison Spore",
		"POISON_SPORE",
		26,
		1638659
	},

	{
		"prt_sewb4",
		16325,
		300,
		1006,
		"Thief Bug Larva",
		"THIEF_BUG_LARVA",
		0,
		0
	},

	{
		"prt_sewb4",
		16328,
		300,
		1048,
		"Thief Bug Egg",
		"THIEF_BUG_EGG",
		20,
		1769476
	},

	{
		"prt_sewb4",
		16329,
		300,
		1111,
		"Drainliar",
		"DRAINLIAR",
		47,
		3080194
	},

	{
		"prt_sewb4",
		16330,
		300,
		1209,
		"Cramp",
		"CRAMP",
		82,
		2949122
	},

	{
		"prt_sewb4",
		17227,
		301,
		1086,
		"Golden Thief Bug",
		"GOLDEN_BUG",
		65,
		2818564
	},

	{
		"que_qsch01",
		17981,
		300,
		1932,
		"Garden Keeper",
		"GARDEN_KEEPER",
		80,
		2752512
	},

	{
		"que_qsch01",
		17998,
		300,
		1933,
		"Garden Watcher",
		"GARDEN_WATCHER",
		81,
		5243144
	},

	{
		"ra_fild01",
		16237,
		300,
		1106,
		"Desert Wolf",
		"DESERT_WOLF",
		103,
		1507586
	},

	{
		"ra_fild01",
		16238,
		300,
		1107,
		"Desert Wolf Baby",
		"DESERT_WOLF_B",
		14,
		1507330
	},

	{
		"ra_fild01",
		16239,
		300,
		1782,
		"Roween",
		"ROWEEN",
		95,
		1573122
	},

	{
		"ra_fild01",
		16240,
		300,
		1627,
		"Anopheles",
		"ANOPHELES",
		95,
		4194308
	},

	{
		"ra_fild03",
		16241,
		300,
		1680,
		"Hill Wind",
		"HILL_WIND_1",
		101,
		4194562
	},

	{
		"ra_fild03",
		16242,
		300,
		1030,
		"Anacondaq",
		"ANACONDAQ",
		100,
		1638658
	},

	{
		"ra_fild03",
		16243,
		300,
		1782,
		"Roween",
		"ROWEEN",
		95,
		1573122
	},

	{
		"ra_fild03",
		16244,
		300,
		1627,
		"Anopheles",
		"ANOPHELES",
		95,
		4194308
	},

	{
		"ra_fild03",
		17234,
		301,
		1785,
		"Atroce",
		"ATROCE",
		113,
		4391426
	},

	{
		"ra_fild04",
		16245,
		300,
		1680,
		"Hill Wind",
		"HILL_WIND_1",
		101,
		4194562
	},

	{
		"ra_fild04",
		16246,
		300,
		1106,
		"Desert Wolf",
		"DESERT_WOLF",
		103,
		1507586
	},

	{
		"ra_fild04",
		16247,
		300,
		1782,
		"Roween",
		"ROWEEN",
		95,
		1573122
	},

	{
		"ra_fild04",
		16248,
		300,
		1627,
		"Anopheles",
		"ANOPHELES",
		95,
		4194308
	},

	{
		"ra_fild04",
		17235,
		301,
		1785,
		"Atroce",
		"ATROCE",
		113,
		4391426
	},

	{
		"ra_fild05",
		16249,
		300,
		1133,
		"Kobold",
		"KOBOLD_1",
		107,
		2883847
	},

	{
		"ra_fild05",
		16250,
		300,
		1134,
		"Kobold",
		"KOBOLD_2",
		102,
		2949383
	},

	{
		"ra_fild05",
		16251,
		300,
		1135,
		"Kobold",
		"KOBOLD_3",
		101,
		2818311
	},

	{
		"ra_fild05",
		16252,
		300,
		1627,
		"Anopheles",
		"ANOPHELES",
		95,
		4194308
	},

	{
		"ra_fild06",
		16253,
		300,
		1282,
		"Kobold Archer",
		"KOBOLD_ARCHER",
		108,
		1507335
	},

	{
		"ra_fild06",
		16254,
		300,
		1133,
		"Kobold",
		"KOBOLD_1",
		107,
		2883847
	},

	{
		"ra_fild06",
		16255,
		300,
		1134,
		"Kobold",
		"KOBOLD_2",
		102,
		2949383
	},

	{
		"ra_fild06",
		16256,
		300,
		1135,
		"Kobold",
		"KOBOLD_3",
		101,
		2818311
	},

	{
		"ra_fild06",
		16257,
		300,
		1627,
		"Anopheles",
		"ANOPHELES",
		95,
		4194308
	},

	{
		"ra_fild06",
		17472,
		300,
		1296,
		"Kobold Leader",
		"KOBOLD_LEADER",
		112,
		2883847
	},

	{
		"ra_fild08",
		16258,
		300,
		1030,
		"Anacondaq",
		"ANACONDAQ",
		100,
		1638658
	},

	{
		"ra_fild08",
		16259,
		300,
		1680,
		"Hill Wind",
		"HILL_WIND_1",
		101,
		4194562
	},

	{
		"ra_fild08",
		16260,
		300,
		1782,
		"Roween",
		"ROWEEN",
		95,
		1573122
	},

	{
		"ra_fild08",
		16261,
		300,
		1107,
		"Desert Wolf Baby",
		"DESERT_WOLF_B",
		14,
		1507330
	},

	{
		"ra_fild08",
		16262,
		300,
		1627,
		"Anopheles",
		"ANOPHELES",
		95,
		4194308
	},

	{
		"ra_fild12",
		16263,
		300,
		1782,
		"Roween",
		"ROWEEN",
		95,
		1573122
	},

	{
		"ra_fild12",
		16264,
		300,
		1107,
		"Desert Wolf Baby",
		"DESERT_WOLF_B",
		14,
		1507330
	},

	{
		"ra_fild12",
		16265,
		300,
		1627,
		"Anopheles",
		"ANOPHELES",
		95,
		4194308
	},

	{
		"ra_fild12",
		17514,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"ra_fild12",
		17515,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"ra_san01",
		17006,
		300,
		1632,
		"Gremlin",
		"GREMLIN",
		118,
		3080710
	},

	{
		"ra_san01",
		17007,
		300,
		1633,
		"Beholder",
		"BEHOLDER",
		120,
		2883584
	},

	{
		"ra_san01",
		17008,
		300,
		1772,
		"Isilla",
		"ISILLA",
		124,
		5243143
	},

	{
		"ra_san01",
		17009,
		300,
		1771,
		"Vanberk",
		"VANBERK",
		123,
		5243143
	},

	{
		"ra_san01",
		17010,
		300,
		1773,
		"Hodremlin",
		"HODREMLIN",
		122,
		4391174
	},

	{
		"ra_san02",
		17011,
		300,
		1632,
		"Gremlin",
		"GREMLIN",
		118,
		3080710
	},

	{
		"ra_san02",
		17012,
		300,
		1633,
		"Beholder",
		"BEHOLDER",
		120,
		2883584
	},

	{
		"ra_san02",
		17013,
		300,
		1774,
		"Seeker",
		"SEEKER",
		124,
		4194304
	},

	{
		"ra_san02",
		17014,
		300,
		1772,
		"Isilla",
		"ISILLA",
		124,
		5243143
	},

	{
		"ra_san02",
		17015,
		300,
		1771,
		"Vanberk",
		"VANBERK",
		123,
		5243143
	},

	{
		"ra_san02",
		17016,
		300,
		1773,
		"Hodremlin",
		"HODREMLIN",
		122,
		4391174
	},

	{
		"ra_san03",
		17017,
		300,
		1632,
		"Gremlin",
		"GREMLIN",
		118,
		3080710
	},

	{
		"ra_san03",
		17018,
		300,
		1633,
		"Beholder",
		"BEHOLDER",
		120,
		2883584
	},

	{
		"ra_san03",
		17019,
		300,
		1774,
		"Seeker",
		"SEEKER",
		124,
		4194304
	},

	{
		"ra_san03",
		17020,
		300,
		1773,
		"Hodremlin",
		"HODREMLIN",
		122,
		4391174
	},

	{
		"ra_san04",
		17021,
		300,
		1774,
		"Seeker",
		"SEEKER",
		124,
		4194304
	},

	{
		"ra_san04",
		17022,
		300,
		1769,
		"Agav",
		"AGAV",
		128,
		5243143
	},

	{
		"ra_san04",
		17023,
		300,
		1770,
		"Echio",
		"ECHIO",
		126,
		5243143
	},

	{
		"ra_san04",
		17024,
		300,
		1773,
		"Hodremlin",
		"HODREMLIN",
		122,
		4391174
	},

	{
		"ra_san05",
		17025,
		300,
		1774,
		"Seeker",
		"SEEKER",
		124,
		4194304
	},

	{
		"ra_san05",
		17026,
		300,
		1769,
		"Agav",
		"AGAV",
		128,
		5243143
	},

	{
		"ra_san05",
		17027,
		300,
		1770,
		"Echio",
		"ECHIO",
		126,
		5243143
	},

	{
		"ra_san05",
		17028,
		300,
		1772,
		"Isilla",
		"ISILLA",
		124,
		5243143
	},

	{
		"ra_san05",
		17029,
		300,
		1773,
		"Hodremlin",
		"HODREMLIN",
		122,
		4391174
	},

	{
		"ra_san05",
		17230,
		301,
		1768,
		"Gloom Under Night",
		"GLOOMUNDERNIGHT",
		139,
		4456960
	},

	{
		"schg_dun01",
		17318,
		300,
		1978,
		"Hell Apocalips",
		"HELL_APOCALIPS",
		121,
		3932672
	},

	{
		"schg_dun01",
		17319,
		300,
		1979,
		"Zukadam",
		"ZAKUDAM",
		115,
		3932679
	},

	{
		"schg_dun01",
		17320,
		300,
		1977,
		"Heavy Metaling",
		"HEAVY_METALING",
		107,
		1310720
	},

	{
		"schg_dun01",
		17321,
		300,
		1976,
		"Cobalt Mineral",
		"COBALT_MINERAL",
		113,
		2621696
	},

	{
		"spl_fild01",
		17175,
		300,
		2015,
		"Dark Pinguicula",
		"PINGUICULA_D",
		113,
		2949379
	},

	{
		"spl_fild01",
		17176,
		300,
		1993,
		"Naga",
		"NAGA",
		117,
		2753026
	},

	{
		"spl_fild01",
		17177,
		300,
		1992,
		"Cornus",
		"CORNUS",
		120,
		4325634
	},

	{
		"spl_fild02",
		17194,
		300,
		1995,
		"Pinguicula",
		"PINGUICULA",
		105,
		4063491
	},

	{
		"spl_fild02",
		17195,
		300,
		1994,
		"Luciola Vespa",
		"LUCIOLA_VESPA",
		109,
		1573124
	},

	{
		"spl_fild02",
		17196,
		300,
		2049,
		"Bradium Golem",
		"W_BRADIUM_GOLEM",
		99,
		2753024
	},

	{
		"spl_fild02",
		17197,
		300,
		2047,
		"Naga",
		"W_NAGA",
		99,
		2753026
	},

	{
		"spl_fild03",
		17198,
		300,
		1994,
		"Luciola Vespa",
		"LUCIOLA_VESPA",
		109,
		1573124
	},

	{
		"spl_fild03",
		17199,
		300,
		1992,
		"Cornus",
		"CORNUS",
		120,
		4325634
	},

	{
		"spl_fild03",
		17200,
		300,
		1993,
		"Naga",
		"NAGA",
		117,
		2753026
	},

	{
		"spl_fild03",
		17201,
		300,
		1991,
		"Tendrillion",
		"TENDRILRION",
		126,
		2752770
	},

	{
		"tha_t01",
		16867,
		300,
		1195,
		"Rideword",
		"RIDEWORD",
		74,
		3932160
	},

	{
		"tha_t01",
		16868,
		300,
		1191,
		"Mimic",
		"MIMIC",
		56,
		3932416
	},

	{
		"tha_t01",
		16869,
		300,
		1275,
		"Alice",
		"ALICE",
		100,
		3932423
	},

	{
		"tha_t01",
		16870,
		300,
		1703,
		"Solace",
		"SOLACE",
		123,
		4325640
	},

	{
		"tha_t01",
		16871,
		300,
		1695,
		"Plasma",
		"PLASMA_G",
		116,
		5373952
	},

	{
		"tha_t02",
		16872,
		300,
		1698,
		"Deathword",
		"DEATHWORD",
		114,
		3932416
	},

	{
		"tha_t02",
		16873,
		300,
		1195,
		"Rideword",
		"RIDEWORD",
		74,
		3932160
	},

	{
		"tha_t02",
		16874,
		300,
		1191,
		"Mimic",
		"MIMIC",
		56,
		3932416
	},

	{
		"tha_t02",
		16875,
		300,
		1702,
		"Retribution",
		"RETRIBUTION",
		121,
		4391176
	},

	{
		"tha_t02",
		16876,
		300,
		1699,
		"Ancient Mimic",
		"ANCIENT_MIMIC",
		112,
		3932672
	},

	{
		"tha_t02",
		16877,
		300,
		1377,
		"Elder",
		"ELDER",
		92,
		5243399
	},

	{
		"tha_t02",
		16878,
		300,
		1275,
		"Alice",
		"ALICE",
		100,
		3932423
	},

	{
		"tha_t02",
		16879,
		300,
		1697,
		"Plasma",
		"PLASMA_B",
		115,
		5308416
	},

	{
		"tha_t03",
		16880,
		300,
		1698,
		"Deathword",
		"DEATHWORD",
		114,
		3932416
	},

	{
		"tha_t03",
		16881,
		300,
		1195,
		"Rideword",
		"RIDEWORD",
		74,
		3932160
	},

	{
		"tha_t03",
		16882,
		300,
		1191,
		"Mimic",
		"MIMIC",
		56,
		3932416
	},

	{
		"tha_t03",
		16883,
		300,
		1701,
		"Shelter",
		"SHELTER",
		125,
		4325640
	},

	{
		"tha_t03",
		16884,
		300,
		1699,
		"Ancient Mimic",
		"ANCIENT_MIMIC",
		112,
		3932672
	},

	{
		"tha_t03",
		16885,
		300,
		1377,
		"Elder",
		"ELDER",
		92,
		5243399
	},

	{
		"tha_t03",
		16886,
		300,
		1696,
		"Plasma",
		"PLASMA_P",
		117,
		5701632
	},

	{
		"tha_t04",
		16887,
		300,
		1700,
		"Observation",
		"OBSERVATION",
		127,
		5243144
	},

	{
		"tha_t04",
		16888,
		300,
		1698,
		"Deathword",
		"DEATHWORD",
		114,
		3932416
	},

	{
		"tha_t04",
		16889,
		300,
		1195,
		"Rideword",
		"RIDEWORD",
		74,
		3932160
	},

	{
		"tha_t04",
		16890,
		300,
		1191,
		"Mimic",
		"MIMIC",
		56,
		3932416
	},

	{
		"tha_t04",
		16891,
		300,
		1320,
		"Owl Duke",
		"OWL_DUKE",
		92,
		3932678
	},

	{
		"tha_t04",
		16892,
		300,
		1295,
		"Owl Baron",
		"OWL_BARON",
		120,
		3932678
	},

	{
		"tha_t04",
		16893,
		300,
		1699,
		"Ancient Mimic",
		"ANCIENT_MIMIC",
		112,
		3932672
	},

	{
		"tha_t04",
		16894,
		300,
		1377,
		"Elder",
		"ELDER",
		92,
		5243399
	},

	{
		"tha_t04",
		16895,
		300,
		1694,
		"Plasma",
		"PLASMA_R",
		118,
		5439488
	},

	{
		"tha_t05",
		16896,
		300,
		1698,
		"Deathword",
		"DEATHWORD",
		114,
		3932416
	},

	{
		"tha_t05",
		16897,
		300,
		1320,
		"Owl Duke",
		"OWL_DUKE",
		92,
		3932678
	},

	{
		"tha_t05",
		16898,
		300,
		1295,
		"Owl Baron",
		"OWL_BARON",
		120,
		3932678
	},

	{
		"tha_t05",
		16899,
		300,
		1699,
		"Ancient Mimic",
		"ANCIENT_MIMIC",
		112,
		3932672
	},

	{
		"tha_t05",
		16900,
		300,
		1377,
		"Elder",
		"ELDER",
		92,
		5243399
	},

	{
		"tha_t05",
		16901,
		300,
		1707,
		"Thanatos Dolor",
		"THA_DOLOR",
		129,
		5767169
	},

	{
		"tha_t05",
		16902,
		300,
		1697,
		"Plasma",
		"PLASMA_B",
		115,
		5308416
	},

	{
		"tha_t05",
		16903,
		300,
		1695,
		"Plasma",
		"PLASMA_G",
		116,
		5373952
	},

	{
		"tha_t05",
		16904,
		300,
		1696,
		"Plasma",
		"PLASMA_P",
		117,
		5701632
	},

	{
		"tha_t05",
		16905,
		300,
		1694,
		"Plasma",
		"PLASMA_R",
		118,
		5439488
	},

	{
		"tha_t06",
		17030,
		300,
		1698,
		"Deathword",
		"DEATHWORD",
		114,
		3932416
	},

	{
		"tha_t06",
		17031,
		300,
		1320,
		"Owl Duke",
		"OWL_DUKE",
		92,
		3932678
	},

	{
		"tha_t06",
		17032,
		300,
		1295,
		"Owl Baron",
		"OWL_BARON",
		120,
		3932678
	},

	{
		"tha_t06",
		17033,
		300,
		1699,
		"Ancient Mimic",
		"ANCIENT_MIMIC",
		112,
		3932672
	},

	{
		"tha_t06",
		17034,
		300,
		1377,
		"Elder",
		"ELDER",
		92,
		5243399
	},

	{
		"tha_t06",
		17035,
		300,
		1706,
		"Thanatos Maero",
		"THA_MAERO",
		129,
		5767425
	},

	{
		"tha_t06",
		17036,
		300,
		1697,
		"Plasma",
		"PLASMA_B",
		115,
		5308416
	},

	{
		"tha_t06",
		17037,
		300,
		1695,
		"Plasma",
		"PLASMA_G",
		116,
		5373952
	},

	{
		"tha_t06",
		17038,
		300,
		1696,
		"Plasma",
		"PLASMA_P",
		117,
		5701632
	},

	{
		"tha_t06",
		17039,
		300,
		1694,
		"Plasma",
		"PLASMA_R",
		118,
		5439488
	},

	{
		"tha_t07",
		17040,
		300,
		1700,
		"Observation",
		"OBSERVATION",
		127,
		5243144
	},

	{
		"tha_t07",
		17041,
		300,
		1698,
		"Deathword",
		"DEATHWORD",
		114,
		3932416
	},

	{
		"tha_t07",
		17042,
		300,
		1702,
		"Retribution",
		"RETRIBUTION",
		121,
		4391176
	},

	{
		"tha_t07",
		17043,
		300,
		1701,
		"Shelter",
		"SHELTER",
		125,
		4325640
	},

	{
		"tha_t07",
		17044,
		300,
		1699,
		"Ancient Mimic",
		"ANCIENT_MIMIC",
		112,
		3932672
	},

	{
		"tha_t07",
		17045,
		300,
		1703,
		"Solace",
		"SOLACE",
		123,
		4325640
	},

	{
		"tha_t07",
		17046,
		300,
		1705,
		"Thanatos Despero",
		"THA_DESPERO",
		129,
		5767681
	},

	{
		"tha_t08",
		17047,
		300,
		1700,
		"Observation",
		"OBSERVATION",
		127,
		5243144
	},

	{
		"tha_t08",
		17048,
		300,
		1698,
		"Deathword",
		"DEATHWORD",
		114,
		3932416
	},

	{
		"tha_t08",
		17049,
		300,
		1702,
		"Retribution",
		"RETRIBUTION",
		121,
		4391176
	},

	{
		"tha_t08",
		17050,
		300,
		1701,
		"Shelter",
		"SHELTER",
		125,
		4325640
	},

	{
		"tha_t08",
		17051,
		300,
		1699,
		"Ancient Mimic",
		"ANCIENT_MIMIC",
		112,
		3932672
	},

	{
		"tha_t08",
		17052,
		300,
		1703,
		"Solace",
		"SOLACE",
		123,
		4325640
	},

	{
		"tha_t08",
		17053,
		300,
		1704,
		"Thanatos Odium",
		"THA_ODIUM",
		129,
		5767681
	},

	{
		"tha_t09",
		17054,
		300,
		1700,
		"Observation",
		"OBSERVATION",
		127,
		5243144
	},

	{
		"tha_t09",
		17055,
		300,
		1702,
		"Retribution",
		"RETRIBUTION",
		121,
		4391176
	},

	{
		"tha_t09",
		17056,
		300,
		1701,
		"Shelter",
		"SHELTER",
		125,
		4325640
	},

	{
		"tha_t09",
		17057,
		300,
		1703,
		"Solace",
		"SOLACE",
		123,
		4325640
	},

	{
		"tha_t09",
		17058,
		300,
		1707,
		"Thanatos Dolor",
		"THA_DOLOR",
		129,
		5767169
	},

	{
		"tha_t09",
		17060,
		300,
		1694,
		"Plasma",
		"PLASMA_R",
		118,
		5439488
	},

	{
		"tha_t10",
		17061,
		300,
		1700,
		"Observation",
		"OBSERVATION",
		127,
		5243144
	},

	{
		"tha_t10",
		17062,
		300,
		1702,
		"Retribution",
		"RETRIBUTION",
		121,
		4391176
	},

	{
		"tha_t10",
		17063,
		300,
		1701,
		"Shelter",
		"SHELTER",
		125,
		4325640
	},

	{
		"tha_t10",
		17064,
		300,
		1703,
		"Solace",
		"SOLACE",
		123,
		4325640
	},

	{
		"tha_t10",
		17065,
		300,
		1706,
		"Thanatos Maero",
		"THA_MAERO",
		129,
		5767425
	},

	{
		"tha_t10",
		17067,
		300,
		1697,
		"Plasma",
		"PLASMA_B",
		115,
		5308416
	},

	{
		"tha_t11",
		17068,
		300,
		1700,
		"Observation",
		"OBSERVATION",
		127,
		5243144
	},

	{
		"tha_t11",
		17069,
		300,
		1702,
		"Retribution",
		"RETRIBUTION",
		121,
		4391176
	},

	{
		"tha_t11",
		17070,
		300,
		1701,
		"Shelter",
		"SHELTER",
		125,
		4325640
	},

	{
		"tha_t11",
		17071,
		300,
		1703,
		"Solace",
		"SOLACE",
		123,
		4325640
	},

	{
		"tha_t11",
		17072,
		300,
		1705,
		"Thanatos Despero",
		"THA_DESPERO",
		129,
		5767681
	},

	{
		"tha_t11",
		17074,
		300,
		1695,
		"Plasma",
		"PLASMA_G",
		116,
		5373952
	},

	{
		"tha_t12",
		17075,
		300,
		1700,
		"Observation",
		"OBSERVATION",
		127,
		5243144
	},

	{
		"tha_t12",
		17076,
		300,
		1702,
		"Retribution",
		"RETRIBUTION",
		121,
		4391176
	},

	{
		"tha_t12",
		17077,
		300,
		1701,
		"Shelter",
		"SHELTER",
		125,
		4325640
	},

	{
		"tha_t12",
		17078,
		300,
		1703,
		"Solace",
		"SOLACE",
		123,
		4325640
	},

	{
		"tha_t12",
		17079,
		300,
		1709,
		"Thanatos Odium",
		"G_THA_ODIUM",
		129,
		5767681
	},

	{
		"tha_t12",
		17080,
		300,
		1693,
		"Plasma",
		"PLASMA_Y",
		119,
		5767168
	},

	{
		"thor_v01",
		17129,
		300,
		1836,
		"Magmaring",
		"MAGMARING",
		110,
		2818048
	},

	{
		"thor_v01",
		17130,
		300,
		1830,
		"Bow Guardian",
		"BOW_GUARDIAN",
		132,
		5243399
	},

	{
		"thor_v01",
		17131,
		300,
		1839,
		"Byorgue",
		"BYORGUE",
		135,
		1310983
	},

	{
		"thor_v01",
		17132,
		300,
		1831,
		"Salamander",
		"SALAMANDER",
		138,
		4129280
	},

	{
		"thor_v01",
		17133,
		300,
		1829,
		"Sword Guardian",
		"SWORD_GUARDIAN",
		133,
		5243399
	},

	{
		"thor_v01",
		17134,
		300,
		1837,
		"Imp",
		"IMP",
		129,
		4128774
	},

	{
		"thor_v01",
		17135,
		300,
		1833,
		"Kasa",
		"KASA",
		135,
		4129280
	},

	{
		"thor_v02",
		17136,
		300,
		1838,
		"Knocker",
		"KNOCKER",
		126,
		1441798
	},

	{
		"thor_v02",
		17137,
		300,
		1836,
		"Magmaring",
		"MAGMARING",
		110,
		2818048
	},

	{
		"thor_v02",
		17138,
		300,
		1831,
		"Salamander",
		"SALAMANDER",
		138,
		4129280
	},

	{
		"thor_v02",
		17139,
		300,
		1837,
		"Imp",
		"IMP",
		129,
		4128774
	},

	{
		"thor_v02",
		17140,
		300,
		1072,
		"Kaho",
		"KAHO",
		98,
		5439750
	},

	{
		"thor_v02",
		17240,
		300,
		1830,
		"Bow Guardian",
		"BOW_GUARDIAN",
		132,
		5243399
	},

	{
		"thor_v02",
		17249,
		300,
		1829,
		"Sword Guardian",
		"SWORD_GUARDIAN",
		133,
		5243399
	},

	{
		"thor_v03",
		17141,
		300,
		1830,
		"Bow Guardian",
		"BOW_GUARDIAN",
		132,
		5243399
	},

	{
		"thor_v03",
		17142,
		300,
		1839,
		"Byorgue",
		"BYORGUE",
		135,
		1310983
	},

	{
		"thor_v03",
		17143,
		300,
		1831,
		"Salamander",
		"SALAMANDER",
		138,
		4129280
	},

	{
		"thor_v03",
		17144,
		300,
		1829,
		"Sword Guardian",
		"SWORD_GUARDIAN",
		133,
		5243399
	},

	{
		"thor_v03",
		17145,
		300,
		1833,
		"Kasa",
		"KASA",
		135,
		4129280
	},

	{
		"thor_v03",
		17231,
		301,
		1832,
		"Ifrit",
		"IFRIT",
		146,
		5440000
	},

	{
		"treasure01",
		16452,
		300,
		1179,
		"Whisper",
		"WHISPER",
		46,
		4456454
	},

	{
		"treasure01",
		16453,
		300,
		1070,
		"Kukre",
		"KUKRE",
		42,
		1376261
	},

	{
		"treasure01",
		16454,
		300,
		1071,
		"Pirate Skeleton",
		"PIRATE_SKEL",
		48,
		1900801
	},

	{
		"treasure01",
		16455,
		300,
		1077,
		"Poison Spore",
		"POISON_SPORE",
		26,
		1638659
	},

	{
		"treasure01",
		16456,
		300,
		1068,
		"Hydra",
		"HYDRA",
		34,
		2686979
	},

	{
		"treasure02",
		16457,
		300,
		1143,
		"Marionette",
		"MARIONETTE",
		90,
		4456454
	},

	{
		"treasure02",
		16458,
		300,
		1191,
		"Mimic",
		"MIMIC",
		56,
		3932416
	},

	{
		"treasure02",
		16459,
		300,
		1208,
		"Wander Man",
		"WANDER_MAN",
		120,
		1573126
	},

	{
		"treasure02",
		16460,
		300,
		1179,
		"Whisper",
		"WHISPER",
		46,
		4456454
	},

	{
		"treasure02",
		16461,
		300,
		1070,
		"Kukre",
		"KUKRE",
		42,
		1376261
	},

	{
		"treasure02",
		16462,
		300,
		1071,
		"Pirate Skeleton",
		"PIRATE_SKEL",
		48,
		1900801
	},

	{
		"treasure02",
		16463,
		300,
		1216,
		"Penomena",
		"PENOMENA",
		85,
		1638661
	},

	{
		"treasure02",
		16464,
		300,
		1068,
		"Hydra",
		"HYDRA",
		34,
		2686979
	},

	{
		"treasure02",
		17232,
		301,
		1112,
		"Drake",
		"DRAKE",
		91,
		1900801
	},

	{
		"treasure02",
		17405,
		300,
		1120,
		"Ghostring",
		"GHOSTRING",
		90,
		5767430
	},

	{
		"tur_dun01",
		16752,
		300,
		1321,
		"Dragon Tail",
		"DRAGON_TAIL",
		86,
		2883844
	},

	{
		"tur_dun01",
		16753,
		300,
		1322,
		"Spring Rabbit",
		"SPRING_RABBIT",
		88,
		2752770
	},

	{
		"tur_dun01",
		16754,
		300,
		1034,
		"Thara Frog",
		"THARA_FROG",
		40,
		2687237
	},

	{
		"tur_dun01",
		16755,
		300,
		1314,
		"Permeter",
		"PERMETER",
		90,
		2621698
	},

	{
		"tur_dun01",
		16756,
		300,
		1256,
		"Pest",
		"PEST",
		89,
		3080194
	},

	{
		"tur_dun02",
		16757,
		300,
		1316,
		"Solider",
		"SOLIDER",
		92,
		2752770
	},

	{
		"tur_dun02",
		16758,
		300,
		1314,
		"Permeter",
		"PERMETER",
		90,
		2621698
	},

	{
		"tur_dun02",
		16759,
		300,
		1256,
		"Pest",
		"PEST",
		89,
		3080194
	},

	{
		"tur_dun02",
		16760,
		300,
		1319,
		"Freezer",
		"FREEZER",
		94,
		2687234
	},

	{
		"tur_dun03",
		16761,
		300,
		1315,
		"Assaulter",
		"ASSULTER",
		100,
		2883847
	},

	{
		"tur_dun03",
		16762,
		300,
		1314,
		"Permeter",
		"PERMETER",
		90,
		2621698
	},

	{
		"tur_dun03",
		16763,
		300,
		1319,
		"Freezer",
		"FREEZER",
		94,
		2687234
	},

	{
		"tur_dun03",
		16764,
		300,
		1318,
		"Heater",
		"HEATER",
		98,
		2818306
	},

	{
		"tur_dun03",
		18853,
		300,
		2076,
		"Wind Ghost",
		"S_WIND_GHOST",
		105,
		4194566
	},

	{
		"tur_dun04",
		16765,
		300,
		1315,
		"Assaulter",
		"ASSULTER",
		100,
		2883847
	},

	{
		"tur_dun04",
		16766,
		300,
		1314,
		"Permeter",
		"PERMETER",
		90,
		2621698
	},

	{
		"tur_dun04",
		16767,
		300,
		1319,
		"Freezer",
		"FREEZER",
		94,
		2687234
	},

	{
		"tur_dun04",
		16768,
		300,
		1318,
		"Heater",
		"HEATER",
		98,
		2818306
	},

	{
		"tur_dun04",
		17233,
		301,
		1312,
		"Turtle General",
		"TURTLE_GENERAL",
		110,
		2753026
	},

	{
		"tur_dun05",
		16769,
		300,
		1315,
		"Assaulter",
		"ASSULTER",
		100,
		2883847
	},

	{
		"tur_dun05",
		16770,
		300,
		1314,
		"Permeter",
		"PERMETER",
		90,
		2621698
	},

	{
		"tur_dun05",
		16771,
		300,
		1319,
		"Freezer",
		"FREEZER",
		94,
		2687234
	},

	{
		"um_fild01",
		16147,
		300,
		1495,
		"Stone Shooter",
		"STONE_SHOOTER",
		64,
		4129027
	},

	{
		"um_fild01",
		16148,
		300,
		1498,
		"Wootan Shooter",
		"WOOTAN_SHOOTER",
		67,
		2752775
	},

	{
		"um_fild01",
		16149,
		300,
		1499,
		"Wootan Fighter",
		"WOOTAN_FIGHTER",
		67,
		2818311
	},

	{
		"um_fild01",
		16150,
		300,
		1493,
		"Dryad",
		"DRYAD",
		68,
		5374211
	},

	{
		"um_fild01",
		17468,
		300,
		1497,
		"Wooden Golem",
		"WOODEN_GOLEM",
		72,
		5374467
	},

	{
		"um_fild01",
		17742,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"um_fild01",
		17743,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"um_fild01",
		17744,
		300,
		1083,
		"Shining Plant",
		"SHINING_PLANT",
		1,
		1703939
	},

	{
		"um_fild02",
		16151,
		300,
		1495,
		"Stone Shooter",
		"STONE_SHOOTER",
		64,
		4129027
	},

	{
		"um_fild02",
		16152,
		300,
		1498,
		"Wootan Shooter",
		"WOOTAN_SHOOTER",
		67,
		2752775
	},

	{
		"um_fild02",
		16153,
		300,
		1499,
		"Wootan Fighter",
		"WOOTAN_FIGHTER",
		67,
		2818311
	},

	{
		"um_fild02",
		17486,
		300,
		1214,
		"Choco",
		"CHOCO",
		48,
		1507330
	},

	{
		"um_fild02",
		17745,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"um_fild02",
		17746,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"um_fild03",
		16154,
		300,
		1495,
		"Stone Shooter",
		"STONE_SHOOTER",
		64,
		4129027
	},

	{
		"um_fild03",
		16155,
		300,
		1498,
		"Wootan Shooter",
		"WOOTAN_SHOOTER",
		67,
		2752775
	},

	{
		"um_fild03",
		16156,
		300,
		1499,
		"Wootan Fighter",
		"WOOTAN_FIGHTER",
		67,
		2818311
	},

	{
		"um_fild03",
		16157,
		300,
		1500,
		"Parasite",
		"PARASITE",
		76,
		2883843
	},

	{
		"um_fild03",
		17747,
		300,
		1079,
		"Blue Plant",
		"BLUE_PLANT",
		1,
		1441795
	},

	{
		"um_fild03",
		17748,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"um_fild03",
		17749,
		300,
		1083,
		"Shining Plant",
		"SHINING_PLANT",
		1,
		1703939
	},

	{
		"um_fild04",
		16158,
		300,
		1495,
		"Stone Shooter",
		"STONE_SHOOTER",
		64,
		4129027
	},

	{
		"um_fild04",
		16159,
		300,
		1498,
		"Wootan Shooter",
		"WOOTAN_SHOOTER",
		67,
		2752775
	},

	{
		"um_fild04",
		16160,
		300,
		1499,
		"Wootan Fighter",
		"WOOTAN_FIGHTER",
		67,
		2818311
	},

	{
		"um_fild04",
		16161,
		300,
		1261,
		"Wild Rose",
		"WILD_ROSE",
		70,
		1572866
	},

	{
		"um_fild04",
		17467,
		300,
		1497,
		"Wooden Golem",
		"WOODEN_GOLEM",
		72,
		5374467
	},

	{
		"um_fild04",
		17487,
		300,
		1214,
		"Choco",
		"CHOCO",
		48,
		1507330
	},

	{
		"um_fild04",
		17750,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"um_fild04",
		17751,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"ve_fild01",
		16266,
		300,
		1783,
		"Galion",
		"GALION",
		100,
		2883842
	},

	{
		"ve_fild01",
		16267,
		300,
		1784,
		"Stapo",
		"STAPO",
		95,
		2752512
	},

	{
		"ve_fild01",
		16268,
		300,
		1781,
		"Drosera",
		"DROSERA",
		101,
		1442051
	},

	{
		"ve_fild01",
		16269,
		300,
		1780,
		"Muscipular",
		"MUSCIPULAR",
		105,
		1442051
	},

	{
		"ve_fild01",
		17228,
		301,
		1785,
		"Atroce",
		"ATROCE",
		113,
		4391426
	},

	{
		"ve_fild01",
		17502,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"ve_fild01",
		17503,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"ve_fild01",
		17504,
		300,
		1079,
		"Blue Plant",
		"BLUE_PLANT",
		1,
		1441795
	},

	{
		"ve_fild01",
		17505,
		300,
		1083,
		"Shining Plant",
		"SHINING_PLANT",
		1,
		1703939
	},

	{
		"ve_fild02",
		16270,
		300,
		1781,
		"Drosera",
		"DROSERA",
		101,
		1442051
	},

	{
		"ve_fild02",
		16271,
		300,
		1780,
		"Muscipular",
		"MUSCIPULAR",
		105,
		1442051
	},

	{
		"ve_fild02",
		16272,
		300,
		1783,
		"Galion",
		"GALION",
		100,
		2883842
	},

	{
		"ve_fild02",
		17229,
		301,
		1785,
		"Atroce",
		"ATROCE",
		113,
		4391426
	},

	{
		"ve_fild02",
		17506,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"ve_fild02",
		17507,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"ve_fild03",
		16273,
		300,
		1836,
		"Magmaring",
		"MAGMARING",
		110,
		2818048
	},

	{
		"ve_fild03",
		16274,
		300,
		1780,
		"Muscipular",
		"MUSCIPULAR",
		105,
		1442051
	},

	{
		"ve_fild03",
		16275,
		300,
		1781,
		"Drosera",
		"DROSERA",
		101,
		1442051
	},

	{
		"ve_fild03",
		17508,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"ve_fild03",
		17509,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"ve_fild04",
		16276,
		300,
		1780,
		"Muscipular",
		"MUSCIPULAR",
		105,
		1442051
	},

	{
		"ve_fild04",
		16277,
		300,
		1781,
		"Drosera",
		"DROSERA",
		101,
		1442051
	},

	{
		"ve_fild04",
		16278,
		300,
		1783,
		"Galion",
		"GALION",
		100,
		2883842
	},

	{
		"ve_fild04",
		17510,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"ve_fild04",
		17511,
		300,
		1079,
		"Blue Plant",
		"BLUE_PLANT",
		1,
		1441795
	},

	{
		"ve_fild06",
		17512,
		300,
		1083,
		"Shining Plant",
		"SHINING_PLANT",
		1,
		1703939
	},

	{
		"ve_fild07",
		16279,
		300,
		1784,
		"Stapo",
		"STAPO",
		95,
		2752512
	},

	{
		"ve_fild07",
		16280,
		300,
		1781,
		"Drosera",
		"DROSERA",
		101,
		1442051
	},

	{
		"ve_fild07",
		16281,
		300,
		1780,
		"Muscipular",
		"MUSCIPULAR",
		105,
		1442051
	},

	{
		"ve_fild07",
		17513,
		300,
		1082,
		"White Plant",
		"WHITE_PLANT",
		1,
		1441795
	},

	{
		"xmas_dun01",
		16431,
		300,
		1113,
		"Drops",
		"DROPS",
		2,
		1507587
	},

	{
		"xmas_dun01",
		16432,
		300,
		1242,
		"Marin",
		"MARIN",
		37,
		2687235
	},

	{
		"xmas_dun01",
		16433,
		300,
		1249,
		"Myst Case",
		"MYSTCASE",
		39,
		3932416
	},

	{
		"xmas_dun01",
		16434,
		300,
		1265,
		"Cookie",
		"COOKIE",
		35,
		3932167
	},

	{
		"xmas_dun01",
		16435,
		300,
		1002,
		"Poring",
		"PORING",
		1,
		1376515
	},

	{
		"xmas_dun01",
		16436,
		300,
		1031,
		"Poporing",
		"POPORING",
		30,
		1638659
	},

	{
		"xmas_dun01",
		17244,
		300,
		1250,
		"Chepet",
		"CHEPET",
		42,
		1507591
	},

	{
		"xmas_dun01",
		17403,
		300,
		1096,
		"Angeling",
		"ANGELING",
		77,
		5636360
	},

	{
		"xmas_dun01",
		17408,
		300,
		1090,
		"Mastering",
		"MASTERING",
		42,
		1376515
	},

	{
		"xmas_dun02",
		16437,
		300,
		1249,
		"Myst Case",
		"MYSTCASE",
		39,
		3932416
	},

	{
		"xmas_dun02",
		16438,
		300,
		1265,
		"Cookie",
		"COOKIE",
		35,
		3932167
	},

	{
		"xmas_dun02",
		16439,
		300,
		1248,
		"Cruiser",
		"CRUISER",
		41,
		3932416
	},

	{
		"xmas_dun02",
		17236,
		301,
		1251,
		"Knight of Windstorm",
		"KNIGHT_OF_WINDSTORM",
		92,
		5505536
	},

	{
		"xmas_fild01",
		16282,
		300,
		1242,
		"Marin",
		"MARIN",
		37,
		2687235
	},

	{
		"xmas_fild01",
		16283,
		300,
		1243,
		"Sasquatch",
		"SASQUATCH",
		72,
		3932674
	},

	{
		"xmas_fild01",
		16284,
		300,
		1515,
		"Garm Baby",
		"GARM_BABY",
		94,
		2687234
	},

	{
		"xmas_fild01",
		17237,
		301,
		1252,
		"Garm",
		"GARM",
		98,
		5308930
	},

	{
		"yuno_fild01",
		16162,
		300,
		1368,
		"Geographer",
		"GEOGRAPHER",
		73,
		4063491
	},

	{
		"yuno_fild01",
		16163,
		300,
		1114,
		"Dustiness",
		"DUSTINESS",
		62,
		2883588
	},

	{
		"yuno_fild01",
		16164,
		300,
		1139,
		"Mantis",
		"MANTIS",
		65,
		1442052
	},

	{
		"yuno_fild01",
		17516,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild01",
		17517,
		300,
		1079,
		"Blue Plant",
		"BLUE_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild01",
		17518,
		300,
		1083,
		"Shining Plant",
		"SHINING_PLANT",
		1,
		1703939
	},

	{
		"yuno_fild01",
		17519,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild01",
		17523,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild02",
		16165,
		300,
		1386,
		"Sleeper",
		"SLEEPER",
		81,
		2752768
	},

	{
		"yuno_fild02",
		16166,
		300,
		1369,
		"Grand Peco",
		"GRAND_PECO",
		75,
		2818562
	},

	{
		"yuno_fild02",
		16167,
		300,
		1376,
		"Harpy",
		"HARPY",
		83,
		4194566
	},

	{
		"yuno_fild02",
		17524,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild02",
		17525,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild02",
		17526,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild03",
		16168,
		300,
		1376,
		"Harpy",
		"HARPY",
		83,
		4194566
	},

	{
		"yuno_fild03",
		16169,
		300,
		1372,
		"Goat",
		"GOAT",
		80,
		4129026
	},

	{
		"yuno_fild03",
		16170,
		300,
		1386,
		"Sleeper",
		"SLEEPER",
		81,
		2752768
	},

	{
		"yuno_fild03",
		17399,
		300,
		1582,
		"Deviling",
		"DEVILING",
		66,
		5701894
	},

	{
		"yuno_fild03",
		17401,
		300,
		1096,
		"Angeling",
		"ANGELING",
		77,
		5636360
	},

	{
		"yuno_fild03",
		17527,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild03",
		17528,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild03",
		17529,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild03",
		17530,
		300,
		1083,
		"Shining Plant",
		"SHINING_PLANT",
		1,
		1703939
	},

	{
		"yuno_fild03",
		17531,
		300,
		1079,
		"Blue Plant",
		"BLUE_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild04",
		16171,
		300,
		1376,
		"Harpy",
		"HARPY",
		83,
		4194566
	},

	{
		"yuno_fild04",
		16172,
		300,
		1372,
		"Goat",
		"GOAT",
		80,
		4129026
	},

	{
		"yuno_fild04",
		16173,
		300,
		1368,
		"Geographer",
		"GEOGRAPHER",
		73,
		4063491
	},

	{
		"yuno_fild04",
		17398,
		300,
		1388,
		"Archangeling",
		"ARCHANGELING",
		84,
		4325640
	},

	{
		"yuno_fild04",
		17406,
		300,
		1090,
		"Mastering",
		"MASTERING",
		42,
		1376515
	},

	{
		"yuno_fild04",
		17532,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild04",
		17533,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild04",
		17534,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild06",
		16174,
		300,
		1386,
		"Sleeper",
		"SLEEPER",
		81,
		2752768
	},

	{
		"yuno_fild06",
		16175,
		300,
		1368,
		"Geographer",
		"GEOGRAPHER",
		73,
		4063491
	},

	{
		"yuno_fild06",
		17535,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild06",
		17536,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild06",
		17537,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild07",
		16176,
		300,
		1372,
		"Goat",
		"GOAT",
		80,
		4129026
	},

	{
		"yuno_fild07",
		16177,
		300,
		1376,
		"Harpy",
		"HARPY",
		83,
		4194566
	},

	{
		"yuno_fild07",
		16178,
		300,
		1369,
		"Grand Peco",
		"GRAND_PECO",
		75,
		2818562
	},

	{
		"yuno_fild07",
		17538,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild07",
		17539,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild07",
		17540,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild08",
		16179,
		300,
		1369,
		"Grand Peco",
		"GRAND_PECO",
		75,
		2818562
	},

	{
		"yuno_fild08",
		16180,
		300,
		1372,
		"Goat",
		"GOAT",
		80,
		4129026
	},

	{
		"yuno_fild08",
		16181,
		300,
		1368,
		"Geographer",
		"GEOGRAPHER",
		73,
		4063491
	},

	{
		"yuno_fild08",
		17541,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild08",
		17542,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild08",
		17543,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild09",
		16182,
		300,
		1369,
		"Grand Peco",
		"GRAND_PECO",
		75,
		2818562
	},

	{
		"yuno_fild09",
		16183,
		300,
		1386,
		"Sleeper",
		"SLEEPER",
		81,
		2752768
	},

	{
		"yuno_fild09",
		16184,
		300,
		1368,
		"Geographer",
		"GEOGRAPHER",
		73,
		4063491
	},

	{
		"yuno_fild09",
		17544,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild09",
		17545,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild09",
		17546,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild11",
		16185,
		300,
		1372,
		"Goat",
		"GOAT",
		80,
		4129026
	},

	{
		"yuno_fild11",
		16186,
		300,
		1368,
		"Geographer",
		"GEOGRAPHER",
		73,
		4063491
	},

	{
		"yuno_fild11",
		17547,
		300,
		1078,
		"Red Plant",
		"RED_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild11",
		17548,
		300,
		1080,
		"Green Plant",
		"GREEN_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild11",
		17549,
		300,
		1081,
		"Yellow Plant",
		"YELLOW_PLANT",
		1,
		1441795
	},

	{
		"yuno_fild12",
		16187,
		300,
		1368,
		"Geographer",
		"GEOGRAPHER",
		73,
		4063491
	},

	{
		"yuno_fild12",
		16188,
		300,
		1139,
		"Mantis",
		"MANTIS",
		65,
		1442052
	}
}