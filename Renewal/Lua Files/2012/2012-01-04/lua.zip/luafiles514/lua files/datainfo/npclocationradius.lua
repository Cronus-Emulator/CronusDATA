NpcLocationRadius = {

	[jobtbl.JT_GIOIA] = 1,
	[jobtbl.JT_DAEHYON] = 1,
	[jobtbl.JT_KADES] = 1,
}