SetHeadSprEditInfo(pcJobTbl.JT_NOVICE,4,4,0,2,0,35)
SetHeadSprEditInfo(pcJobTbl.JT_NOVICE_B,4,4,0,2,0,35)
SetHeadSprEditInfo(4124,4,4,0,2,0,35)
SetHeadSprEditInfo(4158,4,4,0,2,0,35)

SetHeadSprEditInfo(pcJobTbl.JT_TAEKWON,4,4,0,2,0,35)
SetHeadSprEditInfo(pcJobTbl.JT_TAEKWON,90,90,0,7,0,35)
SetHeadSprEditInfo(4155,4,4,0,2,0,35)
SetHeadSprEditInfo(4155,90,90,0,7,0,35)

SetHeadSprEditInfo(pcJobTbl.JT_STAR,4,4,0,2,0,35)
SetHeadSprEditInfo(pcJobTbl.JT_STAR,99,99,1,1,-6,15)
SetHeadSprEditInfo(pcJobTbl.JT_STAR,100,101,1,1,22,-1)
SetHeadSprEditInfo(4123,4,4,0,2,0,35)
SetHeadSprEditInfo(4123,99,99,1,1,-6,15)
SetHeadSprEditInfo(4123,100,101,1,1,22,-1)

SetHeadSprEditInfo(pcJobTbl.JT_SUPERNOVICE,4,4,0,2,0,35)
SetHeadSprEditInfo(pcJobTbl.JT_SUPERNOVICE_B,4,4,0,2,0,35)
SetHeadSprEditInfo(4128,4,4,0,2,0,35)
SetHeadSprEditInfo(4172,4,4,0,2,0,35)
SetHeadSprEditInfo(pcJobTbl.JT_SUPERNOVICE2,4,4,0,2,0,35)
SetHeadSprEditInfo(pcJobTbl.JT_SUPERNOVICE2_B,4,4,0,2,0,35)

SetBodySprEditInfo_THIEFS()

SetBodySprEditInfo_ACOLYTES()

SetBodySprEditInfo(pcJobTbl.JT_ARCHER_H,4,4,0,2,0,5)
SetBodySprEditInfo(pcJobTbl.JT_ARCHER_H,12,12,0,7,0,5)
SetBodySprEditInfo(4186,4,4,0,2,0,5)
SetBodySprEditInfo(4186,12,12,0,7,0,5)