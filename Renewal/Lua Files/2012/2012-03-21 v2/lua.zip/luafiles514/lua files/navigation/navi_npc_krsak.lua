Navi_Npc = {

	{
		"airplane", -- Map
		10122,
		101,
		831, -- SpriteID
		"����Ʈ���� �ȳ���", --NpcName
		"air1",
		247, -- x
		60 -- y
	},

	{
		"airplane",
		12042,
		101,
		86,
		"Apple Merchant",
		"airplane",
		50,
		66
	},

	{
		"airplane",
		12095,
		101,
		857,
		"Exit",
		"airplane1a",
		240,
		64
	},

	{
		"airplane",
		12096,
		101,
		857,
		"Exit",
		"airplane1b",
		247,
		64
	},

	{
		"airplane",
		12097,
		101,
		857,
		"Exit",
		"airplane2a",
		240,
		40
	},

	{
		"airplane",
		12098,
		101,
		857,
		"Exit",
		"airplane2b",
		247,
		40
	},

	{
		"airplane",
		12149,
		101,
		787,
		"Umbala Kid",
		"ein_p",
		64,
		94
	},

	{
		"airplane",
		12150,
		101,
		783,
		"Umbala Lady",
		"ein_p",
		66,
		93
	},

	{
		"airplane",
		12151,
		101,
		789,
		"Umbala Man",
		"ein_p",
		71,
		91
	},

	{
		"airplane",
		12203,
		101,
		833,
		"Crewman",
		"ein",
		47,
		61
	},

	{
		"airplane",
		12302,
		101,
		67,
		"Airship Staff",
		"airplane",
		250,
		58
	},

	{
		"airplane",
		12303,
		101,
		852,
		"Pilot",
		"airplane",
		221,
		158
	},

	{
		"airplane",
		12304,
		101,
		714,
		"Maelin",
		"01airplane",
		65,
		63
	},

	{
		"airplane",
		12305,
		101,
		834,
		"Zerta",
		"01airplane",
		80,
		71
	},

	{
		"airplane",
		12306,
		101,
		702,
		"Aanos",
		"01airplane",
		72,
		34
	},

	{
		"airplane",
		12751,
		101,
		873,
		"Airship Captain",
		"03",
		236,
		163
	},

	{
		"airplane",
		13056,
		101,
		88,
		"������",
		"",
		238,
		54
	},

	{
		"airplane",
		13206,
		101,
		724,
		"Young Dancer",
		"sch",
		76,
		56
	},

	{
		"airplane",
		13207,
		101,
		724,
		"Cheerful Dancer",
		"sch",
		75,
		53
	},

	{
		"airplane",
		13208,
		101,
		724,
		"Mature Looking Dancer",
		"sch",
		79,
		55
	},

	{
		"airplane",
		19457,
		101,
		878,
		"Eocatt",
		"decoy01",
		246,
		47
	},

	{
		"airplane_01",
		10125,
		101,
		831,
		"����Ʈ���� �ȳ���",
		"air2",
		247,
		61
	},

	{
		"airplane_01",
		12099,
		101,
		857,
		"Exit",
		"airplane_011a",
		240,
		64
	},

	{
		"airplane_01",
		12100,
		101,
		857,
		"Exit",
		"airplane_011b",
		247,
		64
	},

	{
		"airplane_01",
		12101,
		101,
		857,
		"Exit",
		"airplane_012a",
		240,
		40
	},

	{
		"airplane_01",
		12102,
		101,
		857,
		"Exit",
		"airplane_012b",
		247,
		40
	},

	{
		"airplane_01",
		12289,
		101,
		74,
		"Ŭ�󸮽�",
		"airplane",
		33,
		69
	},

	{
		"airplane_01",
		12290,
		101,
		86,
		"Apple Merchant",
		"airplane",
		50,
		66
	},

	{
		"airplane_01",
		12291,
		101,
		49,
		"Nils",
		"ein",
		32,
		61
	},

	{
		"airplane_01",
		12292,
		101,
		873,
		"Airship Captain",
		"02",
		246,
		54
	},

	{
		"airplane_01",
		12293,
		101,
		873,
		"Airship Captain",
		"01",
		238,
		154
	},

	{
		"airplane_01",
		12294,
		101,
		67,
		"Airship Staff",
		"airplane_01",
		250,
		58
	},

	{
		"airplane_01",
		12295,
		101,
		852,
		"Pilot",
		"airplane_01",
		221,
		158
	},

	{
		"airplane_01",
		12299,
		101,
		72,
		"Dianne",
		"01airplane_01",
		83,
		61
	},

	{
		"airplane_01",
		12300,
		101,
		55,
		"Mendel",
		"01airplane_01",
		69,
		63
	},

	{
		"airplane_01",
		12301,
		101,
		106,
		"Swordsman Shimizu",
		"01airplane_01",
		71,
		31
	},

	{
		"airplane_01",
		13420,
		101,
		899,
		"Agent",
		"pc1",
		95,
		61
	},

	{
		"airport",
		12043,
		101,
		90,
		"Airport Staff",
		"airport1a",
		143,
		43
	},

	{
		"airport",
		12046,
		101,
		90,
		"Airport Staff",
		"airport1b",
		158,
		43
	},

	{
		"airport",
		12049,
		101,
		90,
		"Airport Staff",
		"airport1c",
		126,
		43
	},

	{
		"airport",
		12052,
		101,
		90,
		"Arrival Staff",
		"airport2a",
		143,
		49
	},

	{
		"airport",
		12054,
		101,
		90,
		"Arrival Staff",
		"airport2b",
		126,
		51
	},

	{
		"airport",
		12056,
		101,
		90,
		"Arrival Staff",
		"airport2c",
		158,
		50
	},

	{
		"airport",
		12138,
		101,
		99,
		"Young Man",
		"",
		174,
		41
	},

	{
		"airport",
		12139,
		101,
		88,
		"Old Man",
		"",
		176,
		41
	},

	{
		"airport",
		15721,
		101,
		852,
		"Freight Manager",
		"�佺Ʈ",
		148,
		41
	},

	{
		"alb2trea",
		11392,
		101,
		100,
		"Fisk",
		"",
		39,
		50
	},

	{
		"alb2trea",
		15451,
		101,
		117,
		"Kafra Employee",
		"",
		59,
		69
	},

	{
		"alb2trea",
		15553,
		102,
		83,
		"��������",
		"",
		87,
		65
	},

	{
		"alb2trea",
		19525,
		101,
		837,
		"�ָ�",
		"ħ����",
		75,
		101
	},

	{
		"alberta",
		10036,
		101,
		109,
		"���������",
		"",
		104,
		60
	},

	{
		"alberta",
		10110,
		101,
		831,
		"����Ʈ���� �ȳ���",
		"alb",
		92,
		57
	},

	{
		"alberta",
		10940,
		101,
		89,
		"Kinsey",
		"",
		91,
		70
	},

	{
		"alberta",
		10942,
		101,
		709,
		"����",
		"",
		244,
		118
	},

	{
		"alberta",
		10946,
		101,
		121,
		"�ź��̼�����",
		"",
		246,
		114
	},

	{
		"alberta",
		11386,
		101,
		84,
		"Fabian",
		"",
		97,
		51
	},

	{
		"alberta",
		11387,
		101,
		100,
		"Steiner",
		"",
		53,
		39
	},

	{
		"alberta",
		11389,
		101,
		100,
		"Fisk",
		"",
		189,
		151
	},

	{
		"alberta",
		11394,
		101,
		54,
		"Drunken Old Man",
		"",
		131,
		139
	},

	{
		"alberta",
		11395,
		101,
		99,
		"Shakir",
		"",
		58,
		80
	},

	{
		"alberta",
		11396,
		101,
		102,
		"Sonya",
		"",
		62,
		156
	},

	{
		"alberta",
		11397,
		101,
		103,
		"Grandmother Alma",
		"",
		93,
		174
	},

	{
		"alberta",
		11398,
		101,
		86,
		"Paul",
		"",
		195,
		151
	},

	{
		"alberta",
		11400,
		101,
		85,
		"Phelix",
		"",
		190,
		173
	},

	{
		"alberta",
		11403,
		101,
		87,
		"Roving Hair Dresser",
		"",
		33,
		141
	},

	{
		"alberta",
		12547,
		101,
		116,
		"Kafra Voting Staff",
		"alberta",
		119,
		70
	},

	{
		"alberta",
		12589,
		101,
		874,
		"Cool Event Staff",
		"alberta",
		114,
		70
	},

	{
		"alberta",
		13523,
		101,
		998,
		"Continental Messenger",
		"alber_edq",
		127,
		64
	},

	{
		"alberta",
		13682,
		101,
		960,
		"���ں�� ȫ������",
		"0",
		246,
		51
	},

	{
		"alberta",
		13759,
		101,
		100,
		"�긮Ʈȣ ����",
		"bra2",
		246,
		82
	},

	{
		"alberta",
		13857,
		101,
		536,
		"����Ÿ�� ����",
		"alberta",
		212,
		202
	},

	{
		"alberta",
		13997,
		101,
		100,
		"����Ÿ��ȣ ����",
		"alberta",
		196,
		202
	},

	{
		"alberta",
		15115,
		101,
		554,
		"���׳뷽",
		"�˺�",
		200,
		151
	},

	{
		"alberta",
		15434,
		101,
		116,
		"Kafra Employee",
		"",
		28,
		229
	},

	{
		"alberta",
		15438,
		101,
		112,
		"Kafra Employee",
		"",
		113,
		60
	},

	{
		"alberta",
		15481,
		101,
		83,
		"Kafra Employee",
		"",
		26,
		229
	},

	{
		"alberta",
		15628,
		102,
		712,
		"�丮������",
		"",
		167,
		135
	},

	{
		"alberta",
		15749,
		101,
		700,
		"����Ʈ ����",
		"�˺���Ÿ",
		105,
		52
	},

	{
		"alberta",
		15805,
		101,
		105,
		"Guide",
		"01alberta",
		23,
		238
	},

	{
		"alberta",
		15806,
		101,
		105,
		"Guide",
		"02alberta",
		120,
		60
	},

	{
		"alberta",
		15807,
		101,
		105,
		"Guide",
		"03alberta",
		184,
		143
	},

	{
		"alberta",
		18114,
		101,
		71,
		"Hat store girl",
		"new30",
		136,
		79
	},

	{
		"alberta",
		18115,
		101,
		51,
		"Stylish Merchant",
		"new30",
		120,
		53
	},

	{
		"alberta",
		18121,
		101,
		92,
		"Smile Assistance",
		"",
		113,
		53
	},

	{
		"alberta",
		18376,
		101,
		98,
		"Necko",
		"",
		83,
		96
	},

	{
		"alberta",
		18377,
		101,
		107,
		"Charlron",
		"",
		119,
		221
	},

	{
		"alberta",
		18378,
		101,
		57,
		"�Ż�",
		"",
		232,
		103
	},

	{
		"alberta",
		18400,
		101,
		99,
		"Tourist",
		"thai",
		43,
		244
	},

	{
		"alberta",
		18412,
		101,
		709,
		"������ ����",
		"0",
		246,
		74
	},

	{
		"alberta",
		18416,
		101,
		776,
		"��� ȫ�� ���",
		"0",
		246,
		62
	},

	{
		"alberta",
		18423,
		101,
		815,
		"�ٳ�",
		"0",
		246,
		40
	},

	{
		"alberta",
		18427,
		101,
		843,
		"���̹���",
		"0",
		246,
		29
	},

	{
		"alberta",
		18463,
		101,
		837,
		"Bulletin Board",
		"�˺���Ÿ",
		111,
		59
	},

	{
		"alberta",
		18752,
		101,
		86,
		"Bullet Dealer Tony",
		"airplane",
		118,
		160
	},

	{
		"alberta",
		18753,
		101,
		83,
		"Magazine Dealer Tonny",
		"airplane",
		118,
		157
	},

	{
		"alberta",
		18756,
		101,
		99,
		"���׼� ����",
		"",
		168,
		138
	},

	{
		"alberta",
		18760,
		101,
		730,
		"Akagi",
		"",
		30,
		65
	},

	{
		"alberta",
		18859,
		101,
		486,
		"Bard",
		"job_min",
		196,
		133
	},

	{
		"alberta",
		19267,
		101,
		105,
		"Guard",
		"s10",
		98,
		202
	},

	{
		"alberta",
		19268,
		101,
		89,
		"Poor-looking Merchant",
		"",
		43,
		49
	},

	{
		"alberta",
		19480,
		101,
		85,
		"Belder",
		"",
		127,
		143
	},

	{
		"alberta",
		19483,
		101,
		86,
		"Jhonnita",
		"",
		102,
		80
	},

	{
		"alberta",
		19567,
		101,
		729,
		"Eden Teleport Officer",
		"4",
		124,
		67
	},

	{
		"alberta",
		19677,
		101,
		709,
		"Captain Janssen",
		"",
		214,
		77
	},

	{
		"alberta_in",
		10941,
		101,
		120,
		"Grandpa Turtle",
		"",
		23,
		104
	},

	{
		"alberta_in",
		11388,
		101,
		49,
		"û��",
		"",
		20,
		183
	},

	{
		"alberta_in",
		11401,
		101,
		53,
		"Inn Employee",
		"",
		32,
		142
	},

	{
		"alberta_in",
		11402,
		101,
		91,
		"Hair Dresser",
		"",
		55,
		142
	},

	{
		"alberta_in",
		14371,
		101,
		706,
		"Iromo",
		"",
		131,
		95
	},

	{
		"alberta_in",
		14372,
		101,
		53,
		"Iromo's Mother",
		"",
		120,
		93
	},

	{
		"alberta_in",
		15356,
		101,
		84,
		"Louitz",
		"",
		133,
		55
	},

	{
		"alberta_in",
		15364,
		101,
		61,
		"Pharmacist",
		"",
		16,
		28
	},

	{
		"alberta_in",
		15543,
		102,
		73,
		"��������",
		"",
		182,
		97
	},

	{
		"alberta_in",
		15544,
		102,
		74,
		"����ǰ����",
		"",
		165,
		96
	},

	{
		"alberta_in",
		15545,
		102,
		49,
		"�������",
		"",
		188,
		21
	},

	{
		"alberta_in",
		15546,
		102,
		101,
		"������",
		"",
		180,
		15
	},

	{
		"alberta_in",
		15621,
		102,
		82,
		"�������",
		"",
		175,
		97
	},

	{
		"alberta_in",
		18100,
		101,
		47,
		"Cherokee",
		"",
		122,
		53
	},

	{
		"alberta_in",
		18103,
		101,
		120,
		"�л����Ҿƹ���",
		"",
		29,
		140
	},

	{
		"alberta_in",
		18108,
		101,
		125,
		"Monster Tamer",
		"",
		173,
		76
	},

	{
		"alberta_in",
		18200,
		101,
		84,
		"PVP Narrator",
		"",
		22,
		146
	},

	{
		"alberta_in",
		18201,
		101,
		83,
		"Gate Keeper",
		"",
		26,
		146
	},

	{
		"alberta_in",
		18379,
		101,
		84,
		"Xenophon",
		"",
		21,
		63
	},

	{
		"alberta_in",
		18380,
		101,
		86,
		"Kahlamanlith",
		"",
		13,
		71
	},

	{
		"alberta_in",
		18381,
		101,
		85,
		"Fredrik",
		"",
		28,
		58
	},

	{
		"alberta_in",
		18436,
		101,
		86,
		"Repairman",
		"",
		31,
		65
	},

	{
		"alberta_in",
		18492,
		101,
		86,
		"Merchant",
		"",
		53,
		43
	},

	{
		"alberta_in",
		18751,
		102,
		900,
		"��������",
		"",
		176,
		81
	},

	{
		"alberta_in",
		19205,
		101,
		59,
		"Purchasing Team",
		"qskill_buy01",
		58,
		52
	},

	{
		"alberta_in",
		19262,
		101,
		807,
		"Wealthy-looking Merchant",
		"",
		125,
		101
	},

	{
		"alberta_in",
		19263,
		101,
		758,
		"Maid",
		"s10",
		154,
		171
	},

	{
		"alberta_in",
		19266,
		101,
		109,
		"Refined Steward",
		"",
		114,
		178
	},

	{
		"alberta_in",
		19500,
		101,
		788,
		"Shaman",
		"",
		70,
		109
	},

	{
		"alde_alche",
		15497,
		102,
		755,
		"��� �ǸŻ�",
		"alche",
		38,
		184
	},

	{
		"alde_alche",
		15677,
		101,
		740,
		"Guild Dealer",
		"",
		24,
		188
	},

	{
		"alde_alche",
		15690,
		101,
		748,
		"Muscle Man",
		"�˶������",
		88,
		180
	},

	{
		"alde_alche",
		15691,
		101,
		1193,
		" ",
		"�˶������1",
		86,
		184
	},

	{
		"alde_alche",
		15692,
		101,
		1193,
		" ",
		"�˶������2",
		89,
		184
	},

	{
		"alde_alche",
		15693,
		101,
		1193,
		" ",
		"�˶������3",
		92,
		184
	},

	{
		"alde_alche",
		15694,
		101,
		1193,
		" ",
		"�˶������4",
		95,
		184
	},

	{
		"alde_alche",
		15768,
		101,
		883,
		"Craft Book Salesman",
		"alde",
		31,
		186
	},

	{
		"alde_alche",
		19265,
		101,
		749,
		"Alchemist",
		"s",
		169,
		162
	},

	{
		"alde_dun03",
		18135,
		101,
		101,
		"Gatekeeper",
		"����",
		264,
		16
	},

	{
		"alde_gld",
		11996,
		101,
		845,
		"Turbo Track Guide",
		"�Ա�",
		186,
		199
	},

	{
		"alde_gld",
		11997,
		101,
		845,
		"Peco Peco Manager",
		"",
		181,
		199
	},

	{
		"alde_gld",
		11998,
		101,
		837,
		"Sign",
		"�ͺ�Ʈ��",
		178,
		180
	},

	{
		"alde_gld",
		11999,
		101,
		845,
		"�ͺ�Ʈ�� ������",
		"�",
		5,
		5
	},

	{
		"alde_gld",
		17837,
		101,
		722,
		"Neuschwanstein",
		"",
		61,
		87
	},

	{
		"alde_gld",
		17838,
		101,
		722,
		"Neuschwanstein",
		"",
		61,
		79
	},

	{
		"alde_gld",
		17839,
		101,
		722,
		"Neuschwanstein",
		"",
		45,
		87
	},

	{
		"alde_gld",
		17840,
		101,
		722,
		"Neuschwanstein",
		"",
		51,
		87
	},

	{
		"alde_gld",
		17841,
		101,
		722,
		"Hohenschwangau",
		"",
		99,
		251
	},

	{
		"alde_gld",
		17842,
		101,
		722,
		"Hohenschwangau",
		"",
		99,
		244
	},

	{
		"alde_gld",
		17843,
		101,
		722,
		"Nuenberg",
		"",
		146,
		82
	},

	{
		"alde_gld",
		17844,
		101,
		722,
		"��������ũ",
		"",
		138,
		83
	},

	{
		"alde_gld",
		17845,
		101,
		722,
		"Rothenburg",
		"",
		265,
		93
	},

	{
		"alde_gld",
		17846,
		101,
		722,
		"Rothenburg",
		"",
		265,
		87
	},

	{
		"alde_gld",
		18030,
		101,
		549,
		"�����̼ջ�� �ޱ׷���",
		"",
		186,
		157
	},

	{
		"alde_gld",
		18031,
		101,
		421,
		"����Ʈ ������",
		"alde_f00",
		191,
		164
	},

	{
		"alde_gld",
		18033,
		101,
		857,
		"������Ȳ�Խ���",
		"fund04",
		188,
		158
	},

	{
		"aldeba_in",
		12325,
		101,
		859,
		"Kafra Employee",
		"lt3",
		155,
		240
	},

	{
		"aldeba_in",
		15421,
		101,
		113,
		"Kafra Service",
		"",
		96,
		181
	},

	{
		"aldeba_in",
		15456,
		101,
		115,
		"Kafra",
		"",
		79,
		161
	},

	{
		"aldeba_in",
		15554,
		102,
		83,
		"��������",
		"",
		94,
		56
	},

	{
		"aldeba_in",
		15555,
		102,
		49,
		"�������",
		"",
		28,
		54
	},

	{
		"aldeba_in",
		15556,
		102,
		101,
		"������",
		"",
		20,
		60
	},

	{
		"aldeba_in",
		15623,
		102,
		713,
		"�������",
		"",
		22,
		47
	},

	{
		"aldeba_in",
		18080,
		101,
		48,
		"RS125",
		"",
		232,
		241
	},

	{
		"aldeba_in",
		18081,
		101,
		63,
		"Threatening-Looking Man",
		"",
		223,
		121
	},

	{
		"aldeba_in",
		18082,
		101,
		109,
		"Friendly-Looking Man",
		"",
		219,
		61
	},

	{
		"aldeba_in",
		18083,
		101,
		97,
		"Fussy Man",
		"",
		152,
		47
	},

	{
		"aldeba_in",
		18084,
		101,
		61,
		"Master",
		"",
		156,
		179
	},

	{
		"aldeba_in",
		18085,
		101,
		117,
		"Kafra Service",
		"",
		84,
		166
	},

	{
		"aldeba_in",
		18086,
		101,
		116,
		"Kafra Service",
		"",
		83,
		245
	},

	{
		"aldeba_in",
		18087,
		101,
		115,
		"Kafra Jasmine",
		"",
		24,
		245
	},

	{
		"aldeba_in",
		18088,
		101,
		114,
		"Kafra Service",
		"",
		142,
		238
	},

	{
		"aldeba_in",
		18089,
		101,
		112,
		"Kafra Service",
		"",
		91,
		244
	},

	{
		"aldeba_in",
		18096,
		101,
		53,
		"Inn Maid",
		"",
		92,
		58
	},

	{
		"aldeba_in",
		18102,
		101,
		86,
		"Trader",
		"",
		152,
		166
	},

	{
		"aldeba_in",
		18110,
		101,
		125,
		"Monster Tamer",
		"",
		168,
		175
	},

	{
		"aldeba_in",
		18442,
		101,
		86,
		"Repairman",
		"",
		38,
		60
	},

	{
		"aldeba_in",
		18454,
		101,
		115,
		"Kafra",
		"",
		88,
		161
	},

	{
		"aldeba_in",
		18702,
		101,
		709,
		"Tzerero",
		"sp",
		223,
		167
	},

	{
		"aldeba_in",
		19244,
		101,
		805,
		"Sir Jore",
		"",
		155,
		101
	},

	{
		"aldeba_in",
		19245,
		101,
		102,
		"Piru Piru",
		"",
		156,
		118
	},

	{
		"aldebaran",
		10035,
		101,
		109,
		"���������",
		"",
		146,
		116
	},

	{
		"aldebaran",
		10075,
		101,
		105,
		"������������",
		"�˵��ٶ�",
		133,
		112
	},

	{
		"aldebaran",
		12324,
		101,
		116,
		"Kafra Employee",
		"lt3",
		58,
		225
	},

	{
		"aldebaran",
		12554,
		101,
		116,
		"Kafra Voting Staff",
		"aldebaran",
		145,
		102
	},

	{
		"aldebaran",
		12596,
		101,
		874,
		"Cool Event Staff",
		"alde",
		138,
		102
	},

	{
		"aldebaran",
		13524,
		101,
		998,
		"Continental Messenger",
		"alde_edq",
		135,
		128
	},

	{
		"aldebaran",
		13538,
		101,
		96,
		"Girl",
		"prince",
		132,
		184
	},

	{
		"aldebaran",
		14069,
		101,
		100,
		"Promotional Staff",
		"",
		127,
		138
	},

	{
		"aldebaran",
		15098,
		101,
		553,
		"������",
		"�˵�",
		170,
		104
	},

	{
		"aldebaran",
		15416,
		101,
		113,
		"Kafra Employee",
		"",
		143,
		119
	},

	{
		"aldebaran",
		15629,
		102,
		97,
		"�丮������",
		"",
		165,
		107
	},

	{
		"aldebaran",
		15750,
		101,
		700,
		"����Ʈ ����",
		"�˵��ٶ�",
		133,
		114
	},

	{
		"aldebaran",
		15773,
		101,
		105,
		"�ż� ������",
		"�˵��ٶ�",
		133,
		109
	},

	{
		"aldebaran",
		15815,
		101,
		105,
		"Guide",
		"01aldebaran",
		139,
		63
	},

	{
		"aldebaran",
		15816,
		101,
		105,
		"Guide",
		"02aldebaran",
		243,
		143
	},

	{
		"aldebaran",
		15817,
		101,
		105,
		"Guide",
		"03aldebaran",
		135,
		243
	},

	{
		"aldebaran",
		15818,
		101,
		105,
		"Guide",
		"04aldebaran",
		36,
		135
	},

	{
		"aldebaran",
		17796,
		101,
		728,
		"Maroll Battle Recruiter",
		"",
		146,
		109
	},

	{
		"aldebaran",
		17909,
		101,
		722,
		"Neuschwanstein",
		"",
		152,
		97
	},

	{
		"aldebaran",
		17910,
		101,
		722,
		"Hohenschwangau",
		"",
		149,
		97
	},

	{
		"aldebaran",
		17911,
		101,
		722,
		"Nuenberg",
		"",
		134,
		97
	},

	{
		"aldebaran",
		17912,
		101,
		722,
		"Wuerzburg",
		"",
		131,
		97
	},

	{
		"aldebaran",
		17913,
		101,
		722,
		"Rothenburg",
		"",
		128,
		97
	},

	{
		"aldebaran",
		18069,
		101,
		48,
		"Forger Munster",
		"",
		113,
		70
	},

	{
		"aldebaran",
		18070,
		101,
		55,
		"Smithing Guy",
		"",
		64,
		104
	},

	{
		"aldebaran",
		18071,
		101,
		83,
		"Young Man",
		"",
		49,
		93
	},

	{
		"aldebaran",
		18072,
		101,
		101,
		"Shell Gathering Lady",
		"",
		81,
		61
	},

	{
		"aldebaran",
		18073,
		101,
		97,
		"Canal Guy",
		"",
		46,
		129
	},

	{
		"aldebaran",
		18074,
		101,
		98,
		"Forest Guy",
		"",
		67,
		154
	},

	{
		"aldebaran",
		18075,
		101,
		47,
		"Slot Guy",
		"",
		90,
		170
	},

	{
		"aldebaran",
		18076,
		101,
		48,
		"Phracon Guy",
		"",
		117,
		181
	},

	{
		"aldebaran",
		18077,
		101,
		49,
		"Alchemy Guy",
		"",
		121,
		231
	},

	{
		"aldebaran",
		18078,
		101,
		62,
		"Little Kid",
		"",
		86,
		228
	},

	{
		"aldebaran",
		18079,
		101,
		119,
		"Insect Guy",
		"",
		159,
		242
	},

	{
		"aldebaran",
		18090,
		101,
		69,
		"Sylvia",
		"",
		60,
		70
	},

	{
		"aldebaran",
		18091,
		101,
		48,
		"Issei",
		"",
		93,
		80
	},

	{
		"aldebaran",
		18092,
		101,
		88,
		"Joo Jahk",
		"",
		180,
		46
	},

	{
		"aldebaran",
		18093,
		101,
		97,
		"Citizen",
		"",
		212,
		122
	},

	{
		"aldebaran",
		18094,
		101,
		101,
		"Town Girl",
		"",
		146,
		124
	},

	{
		"aldebaran",
		18095,
		101,
		89,
		"Bell Keeper",
		"",
		143,
		136
	},

	{
		"aldebaran",
		18119,
		101,
		92,
		"Smile Assistance",
		"",
		136,
		135
	},

	{
		"aldebaran",
		18238,
		101,
		718,
		"��ũ��Ÿ",
		"",
		168,
		168
	},

	{
		"aldebaran",
		18288,
		101,
		64,
		"Meteurengut",
		"",
		44,
		53
	},

	{
		"aldebaran",
		18464,
		101,
		837,
		"�ָ�",
		"�˵��ٶ�",
		146,
		106
	},

	{
		"aldebaran",
		18703,
		101,
		117,
		"Kafra Employee",
		"sp",
		54,
		238
	},

	{
		"aldebaran",
		18894,
		101,
		486,
		"Karian",
		"cmd8",
		142,
		128
	},

	{
		"aldebaran",
		19506,
		101,
		828,
		"Rogue Agent",
		"nd0",
		114,
		56
	},

	{
		"aldebaran",
		19520,
		101,
		837,
		"Bulletin Board",
		"�ð�ž",
		136,
		133
	},

	{
		"aldebaran",
		19569,
		101,
		729,
		"Eden Teleport Officer",
		"5",
		133,
		119
	},

	{
		"ama_dun01",
		11420,
		101,
		767,
		"Soldier",
		"11",
		229,
		7
	},

	{
		"ama_dun01",
		19547,
		101,
		837,
		"�ָ�",
		"�Ƹ���",
		233,
		14
	},

	{
		"ama_in01",
		11424,
		101,
		761,
		"Grandma",
		"1",
		22,
		111
	},

	{
		"ama_in01",
		11426,
		101,
		769,
		"Shaman",
		"",
		169,
		173
	},

	{
		"ama_in01",
		11427,
		101,
		762,
		"Kitsune Mask",
		"",
		180,
		173
	},

	{
		"ama_in01",
		11428,
		101,
		765,
		"Sushi Master",
		"",
		162,
		17
	},

	{
		"ama_in01",
		15575,
		102,
		763,
		"��������",
		"",
		24,
		30
	},

	{
		"ama_in01",
		15576,
		102,
		757,
		"������",
		"",
		89,
		28
	},

	{
		"ama_in01",
		15577,
		102,
		766,
		"�������",
		"",
		102,
		28
	},

	{
		"ama_in02",
		11406,
		101,
		767,
		"Gate Soldier",
		"3",
		207,
		40
	},

	{
		"ama_in02",
		11407,
		101,
		767,
		"Gate Soldier",
		"4",
		207,
		49
	},

	{
		"ama_in02",
		11410,
		101,
		767,
		"Soldier",
		"1",
		187,
		57
	},

	{
		"ama_in02",
		11411,
		101,
		767,
		"Soldier",
		"2",
		170,
		62
	},

	{
		"ama_in02",
		11412,
		101,
		767,
		"Soldier",
		"3",
		37,
		157
	},

	{
		"ama_in02",
		11413,
		101,
		767,
		"Soldier",
		"4",
		32,
		51
	},

	{
		"ama_in02",
		11414,
		101,
		767,
		"Soldier",
		"5",
		40,
		167
	},

	{
		"ama_in02",
		11415,
		101,
		767,
		"Soldier",
		"6",
		32,
		167
	},

	{
		"ama_in02",
		11416,
		101,
		767,
		"Soldier",
		"7",
		42,
		34
	},

	{
		"ama_in02",
		11417,
		101,
		767,
		"Soldier",
		"8",
		203,
		156
	},

	{
		"ama_in02",
		11418,
		101,
		767,
		"Soldier",
		"9",
		195,
		156
	},

	{
		"ama_in02",
		11419,
		101,
		767,
		"Soldier",
		"10",
		115,
		177
	},

	{
		"ama_in02",
		11423,
		101,
		768,
		"Lord of Palace",
		"",
		200,
		176
	},

	{
		"ama_test",
		11431,
		101,
		109,
		"Assistant",
		"ama",
		52,
		44
	},

	{
		"ama_test",
		11436,
		101,
		766,
		"Grandpa",
		"ama",
		49,
		93
	},

	{
		"ama_test",
		11437,
		101,
		761,
		"Grandma",
		"ama",
		50,
		93
	},

	{
		"ama_test",
		11438,
		101,
		762,
		"Coach",
		"",
		50,
		100
	},

	{
		"amatsu",
		10047,
		101,
		109,
		"���������",
		"",
		102,
		152
	},

	{
		"amatsu",
		11404,
		101,
		767,
		"Gate Soldier",
		"1",
		112,
		164
	},

	{
		"amatsu",
		11405,
		101,
		767,
		"Gate Soldier",
		"2",
		119,
		164
	},

	{
		"amatsu",
		11408,
		101,
		767,
		"Gate Soldier",
		"5",
		164,
		174
	},

	{
		"amatsu",
		11409,
		101,
		767,
		"Gate Soldier",
		"6",
		171,
		174
	},

	{
		"amatsu",
		11425,
		101,
		764,
		"Kouji",
		"",
		189,
		166
	},

	{
		"amatsu",
		11429,
		101,
		763,
		"Publisher",
		"",
		223,
		236
	},

	{
		"amatsu",
		11444,
		101,
		757,
		"Well-side Maiden",
		"",
		230,
		160
	},

	{
		"amatsu",
		11445,
		101,
		86,
		"John",
		"",
		179,
		107
	},

	{
		"amatsu",
		11446,
		101,
		759,
		"Mimi",
		"",
		205,
		163
	},

	{
		"amatsu",
		11447,
		101,
		765,
		"Drunken Man",
		"",
		185,
		115
	},

	{
		"amatsu",
		11448,
		101,
		760,
		"Grandma",
		"",
		217,
		179
	},

	{
		"amatsu",
		11449,
		101,
		766,
		"Jyaburo",
		"",
		287,
		266
	},

	{
		"amatsu",
		11450,
		101,
		758,
		"Propose Girl",
		"",
		269,
		221
	},

	{
		"amatsu",
		11451,
		101,
		760,
		"Drama Teacher",
		"",
		243,
		202
	},

	{
		"amatsu",
		11452,
		101,
		1323,
		"Bonubonu",
		"1",
		283,
		203
	},

	{
		"amatsu",
		11453,
		101,
		735,
		"Veterinarian",
		"",
		274,
		178
	},

	{
		"amatsu",
		13718,
		101,
		758,
		"���ǻ� ����",
		"07russia_42",
		233,
		234
	},

	{
		"amatsu",
		15471,
		101,
		116,
		"Kafra Employee",
		"",
		102,
		149
	},

	{
		"amatsu",
		15635,
		102,
		83,
		"�丮������",
		"",
		206,
		150
	},

	{
		"amatsu",
		15841,
		101,
		758,
		"Amatsu Guide",
		"amatsu",
		202,
		91
	},

	{
		"amatsu",
		18414,
		101,
		709,
		"Sea Captain",
		"1",
		194,
		79
	},

	{
		"amatsu",
		19587,
		101,
		729,
		"������ �����̵���",
		"22",
		100,
		145
	},

	{
		"arena_room",
		11801,
		101,
		97,
		"Vendigos",
		"",
		94,
		93
	},

	{
		"arena_room",
		11802,
		101,
		57,
		"Arena Record Staff",
		"",
		105,
		82
	},

	{
		"arena_room",
		11803,
		101,
		726,
		"Helper Pat",
		"",
		68,
		135
	},

	{
		"arena_room",
		11804,
		101,
		750,
		"Helper Ben",
		"",
		41,
		93
	},

	{
		"arena_room",
		11805,
		101,
		730,
		"Helper Vicious",
		"",
		53,
		49
	},

	{
		"arena_room",
		11806,
		101,
		727,
		"Helper Epin",
		"",
		147,
		49
	},

	{
		"arena_room",
		11807,
		101,
		828,
		"Helper Lunic",
		"",
		158,
		93
	},

	{
		"arena_room",
		11808,
		101,
		828,
		"Helper Lonik",
		"",
		158,
		82
	},

	{
		"arena_room",
		11809,
		101,
		55,
		"Teleporter",
		"arena",
		105,
		93
	},

	{
		"arena_room",
		11835,
		101,
		79,
		"Arena Record Staff",
		"acolyte",
		94,
		82
	},

	{
		"arena_room",
		11836,
		101,
		729,
		"Guide Alias",
		"",
		140,
		136
	},

	{
		"aru_gld",
		17935,
		101,
		722,
		"Mardol",
		"",
		164,
		270
	},

	{
		"aru_gld",
		17936,
		101,
		722,
		"Mardol",
		"",
		142,
		235
	},

	{
		"aru_gld",
		17937,
		101,
		722,
		"Mardol",
		"",
		164,
		245
	},

	{
		"aru_gld",
		17938,
		101,
		722,
		"Mardol",
		"",
		182,
		255
	},

	{
		"aru_gld",
		17939,
		101,
		722,
		"Cyr",
		"",
		80,
		41
	},

	{
		"aru_gld",
		17940,
		101,
		722,
		"Cyr",
		"",
		80,
		52
	},

	{
		"aru_gld",
		17941,
		101,
		722,
		"Cyr",
		"",
		120,
		83
	},

	{
		"aru_gld",
		17942,
		101,
		722,
		"Horn",
		"",
		60,
		174
	},

	{
		"aru_gld",
		17943,
		101,
		722,
		"Horn",
		"",
		74,
		174
	},

	{
		"aru_gld",
		17944,
		101,
		722,
		"Gefn",
		"",
		306,
		359
	},

	{
		"aru_gld",
		17945,
		101,
		722,
		"Gefn",
		"",
		306,
		348
	},

	{
		"aru_gld",
		17946,
		101,
		722,
		"Gefn",
		"",
		301,
		318
	},

	{
		"aru_gld",
		17947,
		101,
		722,
		"Gefn",
		"",
		313,
		318
	},

	{
		"aru_gld",
		17948,
		101,
		722,
		"Banadis",
		"",
		289,
		103
	},

	{
		"aru_gld",
		17949,
		101,
		722,
		"Banadis",
		"",
		289,
		112
	},

	{
		"aru_gld",
		17950,
		101,
		722,
		"Banadis",
		"",
		350,
		98
	},

	{
		"aru_gld",
		17951,
		101,
		722,
		"Banadis",
		"",
		350,
		88
	},

	{
		"arug_dun01",
		14303,
		101,
		826,
		"Dwarf",
		"aru_gd",
		199,
		195
	},

	{
		"arug_dun01",
		14368,
		101,
		81,
		"Event controller",
		"aru_gd",
		5,
		5
	},

	{
		"arug_que01",
		14309,
		101,
		715,
		"Pierrot Pier",
		"aru_gd",
		100,
		81
	},

	{
		"arug_que01",
		14310,
		101,
		81,
		"Controller",
		"gdevent_a",
		10,
		10
	},

	{
		"arug_que01",
		14311,
		101,
		412,
		"Gergath",
		"aru_gd",
		100,
		75
	},

	{
		"arug_que01",
		14313,
		101,
		978,
		"",
		"aru_flower_01",
		98,
		105
	},

	{
		"arug_que01",
		14314,
		101,
		977,
		"",
		"aru_flower_02",
		94,
		105
	},

	{
		"arug_que01",
		14315,
		101,
		978,
		"",
		"aru_flower_03",
		90,
		105
	},

	{
		"arug_que01",
		14316,
		101,
		977,
		"",
		"aru_flower_04",
		86,
		105
	},

	{
		"arug_que01",
		14317,
		101,
		978,
		"",
		"aru_flower_05",
		82,
		105
	},

	{
		"arug_que01",
		14318,
		101,
		977,
		"",
		"aru_flower_06",
		79,
		103
	},

	{
		"arug_que01",
		14319,
		101,
		978,
		"",
		"aru_flower_07",
		79,
		100
	},

	{
		"arug_que01",
		14320,
		101,
		977,
		"",
		"aru_flower_08",
		79,
		97
	},

	{
		"arug_que01",
		14322,
		101,
		977,
		"",
		"aru_flower_10",
		79,
		94
	},

	{
		"arug_que01",
		14323,
		101,
		978,
		"",
		"aru_flower_11",
		79,
		91
	},

	{
		"arug_que01",
		14324,
		101,
		977,
		"",
		"aru_flower_12",
		79,
		88
	},

	{
		"arug_que01",
		14325,
		101,
		978,
		"",
		"aru_flower_13",
		79,
		85
	},

	{
		"arug_que01",
		14326,
		101,
		977,
		"",
		"aru_flower_14",
		79,
		82
	},

	{
		"arug_que01",
		14327,
		101,
		978,
		"",
		"aru_flower_15",
		79,
		79
	},

	{
		"arug_que01",
		14328,
		101,
		977,
		"",
		"aru_flower_16",
		79,
		76
	},

	{
		"arug_que01",
		14329,
		101,
		978,
		"",
		"aru_flower_17",
		79,
		73
	},

	{
		"arug_que01",
		14330,
		101,
		977,
		"",
		"aru_flower_18",
		79,
		70
	},

	{
		"arug_que01",
		14331,
		101,
		978,
		"",
		"aru_flower_19",
		79,
		67
	},

	{
		"arug_que01",
		14332,
		101,
		977,
		"",
		"aru_flower_20",
		79,
		64
	},

	{
		"arug_que01",
		14333,
		101,
		978,
		"",
		"aru_flower_21",
		79,
		61
	},

	{
		"arug_que01",
		14334,
		101,
		977,
		"",
		"aru_flower_22",
		79,
		58
	},

	{
		"arug_que01",
		14335,
		101,
		978,
		"",
		"aru_flower_22",
		84,
		58
	},

	{
		"arug_que01",
		14336,
		101,
		977,
		"",
		"aru_flower_23",
		89,
		58
	},

	{
		"arug_que01",
		14337,
		101,
		978,
		"",
		"aru_flower_24",
		94,
		58
	},

	{
		"arug_que01",
		14338,
		101,
		977,
		"",
		"aru_flower_25",
		99,
		58
	},

	{
		"arug_que01",
		14339,
		101,
		978,
		"",
		"aru_flower_26",
		104,
		58
	},

	{
		"arug_que01",
		14340,
		101,
		977,
		"",
		"aru_flower_27",
		109,
		58
	},

	{
		"arug_que01",
		14341,
		101,
		978,
		"",
		"aru_flower_28",
		114,
		58
	},

	{
		"arug_que01",
		14342,
		101,
		977,
		"",
		"aru_flower_29",
		119,
		58
	},

	{
		"arug_que01",
		14343,
		101,
		978,
		"",
		"aru_flower_30",
		124,
		58
	},

	{
		"arug_que01",
		14344,
		101,
		977,
		"",
		"aru_flower_31",
		129,
		58
	},

	{
		"arug_que01",
		14345,
		101,
		978,
		"",
		"aru_flower_32",
		129,
		105
	},

	{
		"arug_que01",
		14346,
		101,
		977,
		"",
		"aru_flower_33",
		129,
		103
	},

	{
		"arug_que01",
		14347,
		101,
		978,
		"",
		"aru_flower_34",
		129,
		100
	},

	{
		"arug_que01",
		14348,
		101,
		977,
		"",
		"aru_flower_35",
		129,
		97
	},

	{
		"arug_que01",
		14350,
		101,
		977,
		"",
		"aru_flower_37",
		129,
		94
	},

	{
		"arug_que01",
		14351,
		101,
		978,
		"",
		"aru_flower_38",
		129,
		91
	},

	{
		"arug_que01",
		14352,
		101,
		977,
		"",
		"aru_flower_39",
		129,
		88
	},

	{
		"arug_que01",
		14353,
		101,
		978,
		"",
		"aru_flower_40",
		129,
		85
	},

	{
		"arug_que01",
		14354,
		101,
		977,
		"",
		"aru_flower_41",
		129,
		82
	},

	{
		"arug_que01",
		14355,
		101,
		978,
		"",
		"aru_flower_42",
		129,
		79
	},

	{
		"arug_que01",
		14356,
		101,
		977,
		"",
		"aru_flower_43",
		129,
		76
	},

	{
		"arug_que01",
		14357,
		101,
		978,
		"",
		"aru_flower_44",
		129,
		73
	},

	{
		"arug_que01",
		14358,
		101,
		977,
		"",
		"aru_flower_45",
		129,
		70
	},

	{
		"arug_que01",
		14359,
		101,
		978,
		"",
		"aru_flower_46",
		129,
		67
	},

	{
		"arug_que01",
		14360,
		101,
		977,
		"",
		"aru_flower_47",
		129,
		64
	},

	{
		"arug_que01",
		14361,
		101,
		978,
		"",
		"aru_flower_48",
		129,
		61
	},

	{
		"arug_que01",
		14363,
		101,
		978,
		"",
		"aru_flower_50",
		124,
		105
	},

	{
		"arug_que01",
		14364,
		101,
		977,
		"",
		"aru_flower_50",
		119,
		105
	},

	{
		"arug_que01",
		14365,
		101,
		978,
		"",
		"aru_flower_50",
		114,
		105
	},

	{
		"arug_que01",
		14366,
		101,
		977,
		"",
		"aru_flower_50",
		109,
		105
	},

	{
		"arug_que01",
		14367,
		101,
		976,
		"",
		"aru_flower_50",
		104,
		105
	},

	{
		"ayo_fild02",
		11933,
		101,
		843,
		"Aik",
		"thai",
		25,
		154
	},

	{
		"ayo_fild02",
		19550,
		101,
		837,
		"�ָ�",
		"�̿��Ÿ",
		279,
		147
	},

	{
		"ayo_in01",
		15589,
		102,
		840,
		"��������",
		"",
		18,
		182
	},

	{
		"ayo_in01",
		15590,
		102,
		842,
		"������",
		"",
		90,
		160
	},

	{
		"ayo_in01",
		15591,
		102,
		843,
		"�������",
		"",
		90,
		192
	},

	{
		"ayothaya",
		10048,
		101,
		109,
		"���������",
		"",
		212,
		173
	},

	{
		"ayothaya",
		11919,
		101,
		843,
		"Young Man",
		"��",
		189,
		120
	},

	{
		"ayothaya",
		11920,
		101,
		838,
		"Girl",
		"������",
		171,
		152
	},

	{
		"ayothaya",
		11921,
		101,
		842,
		"Old Man",
		"�ƿ�Ÿ��",
		143,
		102
	},

	{
		"ayothaya",
		11922,
		101,
		841,
		"Young Man",
		"1�ƿ�Ÿ��",
		197,
		189
	},

	{
		"ayothaya",
		11923,
		101,
		843,
		"Young Man",
		"5�ƿ�Ÿ��",
		214,
		142
	},

	{
		"ayothaya",
		11924,
		101,
		843,
		"Young Man",
		"6�ƿ�Ÿ��",
		241,
		264
	},

	{
		"ayothaya",
		15477,
		101,
		116,
		"Kafra Employee",
		"",
		212,
		169
	},

	{
		"ayothaya",
		15638,
		102,
		83,
		"�丮������",
		"",
		203,
		178
	},

	{
		"ayothaya",
		15842,
		101,
		839,
		"Ayothaya Guide Noi",
		"01ayothaya",
		203,
		169
	},

	{
		"ayothaya",
		15843,
		101,
		839,
		"Ayothaya Guide Noa",
		"02ayothaya",
		146,
		86
	},

	{
		"ayothaya",
		19589,
		101,
		729,
		"������ �����̵���",
		"23",
		221,
		191
	},

	{
		"bat_room",
		15493,
		101,
		861,
		"Kafra Staff",
		"",
		148,
		147
	},

	{
		"bat_room",
		17762,
		101,
		418,
		"KVM [1-59] Officer",
		"01a",
		124,
		178
	},

	{
		"bat_room",
		17763,
		101,
		414,
		"Tierra Gorge Officer",
		"01b",
		125,
		121
	},

	{
		"bat_room",
		17764,
		101,
		418,
		"Flavius Officer",
		"01a",
		133,
		178
	},

	{
		"bat_room",
		17765,
		101,
		414,
		"Flavius Officer",
		"01b",
		133,
		121
	},

	{
		"bat_room",
		17770,
		101,
		416,
		"Prince Croix",
		"",
		160,
		141
	},

	{
		"bat_room",
		17771,
		101,
		415,
		"Prince Croix's Aide",
		"01",
		161,
		140
	},

	{
		"bat_room",
		17772,
		101,
		415,
		"Prince Croix's Aide",
		"02",
		161,
		142
	},

	{
		"bat_room",
		17773,
		101,
		420,
		"General Guillaume",
		"",
		160,
		159
	},

	{
		"bat_room",
		17774,
		101,
		419,
		"Gen. Guillaume's Aide",
		"01",
		161,
		158
	},

	{
		"bat_room",
		17775,
		101,
		419,
		"Gen. Guillaume's Aide",
		"03",
		161,
		160
	},

	{
		"bat_room",
		17776,
		101,
		417,
		"Guillaume Knight",
		"",
		127,
		178
	},

	{
		"bat_room",
		17777,
		101,
		417,
		"Guillaume Knight",
		"",
		135,
		178
	},

	{
		"bat_room",
		17778,
		101,
		417,
		"Guillaume Knight",
		"",
		143,
		178
	},

	{
		"bat_room",
		17779,
		101,
		417,
		"Guillaume Knight",
		"",
		151,
		178
	},

	{
		"bat_room",
		17780,
		101,
		413,
		"Croix Knight",
		"",
		127,
		121
	},

	{
		"bat_room",
		17781,
		101,
		413,
		"Croix Knight",
		"",
		135,
		121
	},

	{
		"bat_room",
		17782,
		101,
		413,
		"Croix Knight",
		"",
		143,
		121
	},

	{
		"bat_room",
		17783,
		101,
		413,
		"Croix Knight",
		"",
		151,
		121
	},

	{
		"bat_room",
		17784,
		101,
		124,
		"Teleporter",
		"����",
		148,
		150
	},

	{
		"bat_room",
		17806,
		101,
		109,
		"Erundek",
		"",
		160,
		150
	},

	{
		"bat_room",
		19722,
		101,
		418,
		"KVM Mercenary Officer",
		"���",
		164,
		178
	},

	{
		"bat_room",
		19723,
		101,
		417,
		"Guillaume Knight",
		"kvm",
		167,
		178
	},

	{
		"bat_room",
		19724,
		101,
		414,
		"KVM Mercenary Officer",
		"ũ���",
		164,
		121
	},

	{
		"bat_room",
		19725,
		101,
		413,
		"Croix Knight",
		"kvm",
		167,
		121
	},

	{
		"bat_room",
		19732,
		101,
		734,
		"KVM Logistic Officer",
		"kvm01",
		151,
		144
	},

	{
		"bif_fild02",
		14898,
		101,
		844,
		"���� ����",
		"ep14_mora1",
		285,
		332
	},

	{
		"bif_fild02",
		14900,
		101,
		844,
		"���� ����",
		"ep14_mora2",
		95,
		310
	},

	{
		"bif_fild02",
		14902,
		101,
		844,
		"���� ����",
		"ep14_mora3",
		173,
		162
	},

	{
		"bif_fild02",
		15239,
		101,
		421,
		"������ �����̵��� 2ȣ",
		"",
		293,
		325
	},

	{
		"bra_dun01",
		19552,
		101,
		837,
		"�ָ�",
		"���������",
		208,
		109
	},

	{
		"bra_fild01",
		13733,
		101,
		1057,
		"",
		"������bra",
		245,
		53
	},

	{
		"bra_in01",
		13756,
		101,
		478,
		"Hotel Keeper",
		"bra1",
		27,
		24
	},

	{
		"brasilis",
		10052,
		101,
		109,
		"���������",
		"",
		200,
		224
	},

	{
		"brasilis",
		13750,
		101,
		85,
		"Ice-Cream Maker",
		"",
		137,
		77
	},

	{
		"brasilis",
		13751,
		101,
		858,
		"Signpost",
		"bra",
		155,
		165
	},

	{
		"brasilis",
		13752,
		101,
		858,
		"�ȳ�ǥ����",
		"bra",
		191,
		239
	},

	{
		"brasilis",
		13753,
		101,
		858,
		"Signpost",
		"bra",
		240,
		247
	},

	{
		"brasilis",
		13754,
		101,
		858,
		"Signpost",
		"bra",
		303,
		309
	},

	{
		"brasilis",
		13755,
		101,
		858,
		"Signpost",
		"bra",
		278,
		137
	},

	{
		"brasilis",
		13757,
		101,
		100,
		"Crewman",
		"bra1",
		316,
		57
	},

	{
		"brasilis",
		15491,
		101,
		117,
		"Kafra Employee",
		"",
		197,
		221
	},

	{
		"brasilis",
		15671,
		102,
		477,
		"���ϻ���",
		"bra",
		221,
		128
	},

	{
		"brasilis",
		15672,
		102,
		476,
		"���ֻ̹���",
		"bra",
		201,
		309
	},

	{
		"brasilis",
		15673,
		102,
		477,
		"�������",
		"",
		244,
		243
	},

	{
		"brasilis",
		15674,
		102,
		478,
		"��������",
		"",
		252,
		257
	},

	{
		"brasilis",
		15848,
		101,
		478,
		"Brasilis Guide",
		"",
		219,
		97
	},

	{
		"brasilis",
		19597,
		101,
		729,
		"������ �����̵���",
		"27",
		191,
		224
	},

	{
		"c_tower3",
		18133,
		101,
		84,
		"Gatekeeper",
		"����",
		10,
		249
	},

	{
		"cmd_fild07",
		15458,
		101,
		721,
		"Kafra Employee",
		"",
		136,
		134
	},

	{
		"cmd_fild07",
		15565,
		102,
		83,
		"��������",
		"",
		257,
		126
	},

	{
		"cmd_fild07",
		15566,
		102,
		49,
		"�������",
		"",
		250,
		98
	},

	{
		"cmd_fild07",
		15567,
		102,
		101,
		"������",
		"",
		277,
		85
	},

	{
		"cmd_fild07",
		18273,
		101,
		100,
		"Rahasu",
		"",
		192,
		58
	},

	{
		"cmd_fild07",
		18274,
		101,
		100,
		"Hallosu",
		"",
		52,
		280
	},

	{
		"cmd_fild07",
		18275,
		101,
		100,
		"Zain",
		"",
		299,
		83
	},

	{
		"cmd_fild07",
		18278,
		101,
		100,
		"Sarumane",
		"",
		94,
		134
	},

	{
		"cmd_fild08",
		19511,
		101,
		837,
		"�ָ�",
		"��������1",
		326,
		357
	},

	{
		"cmd_fild08",
		19512,
		101,
		837,
		"�ָ�",
		"��������2",
		341,
		84
	},

	{
		"cmd_in01",
		15561,
		102,
		83,
		"��������",
		"",
		79,
		182
	},

	{
		"cmd_in01",
		15562,
		102,
		49,
		"�������",
		"",
		128,
		165
	},

	{
		"cmd_in01",
		15563,
		102,
		101,
		"������",
		"",
		117,
		165
	},

	{
		"cmd_in01",
		19261,
		101,
		724,
		"Examiner",
		"s",
		33,
		25
	},

	{
		"cmd_in02",
		11870,
		101,
		828,
		"Man",
		"�ޱ�",
		190,
		94
	},

	{
		"cmd_in02",
		13421,
		101,
		97,
		"Ordinary Man",
		"pc1",
		174,
		89
	},

	{
		"cmd_in02",
		13422,
		101,
		97,
		"Ordinary Man",
		"pc2",
		111,
		52
	},

	{
		"cmd_in02",
		15457,
		101,
		721,
		"Kafra Employee",
		"",
		146,
		180
	},

	{
		"cmd_in02",
		18258,
		101,
		49,
		"Chief",
		"",
		32,
		140
	},

	{
		"cmd_in02",
		18259,
		101,
		48,
		"Martine",
		"",
		73,
		81
	},

	{
		"cmd_in02",
		18260,
		101,
		51,
		"Scoursege",
		"",
		48,
		55
	},

	{
		"cmd_in02",
		18261,
		101,
		709,
		"Roberto",
		"",
		64,
		43
	},

	{
		"cmd_in02",
		18262,
		101,
		89,
		"Deniroz",
		"",
		89,
		72
	},

	{
		"cmd_in02",
		18263,
		101,
		101,
		"Shalone",
		"",
		178,
		92
	},

	{
		"cmd_in02",
		18264,
		101,
		98,
		"Stonae",
		"",
		178,
		86
	},

	{
		"cmd_in02",
		18265,
		101,
		86,
		"G . J",
		"",
		172,
		105
	},

	{
		"cmd_in02",
		18266,
		101,
		83,
		"Loyar",
		"",
		174,
		126
	},

	{
		"cmd_in02",
		18267,
		101,
		109,
		"Moo",
		"",
		57,
		62
	},

	{
		"cmd_in02",
		18285,
		101,
		85,
		"Manzi",
		"",
		189,
		99
	},

	{
		"cmd_in02",
		19260,
		101,
		806,
		"Strange Guy",
		"s",
		88,
		51
	},

	{
		"cmd_in02",
		19488,
		101,
		828,
		"Investigator",
		"",
		94,
		208
	},

	{
		"comodo",
		10008,
		101,
		109,
		"Ledrion",
		"comodo",
		71,
		137
	},

	{
		"comodo",
		10009,
		101,
		86,
		"Gatan",
		"comodo",
		236,
		197
	},

	{
		"comodo",
		10010,
		101,
		731,
		"Bafhail",
		"comodo",
		152,
		184
	},

	{
		"comodo",
		10011,
		101,
		706,
		"Lospii",
		"comodo",
		64,
		219
	},

	{
		"comodo",
		10046,
		101,
		109,
		"���������",
		"",
		199,
		149
	},

	{
		"comodo",
		10088,
		101,
		562,
		"ī�弼����RX2",
		"0001",
		144,
		298
	},

	{
		"comodo",
		11582,
		101,
		84,
		"La Ed",
		"",
		170,
		137
	},

	{
		"comodo",
		11583,
		101,
		92,
		"Haith",
		"",
		171,
		137
	},

	{
		"comodo",
		13225,
		101,
		809,
		"Young Man",
		"sch",
		135,
		299
	},

	{
		"comodo",
		15461,
		101,
		721,
		"Kafra Employee",
		"",
		195,
		150
	},

	{
		"comodo",
		15564,
		102,
		101,
		"���ǰ����",
		"",
		296,
		125
	},

	{
		"comodo",
		15630,
		102,
		83,
		"�丮������",
		"",
		225,
		164
	},

	{
		"comodo",
		15675,
		102,
		724,
		"������� ����",
		"",
		106,
		213
	},

	{
		"comodo",
		15676,
		102,
		479,
		"�ϸ���",
		"ĵ�����",
		196,
		162
	},

	{
		"comodo",
		15699,
		101,
		732,
		"Meruntei",
		"",
		237,
		217
	},

	{
		"comodo",
		15751,
		101,
		700,
		"����Ʈ ����",
		"�ڸ�",
		193,
		159
	},

	{
		"comodo",
		15782,
		101,
		69,
		"���ھ��",
		"�Ӹ���",
		236,
		164
	},

	{
		"comodo",
		15819,
		101,
		700,
		"Comodo Guide",
		"",
		322,
		178
	},

	{
		"comodo",
		15820,
		101,
		700,
		"Comodo Guide",
		"02comodo",
		181,
		347
	},

	{
		"comodo",
		15821,
		101,
		700,
		"Comodo Guide",
		"03comodo",
		197,
		149
	},

	{
		"comodo",
		15822,
		101,
		700,
		"Comodo Guide",
		"04comodo",
		37,
		219
	},

	{
		"comodo",
		18112,
		101,
		700,
		"Hair Ornament Girl",
		"",
		228,
		159
	},

	{
		"comodo",
		18113,
		101,
		702,
		"Traveler",
		"",
		273,
		137
	},

	{
		"comodo",
		18249,
		101,
		704,
		"Campground Boy",
		"",
		206,
		310
	},

	{
		"comodo",
		18250,
		101,
		65,
		"Camping Youth",
		"",
		204,
		310
	},

	{
		"comodo",
		18251,
		101,
		71,
		"Camping Maiden",
		"",
		209,
		305
	},

	{
		"comodo",
		18252,
		101,
		706,
		"Campground Lad",
		"",
		209,
		314
	},

	{
		"comodo",
		18253,
		101,
		86,
		"BBQ Boy",
		"",
		221,
		310
	},

	{
		"comodo",
		18254,
		101,
		90,
		"BBQ Visitor",
		"",
		218,
		309
	},

	{
		"comodo",
		18255,
		101,
		50,
		"BBQ Papa",
		"",
		216,
		310
	},

	{
		"comodo",
		18256,
		101,
		74,
		"BBQ Mama",
		"",
		215,
		307
	},

	{
		"comodo",
		18257,
		101,
		706,
		"BBQ Boy",
		"",
		213,
		310
	},

	{
		"comodo",
		18281,
		101,
		109,
		"Toruna",
		"",
		88,
		97
	},

	{
		"comodo",
		18282,
		101,
		73,
		"Rakusa",
		"",
		164,
		291
	},

	{
		"comodo",
		18283,
		101,
		98,
		"Kichiri",
		"",
		169,
		284
	},

	{
		"comodo",
		18284,
		101,
		55,
		"Magatu",
		"",
		163,
		280
	},

	{
		"comodo",
		18286,
		101,
		701,
		"Hullaris",
		"",
		187,
		153
	},

	{
		"comodo",
		18290,
		101,
		106,
		"Won",
		"",
		232,
		87
	},

	{
		"comodo",
		18402,
		101,
		120,
		"Old Man",
		"thai",
		68,
		195
	},

	{
		"comodo",
		18408,
		101,
		103,
		"Munak's Grandma",
		"",
		112,
		182
	},

	{
		"comodo",
		18455,
		101,
		91,
		"Kachua",
		"",
		219,
		158
	},

	{
		"comodo",
		18456,
		101,
		90,
		"Devellin",
		"",
		204,
		148
	},

	{
		"comodo",
		18457,
		101,
		118,
		"Suspicious Guy",
		"",
		210,
		154
	},

	{
		"comodo",
		18466,
		101,
		837,
		"Bulletin Board",
		"�ڸ�",
		210,
		148
	},

	{
		"comodo",
		18597,
		101,
		741,
		"������ ��������",
		"",
		211,
		155
	},

	{
		"comodo",
		18603,
		101,
		90,
		"Sonotora",
		"1",
		180,
		153
	},

	{
		"comodo",
		18604,
		101,
		86,
		"Bor Robin",
		"1",
		193,
		151
	},

	{
		"comodo",
		18711,
		101,
		730,
		"Wandering Master",
		"job_star",
		172,
		230
	},

	{
		"comodo",
		18890,
		101,
		486,
		"Karian",
		"cmd6",
		184,
		109
	},

	{
		"comodo",
		18891,
		101,
		98,
		"Kayak Master",
		"job_min",
		192,
		119
	},

	{
		"comodo",
		18892,
		101,
		701,
		"Woman Roasting Meat",
		"job_min",
		159,
		316
	},

	{
		"comodo",
		18910,
		101,
		479,
		"Cheerless Minstrel",
		"",
		140,
		86
	},

	{
		"comodo",
		19192,
		101,
		724,
		"Canell",
		"qsk_dan01",
		204,
		172
	},

	{
		"comodo",
		19479,
		101,
		86,
		"Muff",
		"",
		224,
		187
	},

	{
		"comodo",
		19498,
		101,
		881,
		"Man in Hiding",
		"nd",
		339,
		224
	},

	{
		"comodo",
		19499,
		101,
		742,
		"Scholar",
		"",
		139,
		184
	},

	{
		"comodo",
		19509,
		101,
		810,
		"Rogue Guild Agent",
		"nd3",
		233,
		199
	},

	{
		"comodo",
		19526,
		101,
		837,
		"�ָ�",
		"�ڸ𵵵�",
		327,
		177
	},

	{
		"comodo",
		19527,
		101,
		837,
		"�ָ�",
		"�ڸ𵵼�",
		31,
		217
	},

	{
		"comodo",
		19528,
		101,
		837,
		"�ָ�",
		"�ڸ𵵺�",
		178,
		354
	},

	{
		"comodo",
		19577,
		101,
		729,
		"������ �����̵���",
		"17",
		202,
		151
	},

	{
		"comodo",
		19646,
		101,
		55,
		"������ �İߴܿ�",
		"2nd02",
		173,
		354
	},

	{
		"dew_dun01",
		13861,
		101,
		541,
		"ũ��ī�� ȭ�� ������",
		"dew_dun01",
		292,
		164
	},

	{
		"dew_dun01",
		19553,
		101,
		837,
		"�ָ�",
		"����Ÿȭ��",
		294,
		158
	},

	{
		"dew_fild01",
		13855,
		101,
		541,
		"��Ƽ ���� ������",
		"dew_fild01",
		101,
		259
	},

	{
		"dew_fild01",
		13856,
		101,
		541,
		"��Ƽ ���� ���� ����",
		"dew_fild01",
		106,
		306
	},

	{
		"dew_fild01",
		13863,
		101,
		813,
		"��Ƽ",
		"weapon",
		127,
		240
	},

	{
		"dew_fild01",
		13866,
		101,
		541,
		"��Ƽ ���� ����",
		"dew_fild01",
		78,
		288
	},

	{
		"dew_fild01",
		13867,
		101,
		541,
		"���� ��� ������",
		"dew_fild01",
		185,
		300
	},

	{
		"dew_fild01",
		19554,
		101,
		837,
		"�ָ�",
		"����Ÿ ����",
		51,
		61
	},

	{
		"dewata",
		10054,
		101,
		109,
		"���������",
		"",
		202,
		188
	},

	{
		"dewata",
		13813,
		101,
		536,
		"���ڿ��� û��",
		"���ʹ�1",
		221,
		237
	},

	{
		"dewata",
		13814,
		101,
		536,
		"������ û��",
		"���ʹ�2",
		114,
		243
	},

	{
		"dewata",
		13815,
		101,
		881,
		"������",
		"���ʹ�3",
		159,
		81
	},

	{
		"dewata",
		13816,
		101,
		886,
		"�Ĵ� ����",
		"���ʹ�4",
		146,
		109
	},

	{
		"dewata",
		13817,
		101,
		85,
		"�̽İ�",
		"���ʹ�5",
		147,
		107
	},

	{
		"dewata",
		13818,
		101,
		86,
		"�������� ������",
		"���ʹ�6",
		154,
		107
	},

	{
		"dewata",
		13819,
		101,
		536,
		"���� ���̵�",
		"���ʹ�7",
		95,
		203
	},

	{
		"dewata",
		13820,
		101,
		803,
		"������",
		"A",
		97,
		207
	},

	{
		"dewata",
		13821,
		101,
		59,
		"������",
		"B",
		100,
		206
	},

	{
		"dewata",
		13822,
		101,
		90,
		"������",
		"C",
		101,
		206
	},

	{
		"dewata",
		13823,
		101,
		755,
		"������",
		"D",
		99,
		203
	},

	{
		"dewata",
		13824,
		101,
		834,
		"�·�",
		"A",
		67,
		186
	},

	{
		"dewata",
		13825,
		101,
		834,
		"�·�",
		"B",
		65,
		188
	},

	{
		"dewata",
		13826,
		101,
		834,
		"�·�",
		"C",
		63,
		190
	},

	{
		"dewata",
		13827,
		101,
		834,
		"�·�",
		"D",
		62,
		192
	},

	{
		"dewata",
		13828,
		101,
		834,
		"�·�",
		"Ÿ��A",
		75,
		122
	},

	{
		"dewata",
		13829,
		101,
		834,
		"�·�",
		"Ÿ��B",
		69,
		101
	},

	{
		"dewata",
		13830,
		101,
		834,
		"�·�",
		"Ÿ��C",
		71,
		79
	},

	{
		"dewata",
		13831,
		101,
		534,
		"��� ����",
		"���ʹ�8",
		211,
		272
	},

	{
		"dewata",
		13832,
		101,
		536,
		"��� ������",
		"���ʹ�9",
		245,
		244
	},

	{
		"dewata",
		13833,
		101,
		828,
		"���ұ� �κ�",
		"����",
		233,
		263
	},

	{
		"dewata",
		13834,
		101,
		727,
		"���ұ� �κ�",
		"�Ƴ�",
		234,
		263
	},

	{
		"dewata",
		13835,
		101,
		887,
		"���ఴ",
		"���ʹ�11",
		279,
		213
	},

	{
		"dewata",
		13836,
		101,
		538,
		"���� ����",
		"���ʹ�12",
		269,
		208
	},

	{
		"dewata",
		13837,
		101,
		538,
		"�縣",
		"���ʹ�13",
		227,
		129
	},

	{
		"dewata",
		13838,
		101,
		539,
		"�þ�",
		"���ʹ�14",
		239,
		140
	},

	{
		"dewata",
		13839,
		101,
		538,
		"�û�",
		"���ʹ�15",
		193,
		145
	},

	{
		"dewata",
		13840,
		101,
		538,
		"����",
		"���ʹ�16",
		228,
		177
	},

	{
		"dewata",
		13841,
		101,
		703,
		"�� ���� ����",
		"���ʹ�17",
		278,
		100
	},

	{
		"dewata",
		13842,
		101,
		101,
		"���� ����",
		"���ʹ�18",
		249,
		87
	},

	{
		"dewata",
		13843,
		101,
		97,
		"���� �ƺ�",
		"���ʹ�19",
		251,
		85
	},

	{
		"dewata",
		13844,
		101,
		534,
		"�ݽ� ���� �Ҿƹ���",
		"dewata",
		278,
		281
	},

	{
		"dewata",
		13845,
		101,
		534,
		"���谡 ������",
		"dewata",
		165,
		103
	},

	{
		"dewata",
		13846,
		101,
		535,
		"�ݽ� ���� �ҸӴ�",
		"dewata",
		280,
		277
	},

	{
		"dewata",
		13847,
		101,
		535,
		"������ ����",
		"dewata",
		139,
		114
	},

	{
		"dewata",
		13848,
		101,
		536,
		"����Ÿ û��",
		"dewata",
		181,
		88
	},

	{
		"dewata",
		13849,
		101,
		537,
		"����Ÿ ó��",
		"dewata",
		179,
		204
	},

	{
		"dewata",
		13850,
		101,
		726,
		"������ ������",
		"dewata",
		280,
		236
	},

	{
		"dewata",
		13851,
		101,
		537,
		"���̾�Ʈ���� ����",
		"dewata",
		204,
		230
	},

	{
		"dewata",
		13852,
		101,
		538,
		"�ູ�� �޲ٴ� ����",
		"dewata",
		117,
		156
	},

	{
		"dewata",
		13853,
		101,
		538,
		"�޿� ��Ǭ ����",
		"dewata",
		144,
		216
	},

	{
		"dewata",
		13854,
		101,
		539,
		"��� �ǰ��� ����",
		"dewata",
		127,
		248
	},

	{
		"dewata",
		13859,
		101,
		536,
		"�˺���Ÿ�� ����",
		"dewata",
		229,
		49
	},

	{
		"dewata",
		13868,
		101,
		534,
		"ũ��ī�� ȭ�� ������",
		"dewata",
		235,
		56
	},

	{
		"dewata",
		13873,
		101,
		536,
		"���κε� ��� ������",
		"dewata",
		78,
		192
	},

	{
		"dewata",
		15492,
		101,
		117,
		"ī���� ����",
		"dewata",
		202,
		184
	},

	{
		"dewata",
		15681,
		102,
		536,
		"���� ����",
		"",
		218,
		164
	},

	{
		"dewata",
		15682,
		102,
		536,
		"���� ����",
		"",
		182,
		164
	},

	{
		"dewata",
		15683,
		102,
		535,
		"���ϻ���",
		"",
		145,
		267
	},

	{
		"dewata",
		15684,
		102,
		536,
		"�� ����",
		"",
		158,
		182
	},

	{
		"dewata",
		15849,
		101,
		537,
		"����Ÿ ���̵�",
		"dewata",
		202,
		106
	},

	{
		"dewata",
		19599,
		101,
		729,
		"������ �����̵���",
		"28",
		192,
		193
	},

	{
		"dic_dun01",
		14773,
		101,
		450,
		"�ڰ�ܿ�",
		"ep133_23",
		286,
		104
	},

	{
		"dic_dun01",
		14775,
		101,
		492,
		"�ڰ�ܿ�",
		"ep133_23",
		294,
		106
	},

	{
		"dic_dun01",
		14777,
		101,
		492,
		"�ڰ�ܿ�",
		"ep133_26",
		30,
		216
	},

	{
		"dic_dun01",
		14833,
		101,
		490,
		"����̾�",
		"13_3",
		205,
		43
	},

	{
		"dic_dun01",
		14847,
		101,
		450,
		"�������� �ڰ�ܿ�",
		"ep13_3",
		284,
		102
	},

	{
		"dic_dun01",
		14849,
		101,
		449,
		"ȣ��� ���� ����",
		"seller",
		266,
		113
	},

	{
		"dic_dun01",
		19555,
		101,
		837,
		"�ָ�",
		"ī�̴��Ա�",
		30,
		208
	},

	{
		"dic_dun02",
		14836,
		101,
		489,
		"����",
		"13_3",
		111,
		127
	},

	{
		"dic_fild01",
		14707,
		101,
		496,
		"���",
		"pa0829",
		228,
		159
	},

	{
		"dic_fild01",
		14708,
		101,
		421,
		"�����̼� ���",
		"04pa0829",
		232,
		189
	},

	{
		"dic_fild01",
		14710,
		101,
		495,
		"�Ҷ��Ǵ�",
		"pa0829",
		240,
		198
	},

	{
		"dic_fild01",
		14711,
		101,
		495,
		"����",
		"pa0829",
		251,
		183
	},

	{
		"dic_fild01",
		14712,
		101,
		495,
		"���",
		"pa0829",
		259,
		172
	},

	{
		"dic_fild01",
		14756,
		101,
		492,
		"���� ���",
		"ep133_10",
		146,
		281
	},

	{
		"dic_fild01",
		14759,
		101,
		450,
		"���� ���",
		"ep133_10",
		153,
		281
	},

	{
		"dic_fild01",
		14772,
		101,
		496,
		"������",
		"ep133_18",
		231,
		174
	},

	{
		"dic_fild01",
		15259,
		101,
		421,
		"������ �����̵��� 6ȣ",
		"",
		161,
		266
	},

	{
		"dic_fild01",
		19556,
		101,
		837,
		"�ָ�",
		"ī�̴��ⱸ",
		27,
		83
	},

	{
		"dic_in01",
		14713,
		101,
		460,
		"ī��ī",
		"pa0829",
		353,
		37
	},

	{
		"dic_in01",
		14714,
		101,
		453,
		"���Ƿν�",
		"0001",
		40,
		193
	},

	{
		"dic_in01",
		14716,
		101,
		449,
		"����1�� �����",
		"pa0829",
		48,
		263
	},

	{
		"dic_in01",
		14718,
		101,
		449,
		"����2�� �����",
		"pa0829",
		51,
		266
	},

	{
		"dic_in01",
		14720,
		101,
		449,
		"���� 1�� �����",
		"pa0829",
		51,
		270
	},

	{
		"dic_in01",
		14722,
		101,
		449,
		"���� 2�� �����",
		"pa0829",
		48,
		273
	},

	{
		"dic_in01",
		14724,
		101,
		449,
		"��� 1�� �����",
		"pa0829",
		43,
		273
	},

	{
		"dic_in01",
		14726,
		101,
		449,
		"��� 2�� �����",
		"pa0829",
		40,
		270
	},

	{
		"dic_in01",
		14762,
		101,
		453,
		"���谡 ������",
		"ep133_12",
		42,
		264
	},

	{
		"dic_in01",
		14789,
		101,
		491,
		"�Ƿ��� �ǿ�",
		"a",
		341,
		113
	},

	{
		"dic_in01",
		14791,
		101,
		455,
		"�Ƿ��� �ǿ�",
		"b",
		149,
		104
	},

	{
		"dic_in01",
		14797,
		101,
		490,
		"���ٽ��� �ǿ�",
		"a",
		335,
		34
	},

	{
		"dic_in01",
		14798,
		101,
		454,
		"����ũ �ǿ�",
		"a",
		387,
		30
	},

	{
		"dic_in01",
		14799,
		101,
		491,
		"�Ƿ��� �ǿ�",
		"c",
		168,
		116
	},

	{
		"dic_in01",
		14800,
		101,
		490,
		"����� �ǿ�",
		"a",
		372,
		116
	},

	{
		"dic_in01",
		14801,
		101,
		449,
		"�ɰ��� ��ũ��",
		"a",
		360,
		125
	},

	{
		"dic_in01",
		14802,
		101,
		489,
		"�ٽɽ��� �ǿ�",
		"a",
		98,
		110
	},

	{
		"dic_in01",
		14803,
		101,
		489,
		"������ �ǿ�",
		"a",
		91,
		113
	},

	{
		"dic_in01",
		14804,
		101,
		492,
		"�� ���� ��ư",
		"a",
		98,
		96
	},

	{
		"dic_in01",
		14805,
		101,
		454,
		"�޽����� �ǿ�",
		"01",
		87,
		102
	},

	{
		"dic_in01",
		14806,
		101,
		489,
		"�޽����� �ǿ�",
		"04",
		29,
		119
	},

	{
		"dic_in01",
		14807,
		101,
		449,
		"��ũ��",
		"el_01",
		32,
		54
	},

	{
		"dic_in01",
		14808,
		101,
		492,
		"������� ��ư",
		"in_1",
		349,
		282
	},

	{
		"dic_in01",
		14809,
		101,
		492,
		"������� ��ư",
		"in_2",
		370,
		261
	},

	{
		"dic_in01",
		14810,
		101,
		492,
		"������� ��ư",
		"in_3",
		381,
		261
	},

	{
		"dic_in01",
		14811,
		101,
		492,
		"������� ��ư",
		"in_4",
		370,
		282
	},

	{
		"dic_in01",
		14812,
		101,
		492,
		"�޽����� ��ư",
		"in_5",
		354,
		219
	},

	{
		"dic_in01",
		14813,
		101,
		492,
		"�޽����� ��ư",
		"in_6",
		365,
		197
	},

	{
		"dic_in01",
		14814,
		101,
		489,
		"�ȳ���",
		"diel_1",
		42,
		250
	},

	{
		"dic_in01",
		14815,
		101,
		711,
		"�Ļ����� ���谡",
		"tre",
		252,
		103
	},

	{
		"dic_in01",
		15678,
		102,
		900,
		"���λ�",
		"dic",
		238,
		107
	},

	{
		"dicastes01",
		10061,
		101,
		109,
		"���������",
		"",
		193,
		191
	},

	{
		"dicastes01",
		10078,
		101,
		105,
		"������������",
		"��ī���׽�",
		187,
		207
	},

	{
		"dicastes01",
		14715,
		101,
		453,
		"������",
		"pa0829",
		187,
		230
	},

	{
		"dicastes01",
		14717,
		101,
		453,
		"Į����",
		"pa0829",
		175,
		217
	},

	{
		"dicastes01",
		14719,
		101,
		453,
		"Ƕ��",
		"pa0829",
		208,
		230
	},

	{
		"dicastes01",
		14721,
		101,
		453,
		"Ʈ��⽺",
		"pa0829",
		225,
		211
	},

	{
		"dicastes01",
		14723,
		101,
		453,
		"Į����",
		"pa0829",
		223,
		190
	},

	{
		"dicastes01",
		14725,
		101,
		453,
		"����ī",
		"pa0829",
		211,
		178
	},

	{
		"dicastes01",
		14764,
		101,
		449,
		"��å���� ��Ʈ",
		"ep133_15",
		207,
		210
	},

	{
		"dicastes01",
		14765,
		101,
		491,
		"�����ִ� �ǿ�",
		"ep133_16",
		112,
		248
	},

	{
		"dicastes01",
		14766,
		101,
		450,
		"�Ʒ� ���� ��ư",
		"ep133_17",
		249,
		140
	},

	{
		"dicastes01",
		14780,
		101,
		449,
		"��¥ ��ũ��",
		"fihsing1-1",
		202,
		197
	},

	{
		"dicastes01",
		14781,
		101,
		450,
		"������� ��ư",
		"fihsing1-2",
		191,
		202
	},

	{
		"dicastes01",
		14782,
		101,
		450,
		" �Ʒ����� ��ư",
		"�Ʒ���01",
		234,
		158
	},

	{
		"dicastes01",
		14783,
		101,
		450,
		" �Ʒ����� ��ư",
		"�Ʒ���02",
		244,
		166
	},

	{
		"dicastes01",
		14784,
		101,
		450,
		" �Ʒ����� ��ư",
		"�Ʒ���03",
		272,
		166
	},

	{
		"dicastes01",
		14785,
		101,
		450,
		" �Ʒ����� ��ư",
		"�Ʒ���04",
		248,
		129
	},

	{
		"dicastes01",
		14786,
		101,
		450,
		" �Ʒ����� ��ư",
		"�Ʒ���05",
		271,
		152
	},

	{
		"dicastes01",
		14787,
		101,
		450,
		"�ļ���",
		"a",
		202,
		86
	},

	{
		"dicastes01",
		14788,
		101,
		450,
		"�ļ���",
		"b",
		193,
		86
	},

	{
		"dicastes01",
		14790,
		101,
		492,
		"��� ��ư",
		"a",
		194,
		166
	},

	{
		"dicastes01",
		14792,
		101,
		489,
		"������� �ǿ�",
		"a",
		164,
		180
	},

	{
		"dicastes01",
		14793,
		101,
		490,
		"��� �ǿ�",
		"a",
		235,
		245
	},

	{
		"dicastes01",
		14794,
		101,
		453,
		"�λ� ���� ��Ʈ",
		"a",
		284,
		262
	},

	{
		"dicastes01",
		14795,
		101,
		453,
		"�Ѱ��� ��Ʈ",
		"a",
		282,
		208
	},

	{
		"dicastes01",
		14796,
		101,
		449,
		"�Ѱ��� ��ũ��",
		"a",
		246,
		210
	},

	{
		"dicastes01",
		14829,
		101,
		455,
		"������",
		"13_3",
		117,
		262
	},

	{
		"dicastes01",
		15758,
		101,
		700,
		"����Ʈ ����",
		"��ī���׽�",
		207,
		200
	},

	{
		"dicastes01",
		15776,
		101,
		105,
		"�ż� ������",
		"��ī���׽�",
		187,
		200
	},

	{
		"dicastes01",
		15857,
		101,
		481,
		"���谡 ����",
		"info",
		189,
		191
	},

	{
		"e_tower",
		19680,
		101,
		406,
		"Tower Protection Stone",
		"",
		81,
		105
	},

	{
		"e_tower",
		19683,
		101,
		406,
		"Purification Stone",
		"102tower",
		69,
		117
	},

	{
		"ecl_fild01",
		15236,
		101,
		421,
		"������ �����̵��� 1ȣ",
		"",
		118,
		311
	},

	{
		"ecl_in01",
		15344,
		101,
		436,
		"������ ���Ķ�",
		"ecl",
		66,
		95
	},

	{
		"ecl_in01",
		15345,
		101,
		436,
		"���������� ��Ʈ��",
		"ecl",
		64,
		97
	},

	{
		"ecl_in01",
		15346,
		101,
		443,
		"���ʻ��� �ö��ǳ�",
		"ecl",
		33,
		98
	},

	{
		"ecl_in01",
		15347,
		101,
		445,
		"���������� ����",
		"",
		67,
		39
	},

	{
		"ecl_in02",
		15308,
		101,
		835,
		"�ָ�",
		"prison_inn",
		96,
		22
	},

	{
		"ecl_in02",
		15311,
		101,
		437,
		"ġ��� ������",
		"���ǳ�",
		164,
		56
	},

	{
		"ecl_in02",
		15312,
		101,
		441,
		"��ó���� ���ǳ�",
		"",
		135,
		45
	},

	{
		"ecl_in02",
		15313,
		101,
		442,
		"ġ��� ���ǳ�",
		"doctor",
		137,
		44
	},

	{
		"ein_in01",
		12156,
		101,
		851,
		"Teinz",
		"",
		113,
		211
	},

	{
		"ein_in01",
		12157,
		101,
		851,
		"Lowe",
		"",
		48,
		220
	},

	{
		"ein_in01",
		12158,
		101,
		850,
		"Dinje",
		"",
		87,
		237
	},

	{
		"ein_in01",
		12159,
		101,
		851,
		"Tsuen",
		"",
		84,
		218
	},

	{
		"ein_in01",
		12160,
		101,
		849,
		"Gesin",
		"",
		103,
		239
	},

	{
		"ein_in01",
		12161,
		101,
		848,
		"Pevtatin",
		"",
		33,
		275
	},

	{
		"ein_in01",
		12162,
		101,
		851,
		"Rombell",
		"",
		36,
		204
	},

	{
		"ein_in01",
		12163,
		101,
		855,
		"Vonstein",
		"",
		64,
		271
	},

	{
		"ein_in01",
		12164,
		101,
		851,
		"Dorf",
		"",
		49,
		202
	},

	{
		"ein_in01",
		12165,
		101,
		852,
		"Khashurantze",
		"",
		68,
		209
	},

	{
		"ein_in01",
		12166,
		101,
		851,
		"Zherin",
		"",
		85,
		261
	},

	{
		"ein_in01",
		12167,
		101,
		852,
		"Canphotii",
		"",
		43,
		252
	},

	{
		"ein_in01",
		12168,
		101,
		855,
		"Hotel Employee",
		"",
		206,
		224
	},

	{
		"ein_in01",
		12188,
		101,
		851,
		"Cendadt",
		"",
		31,
		217
	},

	{
		"ein_in01",
		12189,
		101,
		854,
		"Tavern Lady",
		"",
		279,
		92
	},

	{
		"ein_in01",
		12190,
		101,
		855,
		"Ryan Danger",
		"einbech_bar",
		277,
		95
	},

	{
		"ein_in01",
		12191,
		101,
		849,
		"Drunken Man",
		"einbech_bar",
		281,
		85
	},

	{
		"ein_in01",
		12194,
		101,
		853,
		"Megass",
		"",
		21,
		147
	},

	{
		"ein_in01",
		12201,
		101,
		855,
		"Decii",
		"",
		208,
		86
	},

	{
		"ein_in01",
		12202,
		101,
		849,
		"Supineque",
		"",
		192,
		90
	},

	{
		"ein_in01",
		13210,
		101,
		724,
		"Young Dancer",
		"sch",
		174,
		266
	},

	{
		"ein_in01",
		13211,
		101,
		724,
		"Cheerful Dancer",
		"sch",
		172,
		266
	},

	{
		"ein_in01",
		13212,
		101,
		724,
		"Mature Looking Dancer",
		"sch",
		170,
		266
	},

	{
		"ein_in01",
		13213,
		101,
		903,
		"Hotel Manager",
		"sch",
		279,
		221
	},

	{
		"ein_in01",
		13214,
		101,
		904,
		"Employee",
		"sch",
		166,
		282
	},

	{
		"ein_in01",
		13215,
		101,
		109,
		"Corporate Figure",
		"",
		181,
		284
	},

	{
		"ein_in01",
		13216,
		101,
		920,
		"Arunafeltz Figure",
		"",
		181,
		285
	},

	{
		"ein_in01",
		13217,
		101,
		109,
		"Corporate Figure",
		"sch",
		168,
		274
	},

	{
		"ein_in01",
		13218,
		101,
		920,
		"Arunafeltz Figure",
		"sch",
		170,
		284
	},

	{
		"ein_in01",
		15592,
		102,
		850,
		"��������",
		"",
		189,
		15
	},

	{
		"ein_in01",
		15593,
		102,
		850,
		"�Ѽչ������",
		"",
		106,
		27
	},

	{
		"ein_in01",
		15594,
		102,
		850,
		"��չ������",
		"",
		109,
		27
	},

	{
		"ein_in01",
		15617,
		102,
		855,
		"�������",
		"",
		119,
		26
	},

	{
		"ein_in01",
		18394,
		101,
		84,
		"Matestein",
		"",
		18,
		82
	},

	{
		"ein_in01",
		18395,
		101,
		86,
		"Tirehaus",
		"",
		15,
		87
	},

	{
		"ein_in01",
		18396,
		101,
		826,
		"Manthasman",
		"",
		24,
		87
	},

	{
		"ein_in01",
		18542,
		101,
		731,
		"Guildsman",
		"BLS",
		18,
		28
	},

	{
		"ein_in01",
		18543,
		101,
		63,
		"Guildsman",
		"alberta",
		201,
		27
	},

	{
		"ein_in01",
		18549,
		101,
		726,
		"Blacksmith Guildsman",
		"moc",
		24,
		41
	},

	{
		"ein_in01",
		18551,
		101,
		63,
		"Paul Spanner",
		"",
		38,
		29
	},

	{
		"ein_in01",
		19455,
		101,
		854,
		"Ei'felle",
		"repay01",
		85,
		208
	},

	{
		"einbech",
		12038,
		101,
		847,
		"Cavitar",
		"",
		97,
		167
	},

	{
		"einbech",
		12112,
		101,
		855,
		"Young Man",
		"ein_main",
		57,
		210
	},

	{
		"einbech",
		12113,
		101,
		846,
		"Shena",
		"",
		46,
		107
	},

	{
		"einbech",
		12114,
		101,
		850,
		"Luda",
		"",
		48,
		107
	},

	{
		"einbech",
		12115,
		101,
		855,
		"Jung",
		"",
		148,
		242
	},

	{
		"einbech",
		12116,
		101,
		851,
		"Franz",
		"",
		148,
		246
	},

	{
		"einbech",
		12140,
		101,
		855,
		"Nemuk",
		"",
		172,
		113
	},

	{
		"einbech",
		12141,
		101,
		855,
		"Young Man",
		"",
		197,
		139
	},

	{
		"einbech",
		12142,
		101,
		848,
		"Mogan",
		"",
		128,
		238
	},

	{
		"einbech",
		12143,
		101,
		848,
		"Hander",
		"",
		129,
		234
	},

	{
		"einbech",
		12144,
		101,
		848,
		"Gushenmu",
		"",
		105,
		218
	},

	{
		"einbech",
		12145,
		101,
		852,
		"Train Station Staff",
		"ein-3",
		39,
		215
	},

	{
		"einbech",
		12147,
		101,
		852,
		"Train Station Manager",
		"ein",
		157,
		215
	},

	{
		"einbech",
		12152,
		101,
		855,
		"Tollaf",
		"",
		151,
		168
	},

	{
		"einbech",
		12153,
		101,
		847,
		"Raust",
		"",
		93,
		139
	},

	{
		"einbech",
		12154,
		101,
		850,
		"Mjunia",
		"",
		149,
		154
	},

	{
		"einbech",
		12155,
		101,
		848,
		"Ekuri",
		"",
		130,
		253
	},

	{
		"einbech",
		12169,
		101,
		858,
		"Bulletin Board",
		"einbech11",
		135,
		250
	},

	{
		"einbech",
		12170,
		101,
		858,
		"Bulletin Board",
		"einbech22",
		90,
		214
	},

	{
		"einbech",
		12171,
		101,
		858,
		"Bulletin Board",
		"einbech33",
		158,
		189
	},

	{
		"einbech",
		12172,
		101,
		858,
		"Bulletin Board",
		"einbech44",
		180,
		136
	},

	{
		"einbech",
		12173,
		101,
		858,
		"Bulletin Board",
		"einbech55",
		133,
		114
	},

	{
		"einbech",
		12174,
		101,
		858,
		"Bulletin Board",
		"einbech01",
		77,
		105
	},

	{
		"einbech",
		12175,
		101,
		858,
		"Bulletin Board",
		"einbech03",
		181,
		127
	},

	{
		"einbech",
		12198,
		101,
		854,
		"Catzllanpu",
		"",
		216,
		118
	},

	{
		"einbech",
		12200,
		101,
		850,
		"Ellhenje",
		"",
		176,
		125
	},

	{
		"einbech",
		12904,
		101,
		851,
		"Bomb Maker",
		"",
		208,
		124
	},

	{
		"einbech",
		15480,
		101,
		860,
		"Kafra Employee",
		"ein3",
		181,
		132
	},

	{
		"einbech",
		15718,
		101,
		91,
		"Metelle",
		"",
		70,
		222
	},

	{
		"einbech",
		15839,
		101,
		852,
		"Einbech Guide",
		"einbech01",
		67,
		37
	},

	{
		"einbech",
		15840,
		101,
		852,
		"Einbech Guide",
		"einbech02",
		48,
		214
	},

	{
		"einbech",
		19532,
		101,
		837,
		"�ָ�",
		"���α���",
		142,
		250
	},

	{
		"einbroch",
		10041,
		101,
		109,
		"���������",
		"",
		235,
		207
	},

	{
		"einbroch",
		12039,
		101,
		85,
		"Uwe Kleine",
		"",
		215,
		180
	},

	{
		"einbroch",
		12109,
		101,
		852,
		"Laboratory Soldier",
		"ein-1",
		51,
		46
	},

	{
		"einbroch",
		12110,
		101,
		852,
		"Laboratory Soldier",
		"ein-2",
		51,
		56
	},

	{
		"einbroch",
		12120,
		101,
		854,
		"Morei",
		"",
		175,
		196
	},

	{
		"einbroch",
		12124,
		101,
		855,
		"Oberu",
		"",
		173,
		229
	},

	{
		"einbroch",
		12127,
		101,
		855,
		"Khemko",
		"",
		176,
		172
	},

	{
		"einbroch",
		12130,
		101,
		846,
		"Leslie",
		"ein_1",
		259,
		326
	},

	{
		"einbroch",
		12131,
		101,
		855,
		"Tan",
		"ein",
		236,
		191
	},

	{
		"einbroch",
		12132,
		101,
		855,
		"Little Toby",
		"ein-1",
		228,
		121
	},

	{
		"einbroch",
		12133,
		101,
		855,
		"Airship Engineer",
		"ein-1",
		40,
		116
	},

	{
		"einbroch",
		12134,
		101,
		854,
		"Centzu",
		"",
		294,
		312
	},

	{
		"einbroch",
		12135,
		101,
		847,
		"Khowropher",
		"",
		232,
		255
	},

	{
		"einbroch",
		12136,
		101,
		855,
		"Khetine",
		"",
		143,
		109
	},

	{
		"einbroch",
		12137,
		101,
		854,
		"Sleik",
		"",
		229,
		149
	},

	{
		"einbroch",
		12176,
		101,
		858,
		"Bulletin Board",
		"",
		244,
		255
	},

	{
		"einbroch",
		12177,
		101,
		858,
		"Bulletin Board",
		"",
		253,
		203
	},

	{
		"einbroch",
		12178,
		101,
		858,
		"Bulletin Board",
		"",
		68,
		206
	},

	{
		"einbroch",
		12179,
		101,
		858,
		"Bulletin Board",
		"einbroch03",
		90,
		84
	},

	{
		"einbroch",
		12180,
		101,
		858,
		"Bulletin Board",
		"einbroch04",
		101,
		106
	},

	{
		"einbroch",
		12181,
		101,
		858,
		"Bulletin Board",
		"einbroch05",
		220,
		208
	},

	{
		"einbroch",
		12182,
		101,
		858,
		"Bulletin Board",
		"einbroch06",
		132,
		76
	},

	{
		"einbroch",
		12183,
		101,
		858,
		"Bulletin Board",
		"einbroch11",
		152,
		46
	},

	{
		"einbroch",
		12184,
		101,
		858,
		"Bulletin Board",
		"einbroch22",
		235,
		141
	},

	{
		"einbroch",
		12185,
		101,
		858,
		"Bulletin Board",
		"einbroch33",
		162,
		256
	},

	{
		"einbroch",
		12186,
		101,
		858,
		"Bulletin Board",
		"einbroch44",
		183,
		174
	},

	{
		"einbroch",
		12187,
		101,
		858,
		"Bulletin Board",
		"einbroch55",
		104,
		202
	},

	{
		"einbroch",
		12197,
		101,
		855,
		"Keneshiotz",
		"",
		188,
		72
	},

	{
		"einbroch",
		12199,
		101,
		850,
		"Kesunboss",
		"",
		208,
		208
	},

	{
		"einbroch",
		12298,
		101,
		91,
		"Airship Staff",
		"ein01",
		94,
		267
	},

	{
		"einbroch",
		15478,
		101,
		861,
		"Kafra Employee",
		"ein1",
		59,
		203
	},

	{
		"einbroch",
		15479,
		101,
		860,
		"Kafra Employee",
		"ein2",
		242,
		205
	},

	{
		"einbroch",
		15595,
		102,
		850,
		"����ũ����",
		"ein",
		138,
		66
	},

	{
		"einbroch",
		15596,
		102,
		855,
		"�����",
		"ein",
		82,
		199
	},

	{
		"einbroch",
		15633,
		102,
		83,
		"�丮������",
		"",
		224,
		207
	},

	{
		"einbroch",
		15670,
		102,
		49,
		"�ϰŷ���",
		"",
		122,
		250
	},

	{
		"einbroch",
		15835,
		101,
		852,
		"Einbroch Guide",
		"einbroch01",
		72,
		202
	},

	{
		"einbroch",
		15836,
		101,
		852,
		"Einbroch Guide",
		"einbroch02",
		155,
		43
	},

	{
		"einbroch",
		15837,
		101,
		852,
		"Einbroch Guide",
		"einbroch03",
		162,
		317
	},

	{
		"einbroch",
		15838,
		101,
		852,
		"Einbroch Guide",
		"einbroch04",
		252,
		320
	},

	{
		"einbroch",
		19583,
		101,
		729,
		"������ �����̵���",
		"20",
		250,
		211
	},

	{
		"gef_fild05",
		15738,
		101,
		877,
		"Myu",
		"08_hat",
		80,
		149
	},

	{
		"gef_fild07",
		15784,
		101,
		1012,
		"�δ� ���α�",
		"����������",
		108,
		161
	},

	{
		"gef_fild07",
		19003,
		101,
		123,
		"������ ��� �ȳ���",
		"",
		89,
		208
	},

	{
		"gef_fild08",
		18475,
		101,
		836,
		"Bulletin Board",
		"�ں�Ʈ����2",
		211,
		24
	},

	{
		"gef_fild09",
		18472,
		101,
		835,
		"Bulletin Board",
		"��ũ����1",
		227,
		29
	},

	{
		"gef_fild10",
		15454,
		101,
		116,
		"Kafra Employee",
		"",
		73,
		340
	},

	{
		"gef_fild10",
		18476,
		101,
		836,
		"�ָ�",
		"����������1",
		109,
		24
	},

	{
		"gef_fild10",
		19521,
		101,
		837,
		"Bulletin Board",
		"��ũ����",
		69,
		340
	},

	{
		"gef_fild10",
		19684,
		101,
		406,
		"Dimensional Gorge Piece",
		"",
		242,
		202
	},

	{
		"gef_fild10",
		19685,
		101,
		865,
		"Mad Scientist",
		"",
		238,
		202
	},

	{
		"gef_fild13",
		17847,
		101,
		722,
		"Eeyolbriggar",
		"",
		303,
		243
	},

	{
		"gef_fild13",
		17848,
		101,
		722,
		"Eeyolbriggar",
		"",
		312,
		243
	},

	{
		"gef_fild13",
		17849,
		101,
		722,
		"Eeyolbriggar",
		"",
		290,
		243
	},

	{
		"gef_fild13",
		17850,
		101,
		722,
		"Eeyolbriggar",
		"",
		324,
		243
	},

	{
		"gef_fild13",
		17851,
		101,
		722,
		"Yesnelph",
		"",
		78,
		182
	},

	{
		"gef_fild13",
		17852,
		101,
		722,
		"Yesnelph",
		"",
		87,
		182
	},

	{
		"gef_fild13",
		17853,
		101,
		722,
		"Yesnelph",
		"",
		73,
		295
	},

	{
		"gef_fild13",
		17854,
		101,
		722,
		"Yesnelph",
		"",
		113,
		274
	},

	{
		"gef_fild13",
		17855,
		101,
		722,
		"Yesnelph",
		"",
		144,
		235
	},

	{
		"gef_fild13",
		17856,
		101,
		722,
		"Yesnelph",
		"",
		144,
		244
	},

	{
		"gef_fild13",
		17857,
		101,
		722,
		"Bergel",
		"",
		190,
		283
	},

	{
		"gef_fild13",
		17858,
		101,
		722,
		"Bergel",
		"",
		199,
		274
	},

	{
		"gef_fild13",
		17859,
		101,
		722,
		"Mersetzdeitz",
		"",
		302,
		87
	},

	{
		"gef_fild13",
		17860,
		101,
		722,
		"Mersetzdeitz",
		"",
		313,
		83
	},

	{
		"gef_fild13",
		17861,
		101,
		722,
		"Mersetzdeitz",
		"",
		252,
		51
	},

	{
		"gef_fild13",
		18034,
		101,
		549,
		"�����̼ջ�� �޶�ũ",
		"",
		187,
		208
	},

	{
		"gef_fild13",
		18035,
		101,
		421,
		"����Ʈ ������",
		"gef_f00",
		189,
		206
	},

	{
		"gef_fild13",
		18037,
		101,
		857,
		"������Ȳ�Խ���",
		"fund01",
		190,
		209
	},

	{
		"gef_fild13",
		18473,
		101,
		835,
		"Bulletin Board",
		"��ũ����2",
		202,
		31
	},

	{
		"gef_fild13",
		18474,
		101,
		836,
		"Bulletin Board",
		"�ں�Ʈ����1",
		29,
		206
	},

	{
		"gef_fild13",
		19187,
		101,
		751,
		"Soldier",
		"277",
		297,
		242
	},

	{
		"gef_tower",
		15747,
		101,
		700,
		"Point Salesman",
		"�Ҽ���",
		105,
		172
	},

	{
		"gef_tower",
		18571,
		101,
		81,
		"White Dog",
		"",
		107,
		36
	},

	{
		"gef_tower",
		18957,
		101,
		102,
		"�Ҽ��� ����",
		"����",
		107,
		172
	},

	{
		"gef_tower",
		19108,
		101,
		876,
		"Meow",
		"",
		115,
		36
	},

	{
		"gef_tower",
		19281,
		101,
		64,
		"Annoyed Man",
		"",
		118,
		36
	},

	{
		"gef_tower",
		19513,
		101,
		837,
		"Bulletin Board",
		"�������ϴ���",
		55,
		142
	},

	{
		"gefenia01",
		19537,
		101,
		837,
		"�ָ�",
		"����Ͼ�1",
		61,
		173
	},

	{
		"gefenia02",
		19538,
		101,
		837,
		"�ָ�",
		"����Ͼ�2",
		120,
		108
	},

	{
		"gefenia03",
		19539,
		101,
		837,
		"�ָ�",
		"����Ͼ�3",
		131,
		201
	},

	{
		"gefenia04",
		19540,
		101,
		837,
		"�ָ�",
		"����Ͼ�4",
		130,
		95
	},

	{
		"geffen",
		10034,
		101,
		109,
		"���������",
		"",
		126,
		64
	},

	{
		"geffen",
		10073,
		101,
		105,
		"������������",
		"����",
		103,
		55
	},

	{
		"geffen",
		10095,
		101,
		735,
		"�븶���� K��",
		"",
		95,
		198
	},

	{
		"geffen",
		10107,
		101,
		831,
		"����Ʈ���� �ȳ���",
		"gef",
		122,
		104
	},

	{
		"geffen",
		11168,
		101,
		91,
		"Meera",
		"",
		59,
		143
	},

	{
		"geffen",
		11169,
		101,
		82,
		"Orwalk",
		"",
		156,
		190
	},

	{
		"geffen",
		11171,
		101,
		97,
		"û��",
		"",
		151,
		44
	},

	{
		"geffen",
		11172,
		101,
		101,
		"Stacey",
		"",
		111,
		48
	},

	{
		"geffen",
		11175,
		101,
		99,
		"Suspicious Guy",
		"",
		146,
		148
	},

	{
		"geffen",
		11183,
		101,
		702,
		"���� ����",
		"",
		90,
		130
	},

	{
		"geffen",
		11199,
		101,
		700,
		"�Ͼ�",
		"yagu",
		122,
		77
	},

	{
		"geffen",
		12533,
		101,
		116,
		"Kafra Voting Staff",
		"geffen",
		122,
		37
	},

	{
		"geffen",
		12575,
		101,
		874,
		"Cool Event Staff",
		"geffen",
		117,
		37
	},

	{
		"geffen",
		15094,
		101,
		553,
		"������",
		"����",
		109,
		61
	},

	{
		"geffen",
		15406,
		101,
		115,
		"Kafra Employee",
		"",
		120,
		62
	},

	{
		"geffen",
		15411,
		101,
		114,
		"Kafra Employee",
		"",
		203,
		123
	},

	{
		"geffen",
		15542,
		102,
		124,
		"���ֻ̹���",
		"",
		193,
		152
	},

	{
		"geffen",
		15627,
		102,
		85,
		"�丮������",
		"",
		196,
		111
	},

	{
		"geffen",
		15700,
		101,
		700,
		"Ipore",
		"",
		67,
		87
	},

	{
		"geffen",
		15708,
		101,
		716,
		"Seth",
		"",
		83,
		189
	},

	{
		"geffen",
		15709,
		101,
		779,
		"Argen",
		"",
		129,
		148
	},

	{
		"geffen",
		15752,
		101,
		700,
		"����Ʈ ����",
		"����",
		129,
		49
	},

	{
		"geffen",
		15771,
		101,
		105,
		"�ż� ������",
		"����",
		100,
		55
	},

	{
		"geffen",
		15801,
		101,
		705,
		"Guide",
		"01geffen",
		203,
		116
	},

	{
		"geffen",
		15802,
		101,
		705,
		"Guide",
		"02geffen",
		118,
		62
	},

	{
		"geffen",
		15803,
		101,
		705,
		"Guide",
		"03geffen",
		36,
		123
	},

	{
		"geffen",
		15804,
		101,
		705,
		"Guide",
		"04geffen",
		123,
		203
	},

	{
		"geffen",
		17798,
		101,
		728,
		"Maroll Battle Recruiter",
		"",
		109,
		66
	},

	{
		"geffen",
		17914,
		101,
		722,
		"Repherion",
		"",
		109,
		123
	},

	{
		"geffen",
		17915,
		101,
		722,
		"��긮��",
		"",
		112,
		129
	},

	{
		"geffen",
		17916,
		101,
		722,
		"Yesnelph",
		"",
		120,
		132
	},

	{
		"geffen",
		17917,
		101,
		722,
		"Bergel",
		"",
		127,
		130
	},

	{
		"geffen",
		17918,
		101,
		722,
		"Mersetzdeitz",
		"",
		131,
		123
	},

	{
		"geffen",
		18120,
		101,
		92,
		"Smile Assistance",
		"",
		119,
		107
	},

	{
		"geffen",
		18448,
		101,
		97,
		"Citizen",
		"",
		203,
		146
	},

	{
		"geffen",
		18460,
		101,
		837,
		"Bulletin Board",
		"����",
		124,
		65
	},

	{
		"geffen",
		18477,
		101,
		51,
		"Bard",
		"2",
		132,
		38
	},

	{
		"geffen",
		18765,
		101,
		709,
		"����",
		"gungun",
		63,
		70
	},

	{
		"geffen",
		19004,
		101,
		123,
		"������ ��� �ȳ���",
		"2",
		43,
		123
	},

	{
		"geffen",
		19184,
		101,
		726,
		"Akkie",
		"",
		178,
		72
	},

	{
		"geffen",
		19185,
		101,
		826,
		"Goodman",
		"",
		172,
		52
	},

	{
		"geffen",
		19565,
		101,
		729,
		"Eden Teleport Officer",
		"3",
		132,
		66
	},

	{
		"geffen_in",
		11170,
		101,
		64,
		"Wizard Stanza",
		"",
		164,
		109
	},

	{
		"geffen_in",
		11173,
		101,
		47,
		"Theodore",
		"",
		34,
		170
	},

	{
		"geffen_in",
		11174,
		101,
		63,
		"Christopher",
		"",
		110,
		172
	},

	{
		"geffen_in",
		11176,
		101,
		52,
		"Crumpler",
		"",
		22,
		125
	},

	{
		"geffen_in",
		11177,
		101,
		61,
		"Skyler",
		"",
		59,
		61
	},

	{
		"geffen_in",
		11178,
		101,
		91,
		"Waitress",
		"",
		27,
		134
	},

	{
		"geffen_in",
		11179,
		101,
		90,
		"Waitress",
		"",
		70,
		67
	},

	{
		"geffen_in",
		11180,
		101,
		120,
		"Merchant Daven",
		"",
		79,
		76
	},

	{
		"geffen_in",
		11181,
		101,
		709,
		"Hadenheim",
		"",
		114,
		73
	},

	{
		"geffen_in",
		11182,
		101,
		704,
		"Psychic Advisor",
		"",
		39,
		127
	},

	{
		"geffen_in",
		11184,
		101,
		53,
		"Inn Employee",
		"",
		70,
		64
	},

	{
		"geffen_in",
		11200,
		101,
		700,
		"���� ������",
		"sorty",
		99,
		174
	},

	{
		"geffen_in",
		11550,
		101,
		731,
		"Blacksmith",
		"�翰��",
		71,
		112
	},

	{
		"geffen_in",
		11551,
		101,
		716,
		"Girl",
		"",
		106,
		106
	},

	{
		"geffen_in",
		15536,
		102,
		68,
		"��������",
		"",
		77,
		167
	},

	{
		"geffen_in",
		15537,
		102,
		64,
		"��������",
		"",
		77,
		173
	},

	{
		"geffen_in",
		15538,
		102,
		66,
		"������",
		"",
		26,
		178
	},

	{
		"geffen_in",
		15539,
		102,
		47,
		"�������",
		"",
		30,
		178
	},

	{
		"geffen_in",
		15540,
		102,
		66,
		"����",
		"",
		74,
		144
	},

	{
		"geffen_in",
		15541,
		102,
		64,
		"��������",
		"",
		171,
		123
	},

	{
		"geffen_in",
		15622,
		102,
		84,
		"�������",
		"",
		22,
		171
	},

	{
		"geffen_in",
		18098,
		101,
		63,
		"Blacksmith",
		"",
		144,
		166
	},

	{
		"geffen_in",
		18106,
		101,
		83,
		"Eric",
		"",
		30,
		71
	},

	{
		"geffen_in",
		18204,
		101,
		84,
		"PVPNarrator",
		"",
		67,
		63
	},

	{
		"geffen_in",
		18205,
		101,
		83,
		"Gate Keeper",
		"",
		63,
		63
	},

	{
		"geffen_in",
		18365,
		101,
		64,
		"Great Wizard",
		"",
		151,
		119
	},

	{
		"geffen_in",
		18441,
		101,
		86,
		"������",
		"",
		34,
		166
	},

	{
		"geffen_in",
		18489,
		101,
		123,
		"Mage Guildsman",
		"",
		164,
		124
	},

	{
		"geffen_in",
		19067,
		101,
		564,
		"�ʺ��ڿ� ���Ǳ�",
		"�����",
		158,
		107
	},

	{
		"geffen_in",
		19077,
		101,
		735,
		"������ ������",
		"",
		159,
		124
	},

	{
		"geffen_in",
		19078,
		101,
		64,
		"���ڵ� �ȳ� ����",
		"",
		158,
		113
	},

	{
		"geffen_in",
		19079,
		101,
		743,
		"������ �ȳ� ����",
		"",
		158,
		110
	},

	{
		"gl_prison1",
		15715,
		101,
		1200,
		"Zealotus",
		"hat",
		137,
		138
	},

	{
		"gl_prison1",
		15716,
		101,
		1202,
		"Phendark",
		"hat",
		97,
		104
	},

	{
		"gl_prison1",
		15717,
		101,
		1201,
		"Rybio",
		"hat",
		100,
		48
	},

	{
		"glast_01",
		19514,
		101,
		837,
		"�ָ�",
		"������",
		372,
		298
	},

	{
		"glast_01",
		19648,
		101,
		95,
		"������ �İߴܿ�",
		"2nd03",
		195,
		131
	},

	{
		"gon_fild01",
		18418,
		101,
		776,
		"Kunlun Envoy",
		"1",
		255,
		79
	},

	{
		"gon_fild01",
		18420,
		101,
		776,
		"Kunlun Envoy",
		"1",
		187,
		239
	},

	{
		"gon_in",
		11541,
		101,
		774,
		"Yu Jiu Xia",
		"",
		173,
		27
	},

	{
		"gon_in",
		11545,
		101,
		702,
		"Hostess",
		"",
		152,
		35
	},

	{
		"gon_in",
		11547,
		101,
		771,
		"Madam",
		"",
		18,
		27
	},

	{
		"gon_test",
		11558,
		101,
		774,
		"Summoner",
		"",
		42,
		89
	},

	{
		"gon_test",
		11559,
		101,
		770,
		"Guide of field of fight",
		"",
		46,
		14
	},

	{
		"gon_test",
		11562,
		101,
		773,
		"ChowAnAn",
		"",
		70,
		103
	},

	{
		"gonryun",
		10050,
		101,
		109,
		"���������",
		"",
		156,
		122
	},

	{
		"gonryun",
		11534,
		101,
		776,
		"Han Ran Jiao",
		"",
		237,
		226
	},

	{
		"gonryun",
		11535,
		101,
		774,
		"Jian Chung Xun",
		"",
		200,
		82
	},

	{
		"gonryun",
		11536,
		101,
		776,
		"Liang Zhun Bu",
		"",
		268,
		88
	},

	{
		"gonryun",
		11537,
		101,
		89,
		"Qian Yuen Shuang",
		"",
		118,
		111
	},

	{
		"gonryun",
		11538,
		101,
		773,
		"Jing Wen Zhen",
		"",
		181,
		161
	},

	{
		"gonryun",
		11539,
		101,
		780,
		"Gatekeeper",
		"���",
		113,
		135
	},

	{
		"gonryun",
		11540,
		101,
		780,
		"Gatekeeper",
		"���",
		113,
		127
	},

	{
		"gonryun",
		11542,
		101,
		780,
		"Soldier",
		"",
		166,
		196
	},

	{
		"gonryun",
		11543,
		101,
		770,
		"Guidev",
		"",
		169,
		71
	},

	{
		"gonryun",
		11548,
		101,
		772,
		"Girl",
		"1",
		139,
		142
	},

	{
		"gonryun",
		11549,
		101,
		733,
		"Stranger",
		"",
		100,
		241
	},

	{
		"gonryun",
		11555,
		101,
		85,
		"Iron man",
		"",
		180,
		118
	},

	{
		"gonryun",
		15472,
		101,
		116,
		"Kafra Employee",
		"",
		159,
		122
	},

	{
		"gonryun",
		15578,
		102,
		777,
		"��������",
		"",
		147,
		84
	},

	{
		"gonryun",
		15579,
		102,
		770,
		"������",
		"",
		173,
		84
	},

	{
		"gonryun",
		15580,
		102,
		774,
		"�������",
		"",
		174,
		101
	},

	{
		"gonryun",
		15637,
		102,
		83,
		"�丮������",
		"",
		147,
		101
	},

	{
		"gonryun",
		15780,
		101,
		50,
		"����",
		"�����ǲ�",
		149,
		189
	},

	{
		"gonryun",
		15844,
		101,
		780,
		"Kunlun Guide",
		"01gonryun",
		163,
		60
	},

	{
		"gonryun",
		18421,
		101,
		776,
		"Kunlun Envoy",
		"3",
		153,
		64
	},

	{
		"gonryun",
		19548,
		101,
		837,
		"�ָ�",
		"���",
		155,
		198
	},

	{
		"gonryun",
		19593,
		101,
		729,
		"������ �����̵���",
		"25",
		162,
		122
	},

	{
		"hu_fild01",
		12822,
		101,
		852,
		"Tower Keeper",
		"",
		140,
		163
	},

	{
		"hu_fild05",
		18913,
		101,
		879,
		"Dancer Kim",
		"fild",
		342,
		130
	},

	{
		"hu_fild05",
		19531,
		101,
		837,
		"�ָ�",
		"���",
		188,
		210
	},

	{
		"hu_fild06",
		12948,
		101,
		97,
		"Postell Schuwell",
		"1",
		34,
		123
	},

	{
		"hu_fild06",
		12950,
		101,
		701,
		"Torpy's Mom",
		"",
		190,
		367
	},

	{
		"hu_fild06",
		12959,
		101,
		896,
		"Burupu",
		"�ְ�",
		217,
		270
	},

	{
		"hu_in01",
		12903,
		101,
		891,
		"Girl",
		"��ĥ Ʈ�δ�",
		310,
		380
	},

	{
		"hu_in01",
		12909,
		101,
		53,
		"Inn Maid",
		"",
		246,
		107
	},

	{
		"hu_in01",
		12910,
		101,
		793,
		"Girl",
		"hgtre",
		365,
		170
	},

	{
		"hu_in01",
		12911,
		101,
		892,
		"Pub Granny",
		"hgtre",
		377,
		106
	},

	{
		"hu_in01",
		12944,
		101,
		49,
		"A Part-Timer",
		"1",
		18,
		94
	},

	{
		"hu_in01",
		12945,
		101,
		50,
		"A Part-Timer",
		"2",
		26,
		77
	},

	{
		"hu_in01",
		12946,
		101,
		849,
		"Allen Schuwell",
		"�ְ�",
		387,
		245
	},

	{
		"hu_in01",
		12947,
		101,
		97,
		"Postell Schuwell",
		"2",
		385,
		247
	},

	{
		"hu_in01",
		12967,
		101,
		74,
		"Cellette Lavit",
		"hg",
		15,
		372
	},

	{
		"hu_in01",
		15367,
		101,
		105,
		"Falcon Breeder",
		"",
		381,
		304
	},

	{
		"hu_in01",
		15641,
		101,
		898,
		"Party Supplies Shop",
		"hg",
		23,
		311
	},

	{
		"hu_in01",
		15642,
		102,
		898,
		"���� ����",
		"",
		93,
		390
	},

	{
		"hu_in01",
		15643,
		102,
		86,
		"���� ����",
		"",
		100,
		390
	},

	{
		"hu_in01",
		15644,
		102,
		86,
		"�� ����",
		"",
		94,
		313
	},

	{
		"hu_in01",
		15645,
		102,
		53,
		"���� ����",
		"",
		241,
		368
	},

	{
		"hu_in01",
		15646,
		102,
		90,
		"���� ����",
		"",
		252,
		368
	},

	{
		"hu_in01",
		18792,
		101,
		79,
		"Praying Nun",
		"benew",
		205,
		204
	},

	{
		"hu_in01",
		18867,
		101,
		486,
		"Karian",
		"job_min2",
		267,
		5
	},

	{
		"hu_in01",
		18868,
		101,
		995,
		"Tone-deaf person",
		"job_min",
		361,
		103
	},

	{
		"hu_in01",
		18912,
		101,
		879,
		"Vacant Looking Lady",
		"wander",
		305,
		251
	},

	{
		"hugel",
		10042,
		101,
		109,
		"���������",
		"",
		80,
		152
	},

	{
		"hugel",
		12916,
		101,
		90,
		"Lisa",
		"3459",
		71,
		197
	},

	{
		"hugel",
		12917,
		101,
		90,
		"Emily",
		"3459",
		126,
		151
	},

	{
		"hugel",
		12918,
		101,
		837,
		"Sign",
		"",
		91,
		152
	},

	{
		"hugel",
		12927,
		101,
		709,
		"Boatman",
		"",
		209,
		109
	},

	{
		"hugel",
		12949,
		101,
		706,
		"Torpy",
		"",
		107,
		67
	},

	{
		"hugel",
		12951,
		101,
		898,
		"Strange Man",
		"out",
		100,
		174
	},

	{
		"hugel",
		12958,
		101,
		709,
		"Kurupe",
		"�ְ�",
		56,
		104
	},

	{
		"hugel",
		12960,
		101,
		889,
		"Booboo the Cow",
		"�ְ�",
		68,
		99
	},

	{
		"hugel",
		12961,
		101,
		896,
		"���� �ҳ�",
		"hg",
		85,
		165
	},

	{
		"hugel",
		12962,
		101,
		898,
		"Young Man",
		"hg",
		189,
		143
	},

	{
		"hugel",
		12963,
		101,
		897,
		"Marius",
		"hg",
		175,
		115
	},

	{
		"hugel",
		12964,
		101,
		892,
		"Old Nikki",
		"hg",
		169,
		112
	},

	{
		"hugel",
		12968,
		101,
		101,
		"Neha",
		"hg",
		76,
		134
	},

	{
		"hugel",
		12969,
		101,
		86,
		"Maewan",
		"hg",
		87,
		139
	},

	{
		"hugel",
		12970,
		101,
		700,
		"Layoma",
		"hg",
		84,
		125
	},

	{
		"hugel",
		12971,
		101,
		100,
		"Erjan",
		"hg",
		102,
		161
	},

	{
		"hugel",
		15486,
		101,
		874,
		"Cool Event Corp. Staff",
		"",
		88,
		168
	},

	{
		"hugel",
		15496,
		102,
		892,
		"���ϰ��� ����",
		"",
		77,
		167
	},

	{
		"hugel",
		15647,
		102,
		53,
		"���� ����",
		"",
		105,
		169
	},

	{
		"hugel",
		15728,
		101,
		897,
		"Ghenirhemin",
		"",
		147,
		103
	},

	{
		"hugel",
		15828,
		101,
		863,
		"Hugel Guide Granny",
		"hugel",
		98,
		56
	},

	{
		"hugel",
		15829,
		101,
		414,
		"Guide Rich King",
		"hugel",
		187,
		172
	},

	{
		"hugel",
		19437,
		101,
		798,
		"Eckar Ellebird",
		"single",
		58,
		72
	},

	{
		"hugel",
		19444,
		101,
		798,
		"Eckar Erenes",
		"double",
		62,
		69
	},

	{
		"hugel",
		19456,
		101,
		900,
		"Wayne",
		"",
		71,
		83
	},

	{
		"hugel",
		19458,
		101,
		866,
		"Mudie",
		"dummy01",
		85,
		93
	},

	{
		"hugel",
		19579,
		101,
		729,
		"������ �����̵���",
		"18",
		93,
		153
	},

	{
		"ice_dun01",
		18954,
		101,
		836,
		"Spirit Detecting Staff",
		"1",
		274,
		274
	},

	{
		"ice_dun01",
		19650,
		101,
		726,
		"������ �İߴܿ�",
		"2nd02",
		154,
		13
	},

	{
		"ice_dun02",
		12991,
		101,
		924,
		"Man Stuck in Ice",
		"cave",
		120,
		105
	},

	{
		"ice_dun02",
		18857,
		101,
		802,
		"���� �Ҳ�",
		"sc_f02",
		206,
		223
	},

	{
		"ice_dun03",
		12994,
		101,
		802,
		"Blazing Fire",
		"ice1",
		126,
		126
	},

	{
		"ice_dun03",
		12995,
		101,
		802,
		"Blazing Fire",
		"ice2",
		172,
		126
	},

	{
		"ice_dun03",
		12996,
		101,
		802,
		"Ÿ������ �Ҳ�",
		"ice3",
		172,
		173
	},

	{
		"ice_dun03",
		12997,
		101,
		802,
		"Blazing Fire",
		"ice4",
		127,
		172
	},

	{
		"ice_dun04",
		13002,
		101,
		925,
		"Frozen Boy",
		"",
		33,
		166
	},

	{
		"in_moc_16",
		15498,
		102,
		880,
		"��ħ�� ����",
		"",
		22,
		20
	},

	{
		"in_moc_16",
		18500,
		101,
		55,
		"Guildsman",
		"",
		19,
		33
	},

	{
		"in_moc_16",
		18505,
		101,
		730,
		"Guildsman",
		"ASN2",
		25,
		90
	},

	{
		"in_moc_16",
		18518,
		101,
		725,
		"Standby Room",
		"ASN",
		21,
		165
	},

	{
		"in_moc_16",
		18524,
		101,
		118,
		"Thomas",
		"ASNTEST",
		89,
		98
	},

	{
		"in_moc_16",
		18527,
		101,
		725,
		"Barcardi",
		"ASN",
		87,
		48
	},

	{
		"in_moc_16",
		18530,
		101,
		106,
		"Guildmaster",
		"ASN2",
		149,
		80
	},

	{
		"in_moc_16",
		18534,
		101,
		55,
		"Master Assist",
		"ASN",
		186,
		81
	},

	{
		"in_moc_16",
		18535,
		101,
		55,
		"[Huey]",
		"",
		156,
		87
	},

	{
		"in_moc_16",
		18536,
		101,
		730,
		"[Khai]",
		"",
		156,
		85
	},

	{
		"in_moc_16",
		18537,
		101,
		106,
		"[The Anonymous One]",
		"",
		156,
		83
	},

	{
		"in_moc_16",
		18538,
		101,
		725,
		"[Barcardi]",
		"",
		156,
		81
	},

	{
		"in_moc_16",
		18539,
		101,
		118,
		"[Beholder]",
		"",
		156,
		79
	},

	{
		"in_moc_16",
		18540,
		101,
		118,
		"[Thomas]",
		"",
		156,
		77
	},

	{
		"in_moc_16",
		18541,
		101,
		55,
		"[Gayle Maroubitz]",
		"",
		156,
		75
	},

	{
		"in_moc_16",
		19106,
		101,
		884,
		"Assassin",
		"���ڴ�",
		14,
		27
	},

	{
		"in_moc_16",
		19107,
		101,
		885,
		"Assassin",
		"���ڴ�",
		23,
		27
	},

	{
		"in_orcs01",
		15711,
		101,
		1023,
		"Orc Warrior",
		"1",
		31,
		93
	},

	{
		"in_orcs01",
		15713,
		101,
		1087,
		"Orc Hero",
		"1",
		162,
		33
	},

	{
		"in_orcs01",
		15740,
		101,
		1273,
		"Orc Lady",
		"2008hat03",
		119,
		106
	},

	{
		"in_orcs01",
		19641,
		101,
		803,
		"Eden Member Hooksha",
		"para07",
		38,
		175
	},

	{
		"in_rogue",
		11867,
		101,
		748,
		"Suspicious Man",
		"�ޱ�",
		243,
		61
	},

	{
		"in_rogue",
		18667,
		101,
		747,
		"Rogue Guildsman",
		"",
		363,
		122
	},

	{
		"in_rogue",
		18668,
		101,
		57,
		"Mr. Smith",
		"",
		376,
		23
	},

	{
		"in_rogue",
		18673,
		101,
		85,
		"Hermanthorn Jr",
		"",
		272,
		135
	},

	{
		"in_rogue",
		18677,
		101,
		99,
		"Aragham Junior",
		"",
		244,
		39
	},

	{
		"in_rogue",
		18681,
		101,
		85,
		"Hollgrehenn junior",
		"",
		160,
		34
	},

	{
		"in_rogue",
		18685,
		101,
		88,
		"Antonio junior",
		"",
		177,
		109
	},

	{
		"in_rogue",
		18850,
		101,
		828,
		"��������",
		"sc01",
		376,
		100
	},

	{
		"in_rogue",
		18851,
		101,
		747,
		"��������",
		"sc02",
		379,
		99
	},

	{
		"in_rogue",
		18852,
		101,
		810,
		"������ ������",
		"sc03",
		379,
		101
	},

	{
		"in_rogue",
		19110,
		101,
		705,
		"Killer",
		"�αױ��",
		357,
		174
	},

	{
		"in_rogue",
		19111,
		101,
		46,
		"Haijara Greg",
		"�αױ��",
		355,
		179
	},

	{
		"in_rogue",
		19112,
		101,
		84,
		"Louis Greg",
		"�αױ��",
		152,
		29
	},

	{
		"in_rogue",
		19113,
		101,
		86,
		"Thor Greg",
		"�αױ��",
		268,
		125
	},

	{
		"in_rogue",
		19117,
		101,
		85,
		"Jay Greg",
		"�αױ��",
		181,
		114
	},

	{
		"in_rogue",
		19487,
		101,
		828,
		"Rogue Investigator",
		"",
		366,
		46
	},

	{
		"in_rogue",
		19491,
		101,
		747,
		"Marybell",
		"",
		359,
		116
	},

	{
		"in_rogue",
		19505,
		101,
		118,
		"Rogue Agent",
		"",
		355,
		28
	},

	{
		"iz_ac01",
		18969,
		101,
		920,
		"ġ���",
		"nb01",
		59,
		43
	},

	{
		"iz_ac01",
		18984,
		101,
		642,
		"���� ���� �����",
		"ũ������",
		59,
		83
	},

	{
		"iz_ac01",
		18994,
		101,
		117,
		"ī���� �ȳ� ����",
		"1",
		95,
		46
	},

	{
		"iz_ac01",
		19000,
		101,
		117,
		"ī���� �ȳ� ����",
		"3",
		89,
		103
	},

	{
		"iz_ac01",
		19005,
		101,
		837,
		"[������]",
		"",
		93,
		76
	},

	{
		"iz_ac01",
		19006,
		101,
		837,
		"[������]",
		"",
		106,
		76
	},

	{
		"iz_ac01",
		19007,
		101,
		837,
		"[�Ĵ�]",
		"",
		106,
		44
	},

	{
		"iz_ac01",
		19008,
		101,
		837,
		"[�ǹ���]",
		"",
		93,
		44
	},

	{
		"iz_ac01",
		19009,
		101,
		837,
		"[�� ���ǽ�]",
		"",
		103,
		89
	},

	{
		"iz_ac01",
		19023,
		101,
		90,
		"��ī���� ������",
		"nk",
		100,
		39
	},

	{
		"iz_ac01",
		19024,
		101,
		418,
		"���� ������",
		"status",
		134,
		47
	},

	{
		"iz_ac01",
		19037,
		101,
		886,
		"��������",
		"ncook",
		147,
		47
	},

	{
		"iz_ac01",
		19038,
		101,
		721,
		"��Ŭ����",
		"ncook",
		149,
		46
	},

	{
		"iz_ac01",
		19039,
		101,
		860,
		"��ǣ��",
		"ncook",
		150,
		47
	},

	{
		"iz_ac01",
		19040,
		101,
		701,
		"������",
		"acook",
		160,
		47
	},

	{
		"iz_ac01",
		19041,
		101,
		567,
		"����� �л�",
		"acook",
		159,
		32
	},

	{
		"iz_ac01",
		19042,
		101,
		80,
		"�ٷ� ���л�",
		"acook",
		164,
		36
	},

	{
		"iz_ac01",
		19043,
		101,
		881,
		"�� ���� �л�",
		"acook",
		133,
		34
	},

	{
		"iz_ac02",
		18972,
		101,
		894,
		"�ʺ����� ���̼�",
		"nb01",
		52,
		136
	},

	{
		"iz_ac02",
		18974,
		101,
		899,
		"����",
		"nb01",
		49,
		134
	},

	{
		"iz_ac02",
		18975,
		101,
		467,
		"����ī��",
		"nb01",
		55,
		134
	},

	{
		"iz_ac02",
		18976,
		101,
		639,
		"���",
		"nbac01",
		62,
		139
	},

	{
		"iz_ac02",
		18985,
		101,
		641,
		"���� ��� ������",
		"ũ������",
		156,
		169
	},

	{
		"iz_ac02",
		18987,
		101,
		95,
		"�����",
		"ũ������",
		152,
		165
	},

	{
		"iz_ac02",
		18988,
		101,
		634,
		"�ü� ������",
		"newbe",
		65,
		109
	},

	{
		"iz_ac02",
		18990,
		101,
		906,
		"���",
		"gun",
		142,
		85
	},

	{
		"iz_ac02",
		18991,
		101,
		98,
		"����İ�����",
		"gun",
		162,
		86
	},

	{
		"iz_ac02",
		18992,
		101,
		735,
		"����ũ �ҿ� ����",
		"",
		148,
		110
	},

	{
		"iz_ac02",
		18997,
		101,
		117,
		"ī���� �ȳ� ����",
		"2",
		101,
		176
	},

	{
		"iz_ac02",
		19010,
		101,
		837,
		"[���� ���ǽ�)]",
		"",
		98,
		170
	},

	{
		"iz_ac02",
		19011,
		101,
		837,
		"[���� ���ǽ�]",
		"",
		109,
		170
	},

	{
		"iz_ac02",
		19012,
		101,
		837,
		"[���� ���ǽ�]",
		"",
		98,
		140
	},

	{
		"iz_ac02",
		19013,
		101,
		837,
		"[���� ���ǽ�]",
		"",
		109,
		140
	},

	{
		"iz_ac02",
		19014,
		101,
		837,
		"[�ü� ���ǽ�]",
		"",
		98,
		110
	},

	{
		"iz_ac02",
		19015,
		101,
		837,
		"[������ ���ǽ�]",
		"",
		109,
		110
	},

	{
		"iz_ac02",
		19016,
		101,
		837,
		"[�±� ���ǽ�]",
		"",
		98,
		80
	},

	{
		"iz_ac02",
		19017,
		101,
		837,
		"[�ǽ����� ���ǽ�]",
		"",
		109,
		80
	},

	{
		"iz_ac02",
		19018,
		101,
		837,
		"[�˻� ���ǽ�]",
		"",
		98,
		50
	},

	{
		"iz_ac02",
		19019,
		101,
		837,
		"[�ްԽ�]",
		"",
		109,
		50
	},

	{
		"iz_ac02",
		19020,
		101,
		837,
		"[ũ������ �����]",
		"",
		107,
		180
	},

	{
		"iz_ac02",
		19021,
		101,
		637,
		"���ڰ��̵�",
		"nk",
		140,
		139
	},

	{
		"iz_ac02",
		19025,
		101,
		608,
		"�˻米�� �����",
		"knight",
		47,
		50
	},

	{
		"iz_ac02",
		19026,
		101,
		635,
		"�˻� ����",
		"knight",
		47,
		48
	},

	{
		"iz_ac02",
		19031,
		101,
		418,
		"�˻� �α���",
		"knight",
		45,
		53
	},

	{
		"iz_ac02",
		19044,
		101,
		644,
		"�ƶ�",
		"1",
		70,
		85
	},

	{
		"iz_ac02",
		19047,
		101,
		706,
		"��ũ��",
		"jtest",
		143,
		55
	},

	{
		"iz_dun04",
		11002,
		101,
		413,
		"���� ������",
		"iz_dun",
		130,
		234
	},

	{
		"iz_dun04",
		19642,
		101,
		745,
		"Eden Member Callandiva",
		"para08",
		43,
		46
	},

	{
		"iz_dun05",
		11004,
		101,
		413,
		"������",
		"iz_dun",
		142,
		190
	},

	{
		"iz_ng01",
		19084,
		101,
		636,
		"���� ���� ���",
		"",
		25,
		67
	},

	{
		"izlu2dun",
		10988,
		101,
		100,
		"Sailor",
		"",
		108,
		27
	},

	{
		"izlu2dun",
		15450,
		101,
		116,
		"ī���� ����",
		"",
		106,
		58
	},

	{
		"izlu2dun",
		19523,
		101,
		837,
		"�ָ�",
		"��������",
		111,
		87
	},

	{
		"izlude",
		10045,
		101,
		109,
		"���������",
		"",
		125,
		148
	},

	{
		"izlude",
		10985,
		101,
		100,
		"����",
		"",
		197,
		205
	},

	{
		"izlude",
		10990,
		101,
		90,
		"����",
		"",
		71,
		92
	},

	{
		"izlude",
		10991,
		101,
		91,
		"������",
		"",
		172,
		215
	},

	{
		"izlude",
		10992,
		101,
		124,
		"�����ھ�",
		"",
		174,
		164
	},

	{
		"izlude",
		10993,
		101,
		84,
		"�尡",
		"",
		85,
		103
	},

	{
		"izlude",
		10994,
		101,
		97,
		"Ű��",
		"",
		140,
		186
	},

	{
		"izlude",
		10995,
		101,
		85,
		"����",
		"",
		57,
		159
	},

	{
		"izlude",
		10996,
		101,
		98,
		"�ù߸���",
		"",
		55,
		159
	},

	{
		"izlude",
		10998,
		101,
		105,
		"����",
		"",
		166,
		156
	},

	{
		"izlude",
		10999,
		101,
		49,
		"���尡",
		"",
		179,
		219
	},

	{
		"izlude",
		11772,
		101,
		71,
		"��ȥ �����",
		"������",
		180,
		224
	},

	{
		"izlude",
		11830,
		101,
		81,
		"��Ƽ",
		"arena",
		250,
		250
	},

	{
		"izlude",
		12082,
		101,
		90,
		"���� ����",
		"izlude",
		202,
		75
	},

	{
		"izlude",
		12756,
		101,
		853,
		"�Ǵ�",
		"",
		172,
		73
	},

	{
		"izlude",
		14071,
		101,
		100,
		"ȫ�����",
		"",
		102,
		171
	},

	{
		"izlude",
		15110,
		101,
		554,
		"���׳뷽",
		"����",
		182,
		218
	},

	{
		"izlude",
		15401,
		101,
		117,
		"ī���� ����",
		"",
		128,
		148
	},

	{
		"izlude",
		15514,
		102,
		53,
		"���ϻ���",
		"",
		124,
		165
	},

	{
		"izlude",
		15515,
		102,
		54,
		"�������",
		"",
		160,
		186
	},

	{
		"izlude",
		15516,
		102,
		90,
		"��������",
		"",
		128,
		158
	},

	{
		"izlude",
		15730,
		101,
		734,
		"�뺴��� ������",
		"��",
		47,
		170
	},

	{
		"izlude",
		15733,
		101,
		893,
		"�뺴��ǰ �ǸŻ�",
		"��",
		55,
		170
	},

	{
		"izlude",
		15753,
		101,
		700,
		"����Ʈ ����",
		"������",
		138,
		163
	},

	{
		"izlude",
		15794,
		101,
		105,
		"�ȳ����",
		"01izlude",
		129,
		175
	},

	{
		"izlude",
		15795,
		101,
		105,
		"�ȳ����",
		"02izlude",
		133,
		113
	},

	{
		"izlude",
		18123,
		101,
		92,
		"�����ϵ����",
		"",
		125,
		175
	},

	{
		"izlude",
		18469,
		101,
		837,
		"�ָ�",
		"������",
		25,
		103
	},

	{
		"izlude",
		18959,
		101,
		873,
		"���� ī��",
		"new_iz",
		198,
		213
	},

	{
		"izlude",
		18964,
		101,
		903,
		"ũ�������п� ���� ��",
		"nb01",
		122,
		207
	},

	{
		"izlude",
		18965,
		101,
		105,
		"�ȳ� ���",
		"iznb01",
		120,
		207
	},

	{
		"izlude",
		18966,
		101,
		858,
		"�����",
		"nb1",
		179,
		75
	},

	{
		"izlude",
		18967,
		101,
		858,
		"�Ʒ���",
		"nb1",
		207,
		167
	},

	{
		"izlude",
		18968,
		101,
		858,
		"����ǥ",
		"nb1",
		43,
		103
	},

	{
		"izlude",
		18970,
		101,
		1078,
		"���Ǵ� ���� Ǯ",
		"nb01",
		141,
		251
	},

	{
		"izlude",
		18971,
		101,
		639,
		"ũ������ �п���",
		"lumin01",
		140,
		249
	},

	{
		"izlude",
		19034,
		101,
		740,
		"�����ŴϾ�",
		"iz_ac",
		93,
		143
	},

	{
		"izlude",
		19035,
		101,
		726,
		"���� ���� �������̽�",
		"iz_bs",
		147,
		131
	},

	{
		"izlude",
		19036,
		101,
		881,
		"���øŴϾ�",
		"iz_bs",
		148,
		122
	},

	{
		"izlude",
		19058,
		101,
		84,
		"���ü����� ��",
		"jtuto",
		153,
		126
	},

	{
		"izlude",
		19059,
		101,
		406,
		"���øӽ� �ͱ���",
		"",
		153,
		121
	},

	{
		"izlude",
		19060,
		101,
		86,
		"Ÿ�嵥",
		"izj",
		145,
		122
	},

	{
		"izlude",
		19061,
		101,
		84,
		"��ī��",
		"izj",
		155,
		132
	},

	{
		"izlude",
		19603,
		101,
		729,
		"������ �����̵���",
		"30",
		131,
		148
	},

	{
		"izlude_in",
		10612,
		101,
		102,
		"Nain",
		"",
		173,
		88
	},

	{
		"izlude_in",
		10997,
		101,
		65,
		"Aaron",
		"",
		125,
		164
	},

	{
		"izlude_in",
		15517,
		102,
		72,
		"�������",
		"",
		60,
		127
	},

	{
		"izlude_in",
		15518,
		102,
		62,
		"������",
		"",
		70,
		127
	},

	{
		"izlude_in",
		15519,
		102,
		47,
		"��������",
		"",
		57,
		110
	},

	{
		"izlude_in",
		15520,
		102,
		124,
		"���ֻ̹���",
		"",
		72,
		98
	},

	{
		"izlude_in",
		18109,
		101,
		125,
		"Monster Tamer",
		"",
		129,
		64
	},

	{
		"izlude_in",
		18371,
		101,
		98,
		"Knight De Thomas",
		"",
		175,
		130
	},

	{
		"izlude_in",
		18496,
		101,
		119,
		"Swordman",
		"",
		74,
		172
	},

	{
		"izlude_in",
		18750,
		102,
		900,
		"��������",
		"",
		72,
		110
	},

	{
		"izlude_in",
		18754,
		101,
		86,
		"�Ѿ˻��� ���",
		"airplane",
		74,
		106
	},

	{
		"izlude_in",
		18755,
		101,
		83,
		"�Ѿ˰������ �ɴ�",
		"airplane",
		74,
		104
	},

	{
		"izlude_in",
		19033,
		101,
		894,
		"���� �ȳ���",
		"knight",
		60,
		103
	},

	{
		"izlude_in",
		19065,
		101,
		564,
		"�ʺ��ڿ� ���Ǳ�",
		"�˻��",
		69,
		177
	},

	{
		"izlude_in",
		19091,
		101,
		645,
		"�˻� 2�� ���� ����",
		"knight",
		70,
		168
	},

	{
		"izlude_in",
		19092,
		101,
		417,
		"�˻� ����",
		"knight",
		68,
		170
	},

	{
		"izlude_in",
		19481,
		101,
		878,
		"������",
		"",
		57,
		92
	},

	{
		"jawaii",
		11774,
		101,
		100,
		"Mariner",
		"������",
		239,
		112
	},

	{
		"jawaii",
		11776,
		101,
		100,
		"Mariner",
		"�˺���",
		122,
		263
	},

	{
		"jawaii",
		11778,
		101,
		80,
		"Tavern Lady",
		"",
		188,
		218
	},

	{
		"jawaii",
		11779,
		101,
		724,
		"Jawaii Resident",
		"��Ʈ��",
		220,
		235
	},

	{
		"jawaii",
		11780,
		101,
		724,
		"Jawaii Resident",
		"����1",
		240,
		146
	},

	{
		"jawaii",
		11781,
		101,
		724,
		"Jawaii Resident",
		"����2",
		168,
		247
	},

	{
		"jawaii",
		11782,
		101,
		724,
		"Jawaii Resident",
		"����3",
		165,
		121
	},

	{
		"jawaii",
		11783,
		101,
		798,
		"Employee",
		"����Ʈ��",
		141,
		200
	},

	{
		"jawaii",
		11785,
		101,
		74,
		"Employee",
		"��Ƽũ��",
		108,
		199
	},

	{
		"jawaii",
		11787,
		101,
		93,
		"Employee",
		"��Ϸ�",
		107,
		189
	},

	{
		"jawaii",
		11789,
		101,
		93,
		"Employee",
		"�����",
		112,
		173
	},

	{
		"jawaii",
		11791,
		101,
		71,
		"Honeymoon Helper",
		"�ڿ���",
		214,
		168
	},

	{
		"jawaii",
		11792,
		102,
		85,
		"���̽�ũ�� ����",
		"",
		186,
		174
	},

	{
		"jawaii_in",
		11760,
		101,
		724,
		"Employee",
		"jaw1",
		25,
		94
	},

	{
		"jawaii_in",
		11761,
		101,
		724,
		"Employee",
		"jaw2",
		25,
		96
	},

	{
		"jawaii_in",
		11762,
		101,
		724,
		"Employee",
		"jaw3",
		25,
		98
	},

	{
		"jawaii_in",
		11763,
		101,
		724,
		"Employee",
		"jaw4",
		25,
		100
	},

	{
		"jawaii_in",
		11764,
		101,
		724,
		"Employee",
		"jaw5",
		30,
		94
	},

	{
		"jawaii_in",
		11765,
		101,
		724,
		"Employee",
		"jaw6",
		30,
		96
	},

	{
		"jawaii_in",
		11766,
		101,
		724,
		"Employee",
		"jaw7",
		30,
		98
	},

	{
		"jawaii_in",
		11767,
		101,
		724,
		"Employee",
		"jaw8",
		30,
		100
	},

	{
		"jawaii_in",
		11768,
		101,
		80,
		"Waitress",
		"jawaii",
		15,
		104
	},

	{
		"jawaii_in",
		11769,
		101,
		46,
		"Bartender",
		"jaw",
		28,
		124
	},

	{
		"jawaii_in",
		11770,
		101,
		97,
		"Customer",
		"jaw_1",
		43,
		115
	},

	{
		"jawaii_in",
		11771,
		101,
		98,
		"Customer",
		"ī����",
		41,
		106
	},

	{
		"jawaii_in",
		11871,
		101,
		734,
		"Security Officer",
		"�ޱ�",
		44,
		110
	},

	{
		"job3_gen01",
		18923,
		101,
		865,
		"Devries",
		"gen",
		25,
		58
	},

	{
		"job3_gen01",
		18924,
		101,
		982,
		"Demi Calberine",
		"gen",
		91,
		48
	},

	{
		"job3_gen01",
		18927,
		101,
		837,
		"Warning",
		"gen",
		18,
		39
	},

	{
		"job3_gen01",
		19207,
		101,
		542,
		"�����",
		"job3_gen01",
		12,
		44
	},

	{
		"job3_guil01",
		15746,
		101,
		49,
		"Rare Herb Collector",
		"",
		91,
		93
	},

	{
		"job3_guil01",
		18834,
		101,
		940,
		"�ٿ���",
		"3rdgc02",
		82,
		95
	},

	{
		"job3_guil01",
		18835,
		101,
		894,
		"���̼�",
		"3rdgc03",
		16,
		20
	},

	{
		"job3_guil01",
		18843,
		101,
		919,
		"����ƿ��",
		"3rdgc11",
		79,
		15
	},

	{
		"job3_guil01",
		18847,
		101,
		467,
		"����ī��",
		"3rdgc16",
		148,
		53
	},

	{
		"job3_rune01",
		15744,
		101,
		853,
		"Rune Salesman",
		"",
		90,
		62
	},

	{
		"job3_rune01",
		18801,
		101,
		470,
		"Rune Knight Captain",
		"",
		80,
		60
	},

	{
		"job3_rune01",
		18803,
		101,
		469,
		"Rune Knight Lunarea",
		"",
		90,
		50
	},

	{
		"job3_rune01",
		18804,
		101,
		469,
		"Rune Knight, Renoa",
		"",
		55,
		50
	},

	{
		"job3_rune01",
		18816,
		101,
		468,
		"Rune Knight Velpino",
		"",
		114,
		50
	},

	{
		"job3_rune01",
		18817,
		101,
		114,
		"Kafra Employee",
		"",
		92,
		62
	},

	{
		"job_duncer",
		13199,
		101,
		892,
		"Dance Instructor",
		"sch",
		93,
		106
	},

	{
		"job_duncer",
		13200,
		101,
		724,
		"Young Dancer",
		"sch",
		85,
		49
	},

	{
		"job_duncer",
		13202,
		101,
		724,
		"Cheerful Dancer",
		"sch",
		83,
		52
	},

	{
		"job_duncer",
		13204,
		101,
		724,
		"Mature Looking Dancer",
		"sch",
		87,
		50
	},

	{
		"job_duncer",
		18606,
		101,
		724,
		"Aile",
		"",
		43,
		93
	},

	{
		"job_duncer",
		18607,
		101,
		101,
		"Bijou",
		"",
		95,
		93
	},

	{
		"job_duncer",
		18610,
		101,
		66,
		"Waiting Room",
		"click",
		32,
		154
	},

	{
		"job_duncer",
		18619,
		101,
		724,
		"Backdancer",
		"1",
		63,
		110
	},

	{
		"job_duncer",
		18620,
		101,
		724,
		"Backdancer",
		"2",
		66,
		113
	},

	{
		"job_duncer",
		18621,
		101,
		724,
		"Backdancer",
		"3",
		72,
		113
	},

	{
		"job_duncer",
		18622,
		101,
		724,
		"Backdancer",
		"4",
		75,
		110
	},

	{
		"job_duncer",
		18624,
		101,
		837,
		"�ȳ���",
		"dancer",
		104,
		116
	},

	{
		"job_duncer",
		18625,
		101,
		837,
		"�ȳ���",
		"dancer2",
		106,
		155
	},

	{
		"job_duncer",
		18626,
		101,
		837,
		"�ȳ���",
		"dancer3",
		69,
		153
	},

	{
		"job_monk",
		18643,
		101,
		89,
		"Hyunmoo",
		"1",
		225,
		180
	},

	{
		"job_star",
		18720,
		101,
		59,
		"Daru",
		"job_star",
		29,
		33
	},

	{
		"job_star",
		18731,
		101,
		106,
		"Beeryu",
		"job_star",
		95,
		33
	},

	{
		"job_star",
		18741,
		101,
		77,
		"Cheehee",
		"job_star",
		161,
		33
	},

	{
		"jupe_cave",
		18779,
		101,
		883,
		"Scholar",
		"",
		37,
		55
	},

	{
		"jupe_cave",
		19522,
		101,
		837,
		"�ָ�",
		"����ν�",
		35,
		57
	},

	{
		"jupe_core2",
		18781,
		101,
		802,
		"Ghostfire",
		"1",
		149,
		273
	},

	{
		"jupe_core2",
		18783,
		101,
		802,
		"Ghostfire",
		"2",
		53,
		75
	},

	{
		"jupe_core2",
		18784,
		101,
		802,
		"Ghostfire",
		"3",
		242,
		62
	},

	{
		"kh_dun01",
		19431,
		101,
		857,
		"Signboard",
		"kh",
		163,
		223
	},

	{
		"kh_kiehl02",
		19424,
		101,
		902,
		"Kiehl",
		"kh",
		50,
		52
	},

	{
		"kh_kiehl02",
		19426,
		101,
		727,
		"Mitchell",
		"kh",
		49,
		55
	},

	{
		"kh_kiehl02",
		19427,
		101,
		880,
		"Agent",
		"kh1",
		46,
		53
	},

	{
		"kh_kiehl02",
		19428,
		101,
		880,
		"Agent",
		"kh2",
		47,
		50
	},

	{
		"kh_kiehl02",
		19429,
		101,
		880,
		"Agent",
		"kh3",
		51,
		49
	},

	{
		"kh_kiehl02",
		19430,
		101,
		880,
		"Agent",
		"kh4",
		53,
		52
	},

	{
		"kh_mansion",
		19400,
		101,
		109,
		"����",
		"kh",
		78,
		54
	},

	{
		"kh_mansion",
		19408,
		101,
		894,
		"Allysia",
		"",
		18,
		30
	},

	{
		"kh_mansion",
		19409,
		101,
		903,
		"Kiel Hyre",
		"kh",
		22,
		28
	},

	{
		"kh_mansion",
		19411,
		101,
		727,
		"Mysterious Woman",
		"kh",
		25,
		79
	},

	{
		"kh_school",
		10089,
		101,
		71,
		"��� ����",
		"ev",
		151,
		28
	},

	{
		"kh_school",
		10090,
		101,
		798,
		"�Ƹ��� ��������",
		"ev",
		177,
		27
	},

	{
		"kh_school",
		10092,
		101,
		828,
		"�̼���",
		"valen07",
		158,
		28
	},

	{
		"kh_school",
		10099,
		101,
		837,
		"����Ʈ ���� �ȳ�",
		"01",
		66,
		158
	},

	{
		"kh_school",
		10100,
		101,
		837,
		"����Ʈ ���� �ȳ�",
		"02",
		41,
		138
	},

	{
		"kh_school",
		10128,
		101,
		726,
		"������",
		"01",
		179,
		19
	},

	{
		"kh_school",
		10129,
		101,
		90,
		"������",
		"02",
		183,
		23
	},

	{
		"kh_school",
		10131,
		102,
		892,
		"�����ⱸ ����",
		"",
		161,
		28
	},

	{
		"kh_school",
		19371,
		101,
		893,
		"Student",
		"kha",
		57,
		142
	},

	{
		"kh_school",
		19372,
		101,
		893,
		"Student",
		"khb",
		57,
		139
	},

	{
		"kh_school",
		19373,
		101,
		101,
		"Lady",
		"kh",
		176,
		60
	},

	{
		"kh_school",
		19378,
		101,
		895,
		"Cute Student",
		"kh",
		179,
		39
	},

	{
		"kh_school",
		19385,
		101,
		895,
		"����",
		"",
		177,
		180
	},

	{
		"kh_school",
		19387,
		101,
		894,
		"Beautiful lady",
		"kh1",
		117,
		149
	},

	{
		"kh_school",
		19388,
		101,
		894,
		"Beautiful lady",
		"kh1",
		118,
		149
	},

	{
		"kh_school",
		19389,
		101,
		894,
		"Beautiful lady",
		"kh1",
		120,
		149
	},

	{
		"kh_school",
		19390,
		101,
		894,
		"Beautiful lady",
		"kh1",
		121,
		149
	},

	{
		"kh_school",
		19391,
		101,
		894,
		"Beautiful Lady",
		"kh1",
		119,
		149
	},

	{
		"kh_school",
		19395,
		101,
		894,
		"Beautiful Lady",
		"kh2",
		122,
		186
	},

	{
		"kh_vila",
		19379,
		101,
		81,
		"Vicious Dog",
		"khp1",
		181,
		178
	},

	{
		"lhz_airport",
		12058,
		101,
		90,
		"Airport Staff",
		"lhz_airport1a",
		143,
		43
	},

	{
		"lhz_airport",
		12061,
		101,
		90,
		"Airship Staff",
		"lhz_airport1b",
		158,
		43
	},

	{
		"lhz_airport",
		12064,
		101,
		90,
		"Airship Staff",
		"lhz_airport1c",
		126,
		43
	},

	{
		"lhz_airport",
		12067,
		101,
		90,
		"Arrival Staff",
		"lhz_airport2a",
		143,
		49
	},

	{
		"lhz_airport",
		12069,
		101,
		90,
		"Arrival Staff",
		"lhz_airport2b",
		126,
		51
	},

	{
		"lhz_airport",
		12071,
		101,
		90,
		"Arrival Staff",
		"lhz_airport2c",
		158,
		50
	},

	{
		"lhz_dun02",
		12668,
		101,
		837,
		"�����",
		"lhz��",
		177,
		150
	},

	{
		"lhz_dun02",
		12669,
		101,
		837,
		"�����",
		"lhz��",
		150,
		122
	},

	{
		"lhz_dun02",
		12670,
		101,
		837,
		"�����",
		"lhz��",
		122,
		149
	},

	{
		"lhz_dun02",
		12671,
		101,
		837,
		"�����",
		"lhz��",
		149,
		178
	},

	{
		"lhz_dun04",
		12774,
		101,
		865,
		"������",
		"memo",
		151,
		276
	},

	{
		"lhz_fild01",
		12328,
		101,
		859,
		"Mysterious Woman",
		"lt7",
		66,
		219
	},

	{
		"lhz_fild02",
		12326,
		101,
		849,
		"Wounded Man",
		"lt",
		228,
		214
	},

	{
		"lhz_in01",
		12329,
		101,
		865,
		"Researcher",
		"lt",
		93,
		45
	},

	{
		"lhz_in01",
		12330,
		101,
		865,
		"Researcher",
		"lt1",
		285,
		169
	},

	{
		"lhz_in01",
		12331,
		101,
		868,
		"Guard",
		"lt5",
		180,
		28
	},

	{
		"lhz_in01",
		12332,
		101,
		868,
		"Guard",
		"lt5",
		173,
		28
	},

	{
		"lhz_in01",
		12337,
		101,
		862,
		"Guide",
		"lt2",
		73,
		188
	},

	{
		"lhz_in01",
		12338,
		101,
		90,
		"Guide",
		"lt1",
		72,
		195
	},

	{
		"lhz_in01",
		12339,
		101,
		862,
		"Guide",
		"lt1",
		72,
		209
	},

	{
		"lhz_in01",
		12442,
		101,
		71,
		"Representative",
		"li_01",
		114,
		181
	},

	{
		"lhz_in01",
		12443,
		101,
		71,
		"Representative",
		"li_02",
		27,
		247
	},

	{
		"lhz_in01",
		12444,
		101,
		865,
		"Mad Scientist",
		"li",
		273,
		121
	},

	{
		"lhz_in01",
		12445,
		101,
		831,
		"Secretary Slierre",
		"li",
		286,
		226
	},

	{
		"lhz_in01",
		12449,
		101,
		867,
		"Rekenber Guard",
		"li01",
		35,
		226
	},

	{
		"lhz_in01",
		12450,
		101,
		867,
		"Rekenber Guard",
		"li02",
		23,
		132
	},

	{
		"lhz_in01",
		12451,
		101,
		867,
		"Rekenber Guard",
		"li03",
		46,
		125
	},

	{
		"lhz_in01",
		12452,
		101,
		98,
		"Jorje",
		"zero",
		144,
		53
	},

	{
		"lhz_in01",
		12453,
		101,
		869,
		"Mereth",
		"erem",
		129,
		54
	},

	{
		"lhz_in01",
		12454,
		101,
		89,
		"Jorjerro",
		"fhero",
		110,
		40
	},

	{
		"lhz_in01",
		12455,
		101,
		841,
		"Ninjose",
		"nina",
		116,
		53
	},

	{
		"lhz_in01",
		12456,
		101,
		704,
		"Joshua",
		"aya",
		116,
		45
	},

	{
		"lhz_in01",
		12457,
		101,
		822,
		"Kejulle Rekenber",
		"reken",
		116,
		39
	},

	{
		"lhz_in01",
		12459,
		101,
		91,
		"Eiya",
		"iaiai",
		164,
		45
	},

	{
		"lhz_in01",
		12460,
		101,
		797,
		"Mareth",
		"seram",
		157,
		47
	},

	{
		"lhz_in01",
		12461,
		101,
		828,
		"Mazwon",
		"minus1",
		147,
		40
	},

	{
		"lhz_in01",
		12462,
		101,
		97,
		"Noama",
		"amano",
		148,
		45
	},

	{
		"lhz_in01",
		12463,
		101,
		53,
		"Enoz",
		"oz",
		139,
		40
	},

	{
		"lhz_in01",
		12464,
		101,
		73,
		"Leimi",
		"mimir",
		139,
		48
	},

	{
		"lhz_in01",
		12465,
		101,
		869,
		"Cenku Dekdam",
		"delic",
		134,
		45
	},

	{
		"lhz_in01",
		12466,
		101,
		798,
		"Bankri Kun",
		"kagun",
		134,
		38
	},

	{
		"lhz_in01",
		12467,
		101,
		849,
		"Leekal",
		"lackee",
		125,
		46
	},

	{
		"lhz_in01",
		12468,
		101,
		843,
		"Dowbow Ryuei",
		"ryusei",
		125,
		40
	},

	{
		"lhz_in01",
		12469,
		101,
		66,
		"Ellette",
		"tre",
		124,
		28
	},

	{
		"lhz_in01",
		12471,
		101,
		865,
		"Scientist",
		"li_01",
		221,
		131
	},

	{
		"lhz_in01",
		12472,
		101,
		851,
		"Repairman",
		"li_01",
		217,
		121
	},

	{
		"lhz_in01",
		12473,
		101,
		750,
		"Scientist",
		"li_02",
		203,
		123
	},

	{
		"lhz_in01",
		12474,
		101,
		865,
		"Scientist",
		"li_03",
		199,
		137
	},

	{
		"lhz_in01",
		12486,
		101,
		109,
		"Banquet Staff",
		"",
		14,
		28
	},

	{
		"lhz_in01",
		12487,
		101,
		703,
		"Luccet",
		"li_party",
		43,
		52
	},

	{
		"lhz_in01",
		12488,
		101,
		706,
		"Hanccet",
		"li_party",
		28,
		33
	},

	{
		"lhz_in01",
		12489,
		101,
		91,
		"Annette",
		"li_party",
		21,
		50
	},

	{
		"lhz_in01",
		12732,
		101,
		868,
		"���˺��� ����",
		"40",
		24,
		140
	},

	{
		"lhz_in01",
		12753,
		101,
		868,
		"Young Man",
		"",
		174,
		258
	},

	{
		"lhz_in01",
		14072,
		101,
		868,
		"Sikaiz",
		"",
		132,
		259
	},

	{
		"lhz_in01",
		14073,
		101,
		967,
		"Munkenro",
		"",
		136,
		260
	},

	{
		"lhz_in01",
		14077,
		101,
		109,
		"Officer A",
		"",
		32,
		22
	},

	{
		"lhz_in01",
		14078,
		101,
		109,
		"Officer B",
		"",
		30,
		24
	},

	{
		"lhz_in01",
		14080,
		101,
		899,
		"Guard",
		"",
		115,
		250
	},

	{
		"lhz_in01",
		14081,
		101,
		899,
		"Guard",
		"",
		115,
		252
	},

	{
		"lhz_in01",
		14082,
		101,
		899,
		"Guard",
		"",
		147,
		252
	},

	{
		"lhz_in01",
		14083,
		101,
		899,
		"Guard",
		"",
		147,
		250
	},

	{
		"lhz_in01",
		14084,
		101,
		899,
		"Guard",
		"",
		124,
		234
	},

	{
		"lhz_in01",
		14085,
		101,
		899,
		"Guard",
		"",
		121,
		234
	},

	{
		"lhz_in01",
		14086,
		101,
		899,
		"Guard",
		"",
		137,
		234
	},

	{
		"lhz_in01",
		14087,
		101,
		899,
		"Guard",
		"",
		140,
		234
	},

	{
		"lhz_in01",
		14088,
		101,
		899,
		"Guard",
		"",
		130,
		232
	},

	{
		"lhz_in01",
		14089,
		101,
		904,
		"Member of Alliance",
		"",
		128,
		249
	},

	{
		"lhz_in01",
		14090,
		101,
		869,
		"Member of Alliance",
		"",
		136,
		245
	},

	{
		"lhz_in01",
		14091,
		101,
		85,
		"Member of Alliance",
		"",
		140,
		245
	},

	{
		"lhz_in01",
		14092,
		101,
		865,
		"Member of Alliance",
		"",
		136,
		249
	},

	{
		"lhz_in01",
		14093,
		101,
		932,
		"Member of Alliance",
		"",
		124,
		245
	},

	{
		"lhz_in01",
		14094,
		101,
		849,
		"Member of Alliance",
		"",
		136,
		241
	},

	{
		"lhz_in01",
		14095,
		101,
		930,
		"Member of Alliance",
		"",
		126,
		249
	},

	{
		"lhz_in01",
		14096,
		101,
		882,
		"Member of Alliance",
		"",
		122,
		245
	},

	{
		"lhz_in01",
		14129,
		101,
		903,
		"Gerhart",
		"",
		110,
		174
	},

	{
		"lhz_in01",
		19098,
		101,
		57,
		"Kellasus",
		"",
		224,
		140
	},

	{
		"lhz_in01",
		19099,
		101,
		754,
		"Skrajjad",
		"",
		225,
		122
	},

	{
		"lhz_in01",
		19100,
		101,
		750,
		"Keshibien",
		"",
		204,
		138
	},

	{
		"lhz_in01",
		19105,
		101,
		98,
		"Alchemist",
		"",
		218,
		141
	},

	{
		"lhz_in02",
		12340,
		101,
		831,
		"Cool Event Staff",
		"",
		36,
		274
	},

	{
		"lhz_in02",
		12341,
		101,
		833,
		"Event Planner",
		"",
		40,
		280
	},

	{
		"lhz_in02",
		12342,
		101,
		853,
		"Cool Event Manager",
		"",
		110,
		286
	},

	{
		"lhz_in02",
		12343,
		101,
		874,
		"Cool Event Staff",
		"",
		36,
		284
	},

	{
		"lhz_in02",
		12344,
		101,
		851,
		"Maintenance Guy",
		"",
		19,
		274
	},

	{
		"lhz_in02",
		12346,
		101,
		869,
		"Digotz",
		"",
		201,
		210
	},

	{
		"lhz_in02",
		12358,
		101,
		753,
		"Martial Artist",
		"",
		289,
		277
	},

	{
		"lhz_in02",
		12372,
		101,
		869,
		"Harp",
		"",
		221,
		276
	},

	{
		"lhz_in02",
		12386,
		101,
		747,
		"Diana",
		"",
		267,
		25
	},

	{
		"lhz_in02",
		12387,
		101,
		91,
		"Shop Assistant",
		"",
		267,
		22
	},

	{
		"lhz_in02",
		12389,
		101,
		91,
		"Maggie",
		"05",
		34,
		212
	},

	{
		"lhz_in02",
		12390,
		101,
		853,
		"Millette",
		"05",
		153,
		206
	},

	{
		"lhz_in02",
		12391,
		101,
		870,
		"Hinkley",
		"06",
		157,
		201
	},

	{
		"lhz_in02",
		12392,
		101,
		849,
		"Togii",
		"07",
		145,
		177
	},

	{
		"lhz_in02",
		12393,
		101,
		863,
		"Tanoue",
		"06",
		229,
		217
	},

	{
		"lhz_in02",
		12394,
		101,
		85,
		"����",
		"06",
		147,
		221
	},

	{
		"lhz_in02",
		12395,
		101,
		870,
		"Suspect",
		"06",
		142,
		222
	},

	{
		"lhz_in02",
		12403,
		101,
		86,
		"Hotel Employee",
		"",
		230,
		284
	},

	{
		"lhz_in02",
		12404,
		101,
		869,
		"Hotel Employee",
		"",
		238,
		275
	},

	{
		"lhz_in02",
		12405,
		101,
		84,
		"Ben Allen",
		"",
		209,
		277
	},

	{
		"lhz_in02",
		12406,
		101,
		868,
		"Hotel Employee",
		"",
		251,
		212
	},

	{
		"lhz_in02",
		12407,
		101,
		849,
		"Christopher Michael",
		"",
		210,
		189
	},

	{
		"lhz_in02",
		12408,
		101,
		853,
		"Safwat Fahmy",
		"",
		201,
		181
	},

	{
		"lhz_in02",
		12409,
		101,
		868,
		"Hotel Employee",
		"",
		242,
		172
	},

	{
		"lhz_in02",
		12410,
		101,
		868,
		"Hotel Employee",
		"",
		247,
		275
	},

	{
		"lhz_in02",
		12417,
		101,
		849,
		"Arthur",
		"",
		34,
		41
	},

	{
		"lhz_in02",
		12418,
		101,
		703,
		"Helen",
		"",
		28,
		39
	},

	{
		"lhz_in02",
		12419,
		101,
		847,
		"Tadem",
		"",
		31,
		34
	},

	{
		"lhz_in02",
		12420,
		101,
		863,
		"Gracie",
		"",
		31,
		33
	},

	{
		"lhz_in02",
		12421,
		101,
		86,
		"Bank Clerk",
		"",
		21,
		38
	},

	{
		"lhz_in02",
		12422,
		101,
		86,
		"Bank Clerk",
		"",
		21,
		25
	},

	{
		"lhz_in02",
		12423,
		101,
		755,
		"Bank Clerk",
		"",
		34,
		22
	},

	{
		"lhz_in02",
		12482,
		101,
		85,
		"Healthy Looking Guy",
		"hol",
		159,
		198
	},

	{
		"lhz_in02",
		12483,
		101,
		122,
		"Hair Dresser",
		"li",
		100,
		143
	},

	{
		"lhz_in02",
		12484,
		101,
		850,
		"Hair Dyer",
		"lich",
		100,
		134
	},

	{
		"lhz_in02",
		12485,
		101,
		862,
		"Assistant Beautician",
		"lich",
		91,
		155
	},

	{
		"lhz_in02",
		12741,
		101,
		61,
		"Bartender",
		"amano07",
		277,
		285
	},

	{
		"lhz_in02",
		12742,
		101,
		865,
		"Lab Staff",
		"amano08",
		265,
		273
	},

	{
		"lhz_in02",
		12743,
		101,
		47,
		"Citizen",
		"amano09",
		271,
		281
	},

	{
		"lhz_in02",
		12744,
		101,
		853,
		"Customer",
		"amano10",
		287,
		282
	},

	{
		"lhz_in02",
		12745,
		101,
		50,
		"Customer",
		"amano11",
		287,
		273
	},

	{
		"lhz_in02",
		12746,
		101,
		815,
		"Customer",
		"amano12",
		283,
		276
	},

	{
		"lhz_in02",
		12747,
		101,
		816,
		"Customer",
		"amano13",
		281,
		280
	},

	{
		"lhz_in02",
		15484,
		101,
		861,
		"Kafra Employee",
		"",
		237,
		284
	},

	{
		"lhz_in02",
		15602,
		102,
		851,
		"�������",
		"",
		276,
		99
	},

	{
		"lhz_in02",
		15603,
		102,
		854,
		"�����̻���",
		"",
		273,
		35
	},

	{
		"lhz_in02",
		15604,
		102,
		851,
		"������",
		"",
		271,
		99
	},

	{
		"lhz_in02",
		15605,
		102,
		62,
		"�ʺ��ڿ�ǰ ����",
		"",
		286,
		95
	},

	{
		"lhz_in02",
		15606,
		102,
		91,
		"��������",
		"",
		105,
		21
	},

	{
		"lhz_in02",
		15607,
		102,
		102,
		"���ϻ���",
		"",
		21,
		220
	},

	{
		"lhz_in02",
		15608,
		102,
		91,
		"��ä����",
		"",
		17,
		220
	},

	{
		"lhz_in02",
		15609,
		102,
		54,
		"�������",
		"",
		32,
		219
	},

	{
		"lhz_in02",
		15610,
		102,
		91,
		"����ǰ����",
		"",
		38,
		145
	},

	{
		"lhz_in02",
		15611,
		102,
		862,
		"��������",
		"",
		85,
		216
	},

	{
		"lhz_in02",
		15612,
		102,
		715,
		"�峭������",
		"",
		87,
		208
	},

	{
		"lhz_in02",
		15613,
		102,
		90,
		"��������",
		"",
		31,
		145
	},

	{
		"lhz_in02",
		15660,
		102,
		71,
		"ȥ��ǰ����",
		"",
		47,
		148
	},

	{
		"lhz_in02",
		15714,
		101,
		90,
		"Margaret Mary",
		"hat",
		91,
		38
	},

	{
		"lhz_in02",
		15743,
		101,
		877,
		"Poison Herb Salesman",
		"",
		16,
		205
	},

	{
		"lhz_in02",
		15781,
		101,
		748,
		"��������",
		"��Ÿ��",
		276,
		281
	},

	{
		"lhz_in02",
		18397,
		101,
		84,
		"Fruel",
		"",
		281,
		24
	},

	{
		"lhz_in02",
		18398,
		101,
		86,
		"Krugg",
		"",
		278,
		24
	},

	{
		"lhz_in02",
		18399,
		101,
		869,
		"Fulerr",
		"",
		282,
		20
	},

	{
		"lhz_in02",
		18443,
		101,
		86,
		"Repairman",
		"",
		284,
		14
	},

	{
		"lhz_in02",
		19101,
		101,
		709,
		"Broncher",
		"",
		278,
		273
	},

	{
		"lhz_in02",
		19472,
		101,
		84,
		"Seiyablem",
		"",
		281,
		35
	},

	{
		"lhz_in02",
		19478,
		101,
		97,
		"Young Man",
		"",
		269,
		33
	},

	{
		"lhz_in03",
		12364,
		101,
		863,
		"Sopheap",
		"",
		32,
		99
	},

	{
		"lhz_in03",
		12365,
		101,
		869,
		"Gopal",
		"",
		25,
		105
	},

	{
		"lhz_in03",
		12376,
		101,
		849,
		"Avetis",
		"",
		239,
		38
	},

	{
		"lhz_in03",
		12383,
		101,
		55,
		"Loudmouth",
		"",
		184,
		38
	},

	{
		"lhz_in03",
		12384,
		101,
		855,
		"Haggar",
		"",
		192,
		19
	},

	{
		"lhz_in03",
		12438,
		101,
		53,
		"Crippled Girl",
		"li_tre",
		32,
		162
	},

	{
		"lhz_in03",
		12441,
		101,
		850,
		"Shayna",
		"li",
		26,
		167
	},

	{
		"lhz_in03",
		12494,
		101,
		81,
		"Rocky",
		"li_house",
		100,
		18
	},

	{
		"lhz_in03",
		12495,
		101,
		850,
		"Housemaid Jane",
		"li_house",
		129,
		22
	},

	{
		"lhz_in03",
		12496,
		101,
		706,
		"Jay",
		"li_house",
		130,
		41
	},

	{
		"lhz_in03",
		12497,
		101,
		74,
		"Housemaid Brenda",
		"li_house",
		124,
		117
	},

	{
		"lhz_in03",
		12733,
		101,
		61,
		"Bartender",
		"12",
		193,
		25
	},

	{
		"lhz_in03",
		12734,
		101,
		869,
		"Bad Drunk",
		"12",
		186,
		29
	},

	{
		"lhz_in03",
		12735,
		101,
		869,
		"Drunken Man",
		"amano01",
		189,
		87
	},

	{
		"lhz_in03",
		12736,
		101,
		870,
		"Drunken Man",
		"amano02",
		183,
		82
	},

	{
		"lhz_in03",
		12737,
		101,
		86,
		"Citizen",
		"amano03",
		180,
		83
	},

	{
		"lhz_in03",
		12738,
		101,
		869,
		"Citizen",
		"amano04",
		176,
		85
	},

	{
		"lhz_in03",
		12739,
		101,
		862,
		"City Girl",
		"amano05",
		192,
		93
	},

	{
		"lhz_in03",
		12740,
		101,
		869,
		"Bad Drunk",
		"amano06",
		185,
		20
	},

	{
		"lhz_in03",
		12902,
		101,
		97,
		"Enquro Carson",
		"",
		39,
		44
	},

	{
		"lhz_in03",
		12915,
		101,
		83,
		"Makkie",
		"1234",
		193,
		28
	},

	{
		"lhz_in03",
		15614,
		102,
		850,
		"��������",
		"",
		239,
		106
	},

	{
		"lhz_in03",
		15615,
		102,
		855,
		"��������",
		"",
		258,
		101
	},

	{
		"lhz_in03",
		15616,
		102,
		855,
		"����",
		"",
		249,
		24
	},

	{
		"lhz_in03",
		15669,
		102,
		49,
		"�ϰŷ���",
		"",
		181,
		17
	},

	{
		"lhz_in03",
		19102,
		101,
		706,
		"Koring",
		"",
		106,
		34
	},

	{
		"lhz_in03",
		19103,
		101,
		90,
		"Beninne",
		"",
		109,
		31
	},

	{
		"lhz_que01",
		12424,
		101,
		755,
		"",
		"li_�ٸ���Ʈ",
		21,
		31
	},

	{
		"lhz_que01",
		12428,
		101,
		754,
		"",
		"li_������",
		29,
		24
	},

	{
		"lhz_que01",
		12433,
		101,
		48,
		"",
		"li_����",
		99,
		74
	},

	{
		"lhz_que01",
		12436,
		101,
		1019,
		"",
		"li_bird",
		90,
		71
	},

	{
		"lighthalzen",
		10039,
		101,
		109,
		"���������",
		"",
		167,
		97
	},

	{
		"lighthalzen",
		10097,
		101,
		853,
		"������ û�� R��",
		"",
		80,
		145
	},

	{
		"lighthalzen",
		10119,
		101,
		831,
		"����Ʈ���� �ȳ���",
		"lhz",
		219,
		205
	},

	{
		"lighthalzen",
		12307,
		101,
		98,
		"Ordinary Man",
		"lt1",
		179,
		170
	},

	{
		"lighthalzen",
		12345,
		101,
		870,
		"Maku",
		"",
		337,
		232
	},

	{
		"lighthalzen",
		12349,
		101,
		868,
		"Guard",
		"",
		267,
		200
	},

	{
		"lighthalzen",
		12353,
		101,
		868,
		"Guard",
		"",
		294,
		223
	},

	{
		"lighthalzen",
		12357,
		101,
		869,
		"Kosit",
		"",
		107,
		107
	},

	{
		"lighthalzen",
		12359,
		101,
		862,
		"Joyce",
		"",
		190,
		134
	},

	{
		"lighthalzen",
		12360,
		101,
		869,
		"Dan Song",
		"",
		191,
		134
	},

	{
		"lighthalzen",
		12361,
		101,
		862,
		"Maivi",
		"",
		78,
		120
	},

	{
		"lighthalzen",
		12362,
		101,
		869,
		"Sigmund",
		"",
		232,
		156
	},

	{
		"lighthalzen",
		12363,
		101,
		862,
		"Jade",
		"",
		239,
		64
	},

	{
		"lighthalzen",
		12366,
		101,
		866,
		"Collins",
		"",
		115,
		159
	},

	{
		"lighthalzen",
		12367,
		101,
		862,
		"Kimmy",
		"",
		176,
		65
	},

	{
		"lighthalzen",
		12368,
		101,
		863,
		"Samnang",
		"",
		220,
		244
	},

	{
		"lighthalzen",
		12369,
		101,
		870,
		"Bodger",
		"",
		364,
		282
	},

	{
		"lighthalzen",
		12370,
		101,
		870,
		"Grinnel",
		"",
		326,
		249
	},

	{
		"lighthalzen",
		12371,
		101,
		870,
		"Shengwen",
		"",
		306,
		324
	},

	{
		"lighthalzen",
		12373,
		101,
		847,
		"Wallace",
		"",
		202,
		94
	},

	{
		"lighthalzen",
		12374,
		101,
		847,
		"Mauro",
		"",
		138,
		50
	},

	{
		"lighthalzen",
		12375,
		101,
		869,
		"Victor Perfecto",
		"",
		77,
		203
	},

	{
		"lighthalzen",
		12377,
		101,
		866,
		"Srinivas",
		"",
		258,
		223
	},

	{
		"lighthalzen",
		12378,
		101,
		92,
		"Sergei",
		"",
		192,
		63
	},

	{
		"lighthalzen",
		12379,
		101,
		700,
		"Merpi",
		"",
		123,
		212
	},

	{
		"lighthalzen",
		12380,
		101,
		866,
		"Klaubis",
		"",
		230,
		182
	},

	{
		"lighthalzen",
		12381,
		101,
		869,
		"Vergil",
		"",
		40,
		107
	},

	{
		"lighthalzen",
		12382,
		101,
		866,
		"Lucius",
		"",
		182,
		102
	},

	{
		"lighthalzen",
		12385,
		101,
		79,
		"Nun",
		"",
		330,
		276
	},

	{
		"lighthalzen",
		12388,
		101,
		863,
		"Janice",
		"05",
		45,
		59
	},

	{
		"lighthalzen",
		12396,
		101,
		706,
		"Berru",
		"lhz_01",
		296,
		239
	},

	{
		"lighthalzen",
		12397,
		101,
		818,
		"Pilia",
		"lhz_01",
		297,
		239
	},

	{
		"lighthalzen",
		12398,
		101,
		870,
		"Reuben",
		"lhz_02",
		311,
		194
	},

	{
		"lighthalzen",
		12399,
		101,
		777,
		"Beggar",
		"lhz_02",
		312,
		233
	},

	{
		"lighthalzen",
		12400,
		101,
		870,
		"Suspicious Guy",
		"lhz_01",
		240,
		216
	},

	{
		"lighthalzen",
		12401,
		101,
		870,
		"Suspicious Guy",
		"lhz_02",
		220,
		169
	},

	{
		"lighthalzen",
		12402,
		101,
		870,
		"Suspicious Guy",
		"lhz_03",
		164,
		127
	},

	{
		"lighthalzen",
		12411,
		101,
		716,
		"Sung",
		"",
		233,
		82
	},

	{
		"lighthalzen",
		12412,
		101,
		97,
		"Kemp",
		"",
		125,
		68
	},

	{
		"lighthalzen",
		12413,
		101,
		862,
		"Ruth",
		"",
		261,
		112
	},

	{
		"lighthalzen",
		12414,
		101,
		869,
		"Oyoung",
		"",
		259,
		108
	},

	{
		"lighthalzen",
		12415,
		101,
		862,
		"Jiwon",
		"",
		198,
		285
	},

	{
		"lighthalzen",
		12416,
		101,
		854,
		"Sameer",
		"",
		89,
		73
	},

	{
		"lighthalzen",
		12437,
		101,
		846,
		"Elder",
		"li_tre",
		346,
		263
	},

	{
		"lighthalzen",
		12470,
		101,
		868,
		"Rekenber Employee",
		"li",
		337,
		296
	},

	{
		"lighthalzen",
		12475,
		101,
		866,
		"Villagomez",
		"li_01",
		77,
		157
	},

	{
		"lighthalzen",
		12476,
		101,
		734,
		"Sefith",
		"li_01",
		132,
		103
	},

	{
		"lighthalzen",
		12477,
		101,
		869,
		"Laqumet",
		"li_02",
		147,
		105
	},

	{
		"lighthalzen",
		12478,
		101,
		863,
		"Margie Keays",
		"li_02",
		65,
		94
	},

	{
		"lighthalzen",
		12479,
		101,
		866,
		"Elmer Keays",
		"li_03",
		66,
		94
	},

	{
		"lighthalzen",
		12480,
		101,
		72,
		"Kariya",
		"li_01",
		233,
		121
	},

	{
		"lighthalzen",
		12481,
		101,
		853,
		"Greedy Looking Man",
		"li_01",
		205,
		208
	},

	{
		"lighthalzen",
		12490,
		101,
		109,
		"Rekenber Employee",
		"li",
		159,
		222
	},

	{
		"lighthalzen",
		12491,
		101,
		868,
		"Rekenber Guard Drew",
		"li_kafra",
		162,
		304
	},

	{
		"lighthalzen",
		12492,
		101,
		867,
		"Rekenber Guard Tan",
		"li_kafra_1",
		163,
		306
	},

	{
		"lighthalzen",
		12493,
		101,
		102,
		"Delna",
		"li_reken",
		70,
		227
	},

	{
		"lighthalzen",
		12561,
		101,
		861,
		"Kafra Voting Staff",
		"lght",
		163,
		60
	},

	{
		"lighthalzen",
		12603,
		101,
		874,
		"Cool Event Staff",
		"lght",
		154,
		60
	},

	{
		"lighthalzen",
		12731,
		101,
		868,
		"Fishbone",
		"",
		341,
		224
	},

	{
		"lighthalzen",
		12752,
		101,
		85,
		"Old Man",
		"",
		141,
		162
	},

	{
		"lighthalzen",
		12757,
		101,
		904,
		"���ڸ� ���Ѷ��",
		"kiup2",
		303,
		303
	},

	{
		"lighthalzen",
		12775,
		101,
		847,
		"������ ����",
		"��4����",
		342,
		291
	},

	{
		"lighthalzen",
		12914,
		101,
		85,
		"Dono",
		"",
		88,
		79
	},

	{
		"lighthalzen",
		14079,
		101,
		899,
		"Guide",
		"",
		220,
		292
	},

	{
		"lighthalzen",
		15106,
		101,
		553,
		"������",
		"����",
		254,
		83
	},

	{
		"lighthalzen",
		15482,
		101,
		860,
		"Kafra Employee",
		"",
		164,
		100
	},

	{
		"lighthalzen",
		15483,
		101,
		861,
		"Kafra Employee",
		"",
		191,
		320
	},

	{
		"lighthalzen",
		15485,
		101,
		874,
		"���� ��ȹ�� ����",
		"",
		94,
		248
	},

	{
		"lighthalzen",
		15597,
		102,
		90,
		"���Ĵ� �ҳ�",
		"",
		112,
		44
	},

	{
		"lighthalzen",
		15598,
		102,
		90,
		"��������",
		"",
		220,
		122
	},

	{
		"lighthalzen",
		15599,
		102,
		102,
		"���ϻ���",
		"",
		69,
		75
	},

	{
		"lighthalzen",
		15600,
		102,
		91,
		"��ä����",
		"",
		124,
		129
	},

	{
		"lighthalzen",
		15601,
		102,
		125,
		"���ֻ̹���",
		"",
		222,
		191
	},

	{
		"lighthalzen",
		15634,
		102,
		83,
		"�丮������",
		"",
		126,
		126
	},

	{
		"lighthalzen",
		15664,
		102,
		66,
		"Ʈ��������",
		"",
		337,
		240
	},

	{
		"lighthalzen",
		15719,
		101,
		706,
		"Kid",
		"����",
		360,
		313
	},

	{
		"lighthalzen",
		15722,
		101,
		47,
		"Strange Guy",
		"",
		143,
		68
	},

	{
		"lighthalzen",
		15723,
		101,
		91,
		"Relaxed-Looking Lady",
		"",
		182,
		89
	},

	{
		"lighthalzen",
		15823,
		101,
		852,
		"Lighthalzen Guide",
		"lighthalzen01",
		207,
		310
	},

	{
		"lighthalzen",
		15824,
		101,
		852,
		"Lighthalzen Guide",
		"lighthalzen02",
		220,
		310
	},

	{
		"lighthalzen",
		15825,
		101,
		852,
		"Lighthalzen Guide",
		"lighthalzen03",
		154,
		100
	},

	{
		"lighthalzen",
		15826,
		101,
		852,
		"Lighthalzen Guide",
		"lighthalzen04",
		307,
		224
	},

	{
		"lighthalzen",
		15827,
		101,
		852,
		"����Ÿ���� �ȳ����",
		"lighthalzen05",
		247,
		82
	},

	{
		"lighthalzen",
		17802,
		101,
		728,
		"Maroll Battle Recruiter",
		"",
		153,
		86
	},

	{
		"lighthalzen",
		18546,
		101,
		734,
		"Krongast",
		"BLS",
		209,
		80
	},

	{
		"lighthalzen",
		18748,
		101,
		86,
		"��",
		"gungun",
		322,
		247
	},

	{
		"lighthalzen",
		18749,
		101,
		85,
		"F. Harrison",
		"gun",
		205,
		284
	},

	{
		"lighthalzen",
		18871,
		101,
		891,
		"����",
		"job_min",
		162,
		126
	},

	{
		"lighthalzen",
		18872,
		101,
		486,
		"Karian",
		"cmd3",
		160,
		124
	},

	{
		"lighthalzen",
		19104,
		101,
		86,
		"Nannan",
		"",
		226,
		210
	},

	{
		"lighthalzen",
		19228,
		101,
		86,
		"Leablem",
		"",
		96,
		137
	},

	{
		"lighthalzen",
		19375,
		101,
		46,
		"Windmill Owner",
		"kh",
		366,
		299
	},

	{
		"lighthalzen",
		19376,
		101,
		97,
		"Windmill Owner's Helper",
		"kh",
		366,
		289
	},

	{
		"lighthalzen",
		19585,
		101,
		729,
		"������ �����̵���",
		"21",
		164,
		86
	},

	{
		"lou_fild01",
		11717,
		101,
		819,
		"Jiu Lian Bu",
		"1-1",
		195,
		177
	},

	{
		"lou_fild01",
		11720,
		101,
		819,
		"Jiu Lian Bu",
		"1-2",
		175,
		173
	},

	{
		"lou_fild01",
		11745,
		101,
		817,
		"Lady",
		"��������޿�",
		224,
		348
	},

	{
		"lou_fild01",
		18425,
		101,
		815,
		"Girl",
		"1",
		190,
		100
	},

	{
		"lou_in01",
		11730,
		101,
		750,
		"Gunpowder Expert",
		"",
		43,
		147
	},

	{
		"lou_in01",
		11731,
		101,
		825,
		"Soldier",
		"ȭ��˻�",
		45,
		138
	},

	{
		"lou_in01",
		11732,
		101,
		825,
		"Soldier",
		"���˻�",
		82,
		139
	},

	{
		"lou_in01",
		11751,
		101,
		821,
		"Lord",
		"���̷�",
		99,
		158
	},

	{
		"lou_in01",
		11752,
		101,
		825,
		"Soldier",
		"���̷�1",
		111,
		151
	},

	{
		"lou_in01",
		11753,
		101,
		825,
		"Soldier",
		"���̷�2",
		91,
		151
	},

	{
		"lou_in01",
		11754,
		101,
		825,
		"Soldier",
		"���̷�3",
		102,
		144
	},

	{
		"lou_in01",
		11755,
		101,
		825,
		"Soldier",
		"���̷�4",
		99,
		144
	},

	{
		"lou_in01",
		11756,
		101,
		817,
		"Friendly Looking Lady",
		"",
		25,
		23
	},

	{
		"lou_in02",
		11713,
		101,
		822,
		"Employee",
		"1",
		53,
		174
	},

	{
		"lou_in02",
		11714,
		101,
		822,
		"Employee",
		"2",
		76,
		181
	},

	{
		"lou_in02",
		11715,
		101,
		818,
		"Employee",
		"3",
		61,
		175
	},

	{
		"lou_in02",
		11716,
		101,
		820,
		"Chef",
		"1-2",
		62,
		183
	},

	{
		"lou_in02",
		11723,
		101,
		823,
		"Chef Assistant",
		"",
		58,
		183
	},

	{
		"lou_in02",
		11724,
		101,
		746,
		"Li Min",
		"",
		80,
		173
	},

	{
		"lou_in02",
		11725,
		101,
		816,
		"Liu Jia Lim",
		"",
		42,
		186
	},

	{
		"lou_in02",
		11726,
		101,
		827,
		"Jiang Rong",
		"",
		43,
		169
	},

	{
		"lou_in02",
		11729,
		101,
		824,
		"Hermit",
		"",
		77,
		37
	},

	{
		"lou_in02",
		11733,
		101,
		814,
		"Doctor",
		"",
		265,
		69
	},

	{
		"lou_in02",
		11734,
		101,
		798,
		"Familiar-Looking Patient",
		"",
		272,
		55
	},

	{
		"lou_in02",
		11735,
		101,
		824,
		"Tool Shop Master",
		"",
		248,
		166
	},

	{
		"lou_in02",
		11736,
		101,
		819,
		"Storage Keeper",
		"",
		201,
		166
	},

	{
		"lou_in02",
		11737,
		101,
		825,
		"City Hall Officer",
		"",
		210,
		47
	},

	{
		"lou_in02",
		11738,
		101,
		822,
		"Studying Officer",
		"",
		156,
		38
	},

	{
		"lou_in02",
		11743,
		101,
		824,
		"Poison King",
		"",
		123,
		39
	},

	{
		"lou_in02",
		11744,
		101,
		822,
		"Employee",
		"������",
		253,
		45
	},

	{
		"lou_in02",
		15586,
		102,
		818,
		"��������",
		"",
		239,
		176
	},

	{
		"lou_in02",
		15587,
		102,
		818,
		"������",
		"",
		121,
		182
	},

	{
		"lou_in02",
		15588,
		102,
		822,
		"�������",
		"",
		130,
		182
	},

	{
		"louyang",
		10049,
		101,
		109,
		"���������",
		"",
		210,
		107
	},

	{
		"louyang",
		11698,
		101,
		815,
		"Muscular Woman",
		"",
		297,
		167
	},

	{
		"louyang",
		11699,
		101,
		819,
		"Powerful-looking guy",
		"",
		274,
		136
	},

	{
		"louyang",
		11700,
		101,
		819,
		"Fist master",
		"",
		276,
		136
	},

	{
		"louyang",
		11701,
		101,
		819,
		"Trainee",
		"1",
		276,
		133
	},

	{
		"louyang",
		11702,
		101,
		819,
		"Trainee",
		"2",
		276,
		131
	},

	{
		"louyang",
		11703,
		101,
		819,
		"Trainee",
		"3",
		276,
		129
	},

	{
		"louyang",
		11704,
		101,
		819,
		"Trainee",
		"4",
		274,
		133
	},

	{
		"louyang",
		11705,
		101,
		819,
		"Trainee",
		"5",
		274,
		131
	},

	{
		"louyang",
		11706,
		101,
		819,
		"Trainee",
		"6",
		274,
		129
	},

	{
		"louyang",
		11707,
		101,
		819,
		"Trainee",
		"7",
		278,
		133
	},

	{
		"louyang",
		11708,
		101,
		819,
		"Trainee",
		"8",
		278,
		131
	},

	{
		"louyang",
		11709,
		101,
		819,
		"Trainee",
		"9",
		278,
		129
	},

	{
		"louyang",
		11710,
		101,
		819,
		"Trainee",
		"10",
		272,
		133
	},

	{
		"louyang",
		11711,
		101,
		819,
		"Trainee",
		"11",
		272,
		131
	},

	{
		"louyang",
		11712,
		101,
		819,
		"Trainee",
		"12",
		272,
		129
	},

	{
		"louyang",
		11727,
		101,
		824,
		"Chi Wu Ping",
		"",
		261,
		123
	},

	{
		"louyang",
		11728,
		101,
		815,
		"Jiu Chi Ling",
		"",
		174,
		150
	},

	{
		"louyang",
		15476,
		101,
		116,
		"ī���� ����",
		"",
		210,
		104
	},

	{
		"louyang",
		15636,
		102,
		820,
		"�丮������",
		"",
		256,
		123
	},

	{
		"louyang",
		15845,
		101,
		818,
		"Louyang Guide",
		"01louyang",
		224,
		104
	},

	{
		"louyang",
		19549,
		101,
		837,
		"�ָ�",
		"������",
		37,
		276
	},

	{
		"louyang",
		19591,
		101,
		729,
		"������ �����̵���",
		"24",
		224,
		107
	},

	{
		"ma_dun01",
		13906,
		101,
		569,
		"��ȣ��",
		"ma_n2",
		35,
		108
	},

	{
		"ma_dun01",
		13920,
		101,
		858,
		"������ ���� ����",
		"ma_d1",
		152,
		23
	},

	{
		"ma_dun01",
		14066,
		101,
		569,
		"��ȣ��",
		"ma_dun01",
		147,
		10
	},

	{
		"ma_fild01",
		13882,
		101,
		582,
		"����� ���ֹ�",
		"bako2",
		165,
		237
	},

	{
		"ma_fild01",
		13893,
		101,
		582,
		"���Ҷ��� �ϲ�",
		"bako2",
		54,
		253
	},

	{
		"ma_fild01",
		13894,
		101,
		577,
		"�Ҹ����� �ϲ�",
		"bako2",
		236,
		119
	},

	{
		"ma_fild01",
		13955,
		101,
		577,
		"�佺Ƽ�� �غ�ҳ�",
		"pin",
		179,
		260
	},

	{
		"ma_fild01",
		13956,
		101,
		574,
		"Ÿ���̽�Ʈ",
		"pin",
		172,
		223
	},

	{
		"ma_fild01",
		13957,
		101,
		58,
		"������",
		"pin01",
		192,
		200
	},

	{
		"ma_fild01",
		13958,
		101,
		775,
		"������",
		"pin02",
		211,
		200
	},

	{
		"ma_fild01",
		13959,
		101,
		824,
		"������",
		"pin03",
		251,
		205
	},

	{
		"ma_fild01",
		13960,
		101,
		582,
		"���� Ÿ���̽�Ʈ",
		"pin04",
		249,
		206
	},

	{
		"ma_fild01",
		13961,
		101,
		815,
		"������",
		"pin05",
		162,
		235
	},

	{
		"ma_fild01",
		13962,
		101,
		578,
		"��ġ�� û��",
		"pin06",
		164,
		234
	},

	{
		"ma_fild01",
		13963,
		101,
		578,
		"��ġ�� û��",
		"pin07",
		170,
		231
	},

	{
		"ma_fild01",
		13964,
		101,
		578,
		"��ġ�� û��",
		"pin08",
		164,
		228
	},

	{
		"ma_fild01",
		13965,
		101,
		577,
		"���� ���ߴ� �ҳ�",
		"pin09",
		170,
		234
	},

	{
		"ma_fild01",
		13966,
		101,
		577,
		"���� ���ߴ� �ҳ�",
		"pin10",
		164,
		231
	},

	{
		"ma_fild01",
		13967,
		101,
		577,
		"���� ���ߴ� �ҳ�",
		"pin11",
		170,
		228
	},

	{
		"ma_fild01",
		14000,
		101,
		575,
		"�����ϴ� ����",
		"�����",
		166,
		214
	},

	{
		"ma_fild01",
		14001,
		101,
		582,
		"ƽ���� ������",
		"malaya",
		238,
		198
	},

	{
		"ma_fild01",
		14002,
		101,
		572,
		"������ü",
		"01",
		74,
		367
	},

	{
		"ma_fild01",
		14003,
		101,
		572,
		"������ü",
		"02",
		109,
		116
	},

	{
		"ma_fild01",
		14004,
		101,
		572,
		"������ü",
		"03",
		280,
		150
	},

	{
		"ma_fild01",
		14005,
		101,
		572,
		"������ü",
		"04",
		309,
		221
	},

	{
		"ma_fild01",
		14055,
		101,
		580,
		"����Ű Ű��",
		"mal",
		261,
		208
	},

	{
		"ma_fild01",
		14056,
		101,
		570,
		"����� ��",
		"mal",
		239,
		253
	},

	{
		"ma_fild01",
		14057,
		101,
		972,
		"���� ��Ÿ��",
		"mal",
		238,
		257
	},

	{
		"ma_fild01",
		14058,
		101,
		579,
		"������",
		"mal01",
		200,
		190
	},

	{
		"ma_fild01",
		14059,
		101,
		576,
		"���ھ���",
		"mal01",
		203,
		189
	},

	{
		"ma_fild01",
		14060,
		101,
		576,
		"�� ���� ����",
		"mal01",
		251,
		93
	},

	{
		"ma_fild01",
		14061,
		101,
		576,
		"�� ���� ����",
		"mal02",
		114,
		141
	},

	{
		"ma_fild01",
		14062,
		101,
		576,
		"�� ���� ����",
		"mal03",
		130,
		314
	},

	{
		"ma_fild01",
		14064,
		101,
		582,
		"���� ��������",
		"malaya",
		158,
		243
	},

	{
		"ma_fild02",
		13874,
		101,
		570,
		"���",
		"",
		312,
		317
	},

	{
		"ma_fild02",
		13881,
		101,
		578,
		"����� ���ֹ�",
		"bako1",
		40,
		240
	},

	{
		"ma_fild02",
		13945,
		101,
		557,
		"������ ����",
		"buwaya_1",
		155,
		235
	},

	{
		"ma_fild02",
		13946,
		101,
		557,
		"������ ����",
		"buwaya_2",
		143,
		142
	},

	{
		"ma_fild02",
		13947,
		101,
		557,
		"������ ����",
		"buwaya_3",
		266,
		155
	},

	{
		"ma_fild02",
		13948,
		101,
		557,
		"������ ����",
		"buwaya_4",
		221,
		91
	},

	{
		"ma_fild02",
		13949,
		101,
		557,
		"������ ����",
		"buwaya_5",
		205,
		85
	},

	{
		"ma_fild02",
		13950,
		101,
		557,
		"������ ����",
		"buwaya_6",
		300,
		98
	},

	{
		"ma_fild02",
		13951,
		101,
		557,
		"������ ����",
		"buwaya_7",
		100,
		275
	},

	{
		"ma_fild02",
		13953,
		101,
		81,
		"��",
		"buwaya",
		312,
		259
	},

	{
		"ma_fild02",
		13954,
		101,
		570,
		"�����",
		"buwayacave",
		308,
		262
	},

	{
		"ma_fild02",
		14006,
		101,
		572,
		"������ü",
		"05",
		282,
		41
	},

	{
		"ma_fild02",
		14007,
		101,
		572,
		"������ü",
		"06",
		246,
		324
	},

	{
		"ma_fild02",
		14008,
		101,
		572,
		"������ü",
		"07",
		71,
		296
	},

	{
		"ma_fild02",
		14009,
		101,
		572,
		"������ü",
		"08",
		32,
		263
	},

	{
		"ma_fild02",
		14063,
		101,
		572,
		"������ ī���� �ε���",
		"",
		241,
		39
	},

	{
		"ma_in01",
		13941,
		101,
		577,
		"������",
		"buwaya",
		47,
		101
	},

	{
		"ma_in01",
		13942,
		101,
		81,
		"��",
		"buwaya_totoi",
		43,
		101
	},

	{
		"ma_in01",
		13999,
		101,
		583,
		"��������",
		"ma",
		30,
		94
	},

	{
		"ma_in01",
		14054,
		101,
		1752,
		"��ȥ ���Ÿ",
		"mal",
		125,
		107
	},

	{
		"ma_in01",
		15686,
		102,
		536,
		"���� ����",
		"ma",
		73,
		22
	},

	{
		"ma_in01",
		15687,
		102,
		536,
		"���� ����",
		"ma",
		22,
		23
	},

	{
		"ma_in01",
		15689,
		102,
		536,
		"�� ����",
		"ma",
		67,
		13
	},

	{
		"ma_scene01",
		13895,
		101,
		578,
		"������ �ϲ�",
		"bako2",
		177,
		89
	},

	{
		"ma_scene01",
		13896,
		101,
		582,
		"����� �ϲ�",
		"bako2",
		141,
		118
	},

	{
		"ma_scene01",
		13897,
		101,
		578,
		"��ź���� �ϲ�",
		"bako2",
		175,
		170
	},

	{
		"ma_scene01",
		14010,
		101,
		572,
		"������ü",
		"09",
		195,
		92
	},

	{
		"ma_scene01",
		14011,
		101,
		572,
		"������ü",
		"10",
		158,
		139
	},

	{
		"ma_scene01",
		14012,
		101,
		572,
		"������ü",
		"11",
		167,
		112
	},

	{
		"ma_scene01",
		14065,
		101,
		541,
		"��ȣ",
		"",
		174,
		179
	},

	{
		"mal_dun01",
		15013,
		101,
		549,
		"������� ������",
		"mald",
		136,
		120
	},

	{
		"mal_dun01",
		15014,
		101,
		551,
		"�ǻ�",
		"mal",
		136,
		122
	},

	{
		"mal_dun01",
		15016,
		101,
		552,
		"������",
		"mal",
		133,
		125
	},

	{
		"mal_dun01",
		15177,
		101,
		551,
		"�Ұ��縮",
		"",
		151,
		235
	},

	{
		"mal_in01",
		15001,
		101,
		547,
		"��ĭ",
		"mal",
		114,
		169
	},

	{
		"mal_in01",
		15002,
		101,
		563,
		"������ ���",
		"mal",
		116,
		168
	},

	{
		"mal_in01",
		15044,
		101,
		549,
		"���� ������",
		"gamer",
		31,
		210
	},

	{
		"mal_in01",
		15050,
		101,
		544,
		"����",
		"gamer",
		91,
		216
	},

	{
		"mal_in01",
		15051,
		101,
		544,
		"�ľ�",
		"gamer",
		86,
		222
	},

	{
		"mal_in01",
		15052,
		101,
		422,
		"��ī",
		"gamer",
		91,
		222
	},

	{
		"mal_in01",
		15053,
		101,
		422,
		"���",
		"gamer",
		134,
		221
	},

	{
		"mal_in01",
		15054,
		101,
		546,
		"�Ŵ���",
		"gamer",
		133,
		214
	},

	{
		"mal_in01",
		15055,
		101,
		553,
		"��ġ",
		"gamer",
		136,
		216
	},

	{
		"mal_in01",
		15056,
		101,
		559,
		"�ο�",
		"gamer",
		136,
		215
	},

	{
		"mal_in01",
		15057,
		101,
		876,
		"���",
		"gamer",
		136,
		214
	},

	{
		"mal_in01",
		15058,
		101,
		421,
		"����",
		"gamer",
		136,
		213
	},

	{
		"mal_in01",
		15059,
		101,
		554,
		"���",
		"gamer",
		136,
		212
	},

	{
		"mal_in01",
		15061,
		101,
		858,
		"�ָ�",
		"��G1��",
		15,
		221
	},

	{
		"mal_in01",
		15062,
		101,
		858,
		"�ָ�",
		"��G����1��",
		77,
		214
	},

	{
		"mal_in01",
		15063,
		101,
		858,
		"�ָ�",
		"��G����2��",
		142,
		220
	},

	{
		"mal_in01",
		15064,
		101,
		890,
		"����",
		"gamer",
		155,
		222
	},

	{
		"mal_in01",
		15065,
		101,
		560,
		"������",
		"gamer",
		30,
		222
	},

	{
		"mal_in01",
		15066,
		101,
		555,
		"��⹦",
		"gamer",
		19,
		213
	},

	{
		"mal_in01",
		15081,
		101,
		561,
		"�˺�",
		"pa0829",
		172,
		28
	},

	{
		"mal_in01",
		15082,
		101,
		544,
		"����ī",
		"pa0829",
		172,
		26
	},

	{
		"mal_in01",
		15178,
		101,
		545,
		"û�Һ� �̽�",
		"",
		160,
		34
	},

	{
		"mal_in02",
		14970,
		101,
		505,
		"���ڻ���",
		"����",
		134,
		31
	},

	{
		"mal_in02",
		14972,
		101,
		495,
		"������",
		"mal",
		28,
		56
	},

	{
		"mal_in02",
		14973,
		101,
		556,
		"�丶��",
		"mal",
		22,
		62
	},

	{
		"mal_in02",
		14974,
		101,
		421,
		"��ȸ ����",
		"mal",
		182,
		61
	},

	{
		"mal_in02",
		14975,
		101,
		422,
		"��������",
		"mal",
		178,
		66
	},

	{
		"mal_in02",
		14976,
		101,
		546,
		"��",
		"mal",
		177,
		58
	},

	{
		"mal_in02",
		14977,
		101,
		549,
		"������� ������",
		"mal",
		174,
		64
	},

	{
		"mal_in02",
		14978,
		101,
		559,
		"�������� ����",
		"mal",
		179,
		57
	},

	{
		"mal_in02",
		14979,
		101,
		553,
		"��",
		"mal",
		140,
		94
	},

	{
		"mal_in02",
		15000,
		101,
		545,
		"�긮",
		"mal",
		181,
		55
	},

	{
		"mal_in02",
		15015,
		101,
		544,
		"û�ҿ�ǰ���",
		"mal",
		102,
		94
	},

	{
		"mal_in02",
		15030,
		101,
		495,
		"�ٳ�",
		"mal",
		1,
		1
	},

	{
		"mal_in02",
		15041,
		101,
		547,
		"������",
		"ml",
		184,
		72
	},

	{
		"mal_in02",
		15074,
		101,
		555,
		"������� ����",
		"nyaong01",
		166,
		74
	},

	{
		"mal_in02",
		15075,
		101,
		561,
		"������ ����",
		"nyaong02",
		132,
		95
	},

	{
		"mal_in02",
		15076,
		101,
		545,
		"��ĥ�� ����",
		"nyaong03",
		109,
		62
	},

	{
		"mal_in02",
		15173,
		101,
		548,
		"������ �Ľ�",
		"malqook01",
		187,
		58
	},

	{
		"mal_in02",
		15174,
		101,
		544,
		"Ŭ����",
		"malqook02",
		76,
		63
	},

	{
		"malangdo",
		10053,
		101,
		109,
		"���������",
		"",
		178,
		139
	},

	{
		"malangdo",
		10065,
		101,
		559,
		"�Ż� ������ �Ź�",
		"evt",
		156,
		210
	},

	{
		"malangdo",
		10066,
		101,
		563,
		"�ձ��Ҽ����Ǳ�",
		"",
		234,
		187
	},

	{
		"malangdo",
		10067,
		101,
		551,
		"������",
		"kingscoin",
		235,
		186
	},

	{
		"malangdo",
		10161,
		101,
		735,
		"�ϰŷ���",
		"pa0829",
		204,
		148
	},

	{
		"malangdo",
		14971,
		101,
		560,
		"â������",
		"â��",
		184,
		139
	},

	{
		"malangdo",
		14980,
		101,
		550,
		"�տ�",
		"mal1",
		114,
		157
	},

	{
		"malangdo",
		14982,
		101,
		550,
		"�տ�",
		"mal2",
		284,
		237
	},

	{
		"malangdo",
		14984,
		101,
		550,
		"�տ�",
		"mal3",
		134,
		150
	},

	{
		"malangdo",
		14986,
		101,
		550,
		"�տ�",
		"mal4",
		173,
		199
	},

	{
		"malangdo",
		14988,
		101,
		550,
		"�տ�",
		"mal5",
		233,
		197
	},

	{
		"malangdo",
		14990,
		101,
		550,
		"�տ�",
		"mal6",
		137,
		239
	},

	{
		"malangdo",
		14992,
		101,
		550,
		"�տ�",
		"mal7",
		239,
		157
	},

	{
		"malangdo",
		14994,
		101,
		550,
		"�տ�",
		"mal8",
		221,
		155
	},

	{
		"malangdo",
		14996,
		101,
		550,
		"�տ�",
		"mal9",
		217,
		109
	},

	{
		"malangdo",
		14998,
		101,
		550,
		"�տ�",
		"mal10",
		162,
		183
	},

	{
		"malangdo",
		15003,
		101,
		557,
		"������ �𷡴���",
		"mal1",
		221,
		139
	},

	{
		"malangdo",
		15004,
		101,
		557,
		"������ �𷡴���",
		"mal2",
		208,
		174
	},

	{
		"malangdo",
		15005,
		101,
		557,
		"������ �𷡴���",
		"mal3",
		191,
		223
	},

	{
		"malangdo",
		15006,
		101,
		557,
		"������ �𷡴���",
		"mal4",
		150,
		195
	},

	{
		"malangdo",
		15007,
		101,
		557,
		"������ �𷡴���",
		"mal5",
		116,
		196
	},

	{
		"malangdo",
		15008,
		101,
		557,
		"������ �𷡴���",
		"mal6",
		178,
		145
	},

	{
		"malangdo",
		15009,
		101,
		557,
		"������ �𷡴���",
		"mal7",
		142,
		120
	},

	{
		"malangdo",
		15010,
		101,
		557,
		"������ �𷡴���",
		"mal8",
		136,
		122
	},

	{
		"malangdo",
		15011,
		101,
		557,
		"������ �𷡴���",
		"mal9",
		152,
		143
	},

	{
		"malangdo",
		15012,
		101,
		557,
		"������ �𷡴���",
		"mal10",
		242,
		175
	},

	{
		"malangdo",
		15017,
		101,
		546,
		"��Ÿ��",
		"mal",
		190,
		167
	},

	{
		"malangdo",
		15031,
		101,
		561,
		"������",
		"ml",
		175,
		206
	},

	{
		"malangdo",
		15032,
		101,
		547,
		"������",
		"ml1",
		181,
		205
	},

	{
		"malangdo",
		15033,
		101,
		547,
		"������",
		"ml1",
		180,
		202
	},

	{
		"malangdo",
		15034,
		101,
		547,
		"������",
		"ml1",
		186,
		201
	},

	{
		"malangdo",
		15035,
		101,
		547,
		"������",
		"ml2",
		177,
		202
	},

	{
		"malangdo",
		15036,
		101,
		547,
		"������",
		"ml3",
		183,
		202
	},

	{
		"malangdo",
		15037,
		101,
		543,
		"������ ����",
		"ml",
		203,
		116
	},

	{
		"malangdo",
		15038,
		101,
		543,
		"�ſ� ������ ����",
		"ml1",
		205,
		116
	},

	{
		"malangdo",
		15039,
		101,
		546,
		"���ڶ� ������",
		"ml",
		197,
		120
	},

	{
		"malangdo",
		15040,
		101,
		543,
		"������ ������ ����",
		"ml2",
		171,
		163
	},

	{
		"malangdo",
		15042,
		101,
		545,
		"�������",
		"ml",
		125,
		147
	},

	{
		"malangdo",
		15043,
		101,
		545,
		"������",
		"ml",
		129,
		146
	},

	{
		"malangdo",
		15045,
		101,
		547,
		"�̻��� ������",
		"gamer",
		127,
		111
	},

	{
		"malangdo",
		15046,
		101,
		876,
		"�̷�",
		"gamer",
		161,
		197
	},

	{
		"malangdo",
		15047,
		101,
		555,
		"��Ʃ",
		"gamer",
		230,
		197
	},

	{
		"malangdo",
		15048,
		101,
		546,
		"����",
		"gamer",
		244,
		144
	},

	{
		"malangdo",
		15049,
		101,
		560,
		"����",
		"gamer",
		181,
		119
	},

	{
		"malangdo",
		15060,
		101,
		858,
		"�ָ�",
		"��G�Ա�",
		120,
		140
	},

	{
		"malangdo",
		15067,
		101,
		561,
		"���׶� ������",
		"nya_01",
		165,
		223
	},

	{
		"malangdo",
		15068,
		101,
		560,
		"[�߿˴�] ����",
		"nya_11",
		211,
		203
	},

	{
		"malangdo",
		15069,
		101,
		559,
		"[�߿˴�] �ν�",
		"nya_09",
		214,
		204
	},

	{
		"malangdo",
		15070,
		101,
		553,
		"[�߿˴�] ����",
		"nya_10",
		215,
		201
	},

	{
		"malangdo",
		15071,
		101,
		544,
		"���ǿ� �κ�",
		"nya_16",
		176,
		165
	},

	{
		"malangdo",
		15072,
		101,
		560,
		"��Ž�� ������",
		"nya_14",
		172,
		178
	},

	{
		"malangdo",
		15073,
		101,
		559,
		"��Ž���� ģ��",
		"nya_15",
		173,
		177
	},

	{
		"malangdo",
		15077,
		101,
		555,
		"���丶��",
		"pa0829",
		213,
		167
	},

	{
		"malangdo",
		15078,
		101,
		553,
		"������",
		"pa0829",
		215,
		166
	},

	{
		"malangdo",
		15079,
		101,
		564,
		"����ȯ����CX-1",
		"pa0829",
		220,
		167
	},

	{
		"malangdo",
		15080,
		101,
		562,
		"Ư�깰���Ǳ�CX-82",
		"pa0829",
		218,
		165
	},

	{
		"malangdo",
		15083,
		101,
		495,
		"������ ����",
		"",
		162,
		146
	},

	{
		"malangdo",
		15084,
		101,
		496,
		"�������� ����",
		"",
		173,
		145
	},

	{
		"malangdo",
		15085,
		101,
		495,
		"��� ����",
		"",
		150,
		135
	},

	{
		"malangdo",
		15086,
		101,
		554,
		"���� ����",
		"malang",
		147,
		117
	},

	{
		"malangdo",
		15088,
		101,
		479,
		"�����ϴ� �ν�Ʈ��",
		"����",
		151,
		120
	},

	{
		"malangdo",
		15089,
		101,
		485,
		"�����ϴ� ������",
		"����",
		149,
		120
	},

	{
		"malangdo",
		15090,
		101,
		558,
		"������ ���û�",
		"malang",
		216,
		168
	},

	{
		"malangdo",
		15091,
		101,
		853,
		"������ ���û�",
		"malang1",
		164,
		203
	},

	{
		"malangdo",
		15120,
		101,
		545,
		"��",
		"��������",
		219,
		86
	},

	{
		"malangdo",
		15171,
		101,
		544,
		"¸�׶�",
		"�����Ϲ�",
		224,
		172
	},

	{
		"malangdo",
		15172,
		101,
		559,
		"Ȧ���",
		"����ĳ��",
		221,
		174
	},

	{
		"malangdo",
		15175,
		101,
		557,
		"������ �𷡴���",
		"malq07",
		133,
		134
	},

	{
		"malangdo",
		15176,
		101,
		557,
		"������ �𷡴���",
		"malq12",
		197,
		237
	},

	{
		"malangdo",
		15179,
		101,
		549,
		"������ ������ ���",
		"",
		175,
		145
	},

	{
		"malangdo",
		15180,
		101,
		554,
		"����� ȯ����",
		"",
		232,
		171
	},

	{
		"malangdo",
		15181,
		101,
		559,
		"��ó��",
		"pa0829",
		208,
		166
	},

	{
		"malangdo",
		15685,
		102,
		560,
		"������",
		"������",
		232,
		163
	},

	{
		"malangdo",
		15754,
		101,
		700,
		"����Ʈ ����",
		"������",
		214,
		163
	},

	{
		"malangdo",
		15856,
		101,
		546,
		"������ �ȳ����",
		"malangdo",
		218,
		101
	},

	{
		"malangdo",
		18066,
		101,
		564,
		"����Ƽ�����Ǳ�",
		"������",
		215,
		119
	},

	{
		"malangdo",
		18067,
		101,
		857,
		"������ �� ��� ������",
		"������",
		218,
		126
	},

	{
		"malangdo",
		18068,
		101,
		545,
		"����� ���̽�",
		"������",
		218,
		123
	},

	{
		"malangdo",
		19536,
		101,
		837,
		"�ָ�",
		"������",
		77,
		238
	},

	{
		"malaya",
		10062,
		101,
		109,
		"���������",
		"",
		234,
		218
	},

	{
		"malaya",
		13875,
		101,
		578,
		"�뷡�ϴ� ����",
		"bako1",
		280,
		331
	},

	{
		"malaya",
		13876,
		101,
		579,
		"�뷡�ϴ� ����",
		"bako1",
		275,
		333
	},

	{
		"malaya",
		13877,
		101,
		577,
		"�̿� ���� �ҳ�",
		"bako1",
		290,
		329
	},

	{
		"malaya",
		13878,
		101,
		576,
		"�̿� ���� ó��",
		"bako1",
		264,
		338
	},

	{
		"malaya",
		13879,
		101,
		575,
		"���� ������",
		"bako1",
		272,
		339
	},

	{
		"malaya",
		13884,
		101,
		578,
		"�ݺ��� ����",
		"bako2",
		286,
		269
	},

	{
		"malaya",
		13885,
		101,
		579,
		"ħ���� ����",
		"bako2",
		276,
		269
	},

	{
		"malaya",
		13886,
		101,
		577,
		"�ݺ��� �ҳ�",
		"bako2",
		276,
		262
	},

	{
		"malaya",
		13968,
		101,
		582,
		"������ ���",
		"01",
		237,
		240
	},

	{
		"malaya",
		13971,
		101,
		582,
		"������ ���",
		"02",
		67,
		44
	},

	{
		"malaya",
		13974,
		101,
		582,
		"������ ���",
		"03",
		282,
		129
	},

	{
		"malaya",
		13977,
		101,
		582,
		"������ ���",
		"04",
		134,
		250
	},

	{
		"malaya",
		13980,
		101,
		582,
		"������ ���",
		"05",
		341,
		153
	},

	{
		"malaya",
		13983,
		101,
		582,
		"������ ���",
		"06",
		293,
		290
	},

	{
		"malaya",
		13986,
		101,
		582,
		"������ ���",
		"07",
		242,
		221
	},

	{
		"malaya",
		13989,
		101,
		582,
		"������ ���",
		"08",
		62,
		245
	},

	{
		"malaya",
		13992,
		101,
		582,
		"������ ���",
		"09",
		257,
		58
	},

	{
		"malaya",
		14013,
		101,
		575,
		"�ҸӴ�",
		"ma01",
		227,
		311
	},

	{
		"malaya",
		14014,
		101,
		578,
		"���� ���� û��",
		"ma02",
		189,
		263
	},

	{
		"malaya",
		14015,
		101,
		570,
		"�ױ� �����",
		"ma03",
		270,
		59
	},

	{
		"malaya",
		14016,
		101,
		576,
		"�ҳ�",
		"ma04",
		88,
		252
	},

	{
		"malaya",
		14017,
		101,
		577,
		"����",
		"ma05",
		219,
		92
	},

	{
		"malaya",
		14018,
		101,
		582,
		"�ֹ�",
		"ma06",
		363,
		283
	},

	{
		"malaya",
		14019,
		101,
		574,
		"����",
		"ma07",
		41,
		127
	},

	{
		"malaya",
		14020,
		101,
		583,
		"����",
		"ma08",
		63,
		185
	},

	{
		"malaya",
		14043,
		101,
		475,
		"�̸��",
		"pm03",
		169,
		350
	},

	{
		"malaya",
		15494,
		101,
		581,
		"ī���� ����",
		"01",
		71,
		79
	},

	{
		"malaya",
		15495,
		101,
		581,
		"ī���� ����",
		"02",
		234,
		204
	},

	{
		"malaya",
		15688,
		102,
		535,
		"���ϻ���",
		"ma",
		150,
		261
	},

	{
		"malaya",
		15850,
		101,
		579,
		"��Ʈ ����� ���̵�",
		"01",
		71,
		72
	},

	{
		"malaya",
		15851,
		101,
		579,
		"��Ʈ ����� ���̵�",
		"02",
		250,
		83
	},

	{
		"malaya",
		15852,
		101,
		579,
		"��Ʈ ����� ���̵�",
		"03",
		224,
		204
	},

	{
		"malaya",
		19607,
		101,
		729,
		"������ �����̵���",
		"32",
		225,
		218
	},

	{
		"man_fild02",
		14511,
		101,
		421,
		"Cat Hand Agent",
		"03pa0829",
		132,
		47
	},

	{
		"man_fild02",
		15254,
		101,
		421,
		"������ �����̵��� 5ȣ",
		"",
		135,
		49
	},

	{
		"man_in01",
		14418,
		101,
		454,
		"Merchant of Manuk",
		"",
		286,
		16
	},

	{
		"man_in01",
		14607,
		101,
		450,
		"Manuk Guard",
		"1_edq",
		286,
		61
	},

	{
		"man_in01",
		14608,
		101,
		450,
		"Manuk Guard",
		"2_edq",
		295,
		61
	},

	{
		"man_in01",
		14609,
		101,
		437,
		"Laphine Prisoner",
		"edq",
		291,
		62
	},

	{
		"manuk",
		10059,
		101,
		109,
		"���������",
		"",
		296,
		147
	},

	{
		"manuk",
		10079,
		101,
		105,
		"������������",
		"����ũ",
		273,
		212
	},

	{
		"manuk",
		14374,
		101,
		454,
		"Piom",
		"",
		100,
		100
	},

	{
		"manuk",
		14375,
		101,
		449,
		"Benknee",
		"",
		188,
		216
	},

	{
		"manuk",
		14376,
		101,
		455,
		"Piom",
		"",
		169,
		260
	},

	{
		"manuk",
		14377,
		101,
		450,
		"Galtun",
		"",
		218,
		163
	},

	{
		"manuk",
		14378,
		101,
		450,
		"Galtun",
		"",
		266,
		199
	},

	{
		"manuk",
		14379,
		101,
		449,
		"Benknee",
		"",
		225,
		129
	},

	{
		"manuk",
		14380,
		101,
		454,
		"Piom",
		"",
		286,
		147
	},

	{
		"manuk",
		14381,
		101,
		454,
		"Piom",
		"",
		183,
		185
	},

	{
		"manuk",
		14382,
		101,
		450,
		"Galtun",
		"",
		256,
		143
	},

	{
		"manuk",
		14383,
		101,
		455,
		"Piom",
		"",
		245,
		124
	},

	{
		"manuk",
		14421,
		101,
		460,
		"Manuk Piom",
		"tre1",
		99,
		334
	},

	{
		"manuk",
		14422,
		101,
		455,
		"Manuk Piom",
		"tre2",
		103,
		311
	},

	{
		"manuk",
		14423,
		101,
		454,
		"Manuk Piom",
		"tre4",
		293,
		203
	},

	{
		"manuk",
		14424,
		101,
		449,
		"Manuk Benknee",
		"tre5",
		253,
		173
	},

	{
		"manuk",
		14433,
		101,
		454,
		"Villager",
		"ep13_11",
		278,
		177
	},

	{
		"manuk",
		14434,
		101,
		449,
		"Villager",
		"ep13_12",
		281,
		177
	},

	{
		"manuk",
		14579,
		101,
		450,
		"Manuk Galtun",
		"ep13_2dayq01",
		252,
		116
	},

	{
		"manuk",
		14754,
		101,
		450,
		"���Ա�������",
		"ep133_09",
		321,
		182
	},

	{
		"manuk",
		15759,
		101,
		700,
		"����Ʈ ����",
		"����ũ",
		261,
		206
	},

	{
		"manuk",
		15777,
		101,
		105,
		"�ż� ������",
		"����ũ",
		273,
		206
	},

	{
		"mid_camp",
		10057,
		101,
		109,
		"���������",
		"",
		201,
		237
	},

	{
		"mid_camp",
		10081,
		101,
		105,
		"������������",
		"�̵尡����",
		242,
		243
	},

	{
		"mid_camp",
		14104,
		101,
		707,
		"Rift Guard",
		"",
		213,
		286
	},

	{
		"mid_camp",
		14134,
		101,
		852,
		"Camp Guard",
		"man2",
		13,
		143
	},

	{
		"mid_camp",
		14136,
		101,
		852,
		"Camp Guard",
		"man3",
		9,
		215
	},

	{
		"mid_camp",
		14153,
		101,
		886,
		"Cooking Soldier",
		"ep13bs",
		159,
		282
	},

	{
		"mid_camp",
		14154,
		101,
		937,
		"Sorcerer",
		"ep13bs",
		166,
		248
	},

	{
		"mid_camp",
		14295,
		101,
		712,
		"Henry Clifford",
		"",
		66,
		122
	},

	{
		"mid_camp",
		14296,
		101,
		876,
		"Cat Hand Mining Agent",
		"",
		88,
		100
	},

	{
		"mid_camp",
		14298,
		101,
		1989,
		"Hillsrion",
		"alba01",
		152,
		316
	},

	{
		"mid_camp",
		14299,
		101,
		1986,
		"Tatacho",
		"alba02",
		145,
		313
	},

	{
		"mid_camp",
		14300,
		101,
		1992,
		"Cornus",
		"alba03",
		162,
		306
	},

	{
		"mid_camp",
		14743,
		101,
		930,
		"������� ��",
		"ep133_is01",
		220,
		246
	},

	{
		"mid_camp",
		14744,
		101,
		868,
		"������� ����",
		"ep133_is02",
		223,
		246
	},

	{
		"mid_camp",
		15249,
		101,
		421,
		"������ �����̵��� 4ȣ",
		"",
		207,
		234
	},

	{
		"mid_camp",
		15661,
		102,
		66,
		"Ʈ��������",
		"",
		129,
		284
	},

	{
		"mid_camp",
		15666,
		102,
		49,
		"�ϰŷ���",
		"",
		184,
		263
	},

	{
		"mid_camp",
		15761,
		101,
		700,
		"����Ʈ ����",
		"�̵尡����",
		224,
		237
	},

	{
		"mid_camp",
		15779,
		101,
		105,
		"�ż� ������",
		"�̵尡����",
		242,
		238
	},

	{
		"mid_camp",
		18806,
		101,
		468,
		"Rune Knight Sage Guard",
		"",
		238,
		250
	},

	{
		"mid_camp",
		18807,
		101,
		83,
		"Dispatched Rune Knight",
		"",
		13,
		138
	},

	{
		"mid_campin",
		14119,
		101,
		751,
		"Instructor Igrid",
		"",
		85,
		118
	},

	{
		"mid_campin",
		14145,
		101,
		89,
		"Receptionist Brink",
		"ep13bs",
		106,
		122
	},

	{
		"mid_campin",
		14149,
		101,
		849,
		"Davi",
		"ep13bs",
		292,
		120
	},

	{
		"mid_campin",
		14746,
		101,
		852,
		"����",
		"ep133_is04",
		111,
		120
	},

	{
		"mid_campin",
		14750,
		101,
		997,
		"�Ͽ��",
		"ep133_is06",
		168,
		125
	},

	{
		"mjolnir_01",
		10746,
		101,
		81,
		"Dog",
		"prt",
		312,
		269
	},

	{
		"mjolnir_02",
		15455,
		101,
		116,
		"ī���� ����",
		"",
		82,
		362
	},

	{
		"mjolnir_02",
		19516,
		101,
		837,
		"Bulletin Board",
		"��������",
		76,
		362
	},

	{
		"mjolnir_09",
		19081,
		101,
		123,
		"������ ������ ����",
		"2",
		48,
		246
	},

	{
		"mjolnir_12",
		19518,
		101,
		837,
		"�ָ�",
		"�˵��̱ý�",
		40,
		18
	},

	{
		"moc_fild12",
		18271,
		101,
		59,
		"Serutero",
		"",
		35,
		303
	},

	{
		"moc_fild16",
		11108,
		101,
		55,
		" Uncle Assassin",
		"07rhea_29",
		199,
		212
	},

	{
		"moc_fild16",
		11109,
		101,
		118,
		"Assassin",
		"07rhea_30",
		211,
		254
	},

	{
		"moc_fild16",
		18893,
		101,
		486,
		"Karian",
		"cmd7",
		204,
		231
	},

	{
		"moc_fild19",
		19519,
		101,
		837,
		"Bulletin Board",
		"����ũ��",
		107,
		101
	},

	{
		"moc_fild20",
		14843,
		101,
		876,
		"������",
		"to22",
		368,
		197
	},

	{
		"moc_fild22b",
		14845,
		101,
		495,
		"�����̼� ���",
		"ŸƮ",
		182,
		179
	},

	{
		"moc_para01",
		10087,
		101,
		900,
		"���� ���",
		"rakuen",
		34,
		38
	},

	{
		"moc_para01",
		10113,
		101,
		831,
		"����Ʈ���� �ȳ���",
		"para",
		38,
		19
	},

	{
		"moc_para01",
		14840,
		101,
		496,
		"�����̼� ���",
		"gekk",
		44,
		19
	},

	{
		"moc_para01",
		15786,
		101,
		704,
		"īŻ�α� ������",
		"catal01",
		22,
		16
	},

	{
		"moc_para01",
		19070,
		101,
		564,
		"�ʺ��ڿ� ���Ǳ�",
		"�����ܿ�",
		17,
		37
	},

	{
		"moc_para01",
		19225,
		101,
		899,
		"������ ����",
		"",
		165,
		51
	},

	{
		"moc_para01",
		19557,
		101,
		857,
		"Mission [11 - 25]",
		"Ʃ��",
		36,
		38
	},

	{
		"moc_para01",
		19559,
		101,
		857,
		"Mission [41 - 55]",
		"",
		40,
		38
	},

	{
		"moc_para01",
		19560,
		101,
		952,
		"Secretary Lime Evenor",
		"eden",
		27,
		35
	},

	{
		"moc_para01",
		19623,
		101,
		900,
		"Old Adventurer",
		"eden",
		16,
		22
	},

	{
		"moc_para01",
		19624,
		101,
		886,
		"Eden's chief",
		"eden",
		182,
		48
	},

	{
		"moc_para01",
		19625,
		101,
		883,
		"Eden's Intern",
		"eden",
		172,
		28
	},

	{
		"moc_para01",
		19626,
		101,
		814,
		"Office Assistant Neede",
		"eden",
		20,
		35
	},

	{
		"moc_para01",
		19627,
		101,
		857,
		"Mission [26 - 40]",
		"09tuto_rhea01",
		38,
		38
	},

	{
		"moc_para01",
		19634,
		101,
		857,
		"Request [71 - 85]",
		"",
		44,
		38
	},

	{
		"moc_para01",
		19635,
		101,
		857,
		"Mission [56 - 70]",
		"",
		42,
		38
	},

	{
		"moc_para01",
		19636,
		101,
		469,
		"Instructor Boya",
		"para01",
		25,
		35
	},

	{
		"moc_para01",
		19643,
		101,
		967,
		"Administrator Michael",
		"para09",
		112,
		96
	},

	{
		"moc_para01",
		19644,
		101,
		820,
		"Chef",
		"",
		179,
		44
	},

	{
		"moc_para01",
		19645,
		101,
		468,
		"������ ���� �츣",
		"2nd01",
		23,
		35
	},

	{
		"moc_para01",
		19654,
		101,
		813,
		"�������� �严",
		"2nd10",
		111,
		83
	},

	{
		"moc_para01",
		19655,
		101,
		851,
		"���������� ������",
		"2nd11",
		112,
		79
	},

	{
		"moc_para01",
		19656,
		101,
		857,
		"�Ƿ� [86 - 90]",
		"",
		48,
		175
	},

	{
		"moc_para01",
		19657,
		101,
		857,
		"�Ƿ� [91 - 99]",
		"",
		48,
		177
	},

	{
		"moc_para01",
		19658,
		101,
		629,
		"��ī",
		"1",
		37,
		95
	},

	{
		"moc_para01",
		19659,
		101,
		630,
		"���׸�Ʈ",
		"12",
		41,
		95
	},

	{
		"moc_para01",
		19660,
		101,
		558,
		"�ֹ�",
		"1",
		17,
		95
	},

	{
		"moc_pryd04",
		13710,
		101,
		967,
		"Soldier",
		"07russia_26",
		126,
		120
	},

	{
		"moc_prydb1",
		13191,
		101,
		707,
		"���� ����",
		"sch",
		162,
		119
	},

	{
		"moc_prydb1",
		15349,
		101,
		547,
		"������ ������",
		"nightmare1",
		103,
		54
	},

	{
		"moc_prydb1",
		18369,
		101,
		118,
		"Alcouskou",
		"",
		154,
		128
	},

	{
		"moc_prydb1",
		18497,
		101,
		69,
		"Thief Guide",
		"",
		39,
		129
	},

	{
		"moc_prydb1",
		18498,
		101,
		118,
		"Thief Guildsman",
		"",
		42,
		133
	},

	{
		"moc_prydb1",
		19066,
		101,
		564,
		"�ʺ��ڿ� ���Ǳ�",
		"���Ͽ�",
		38,
		124
	},

	{
		"moc_prydb1",
		19093,
		101,
		638,
		"���",
		"nbprm01",
		50,
		130
	},

	{
		"moc_prydb1",
		19094,
		101,
		810,
		"ī����",
		"nbpr01",
		42,
		120
	},

	{
		"moc_prydb1",
		19095,
		101,
		857,
		"��巿�� �Խ���",
		"nbpr",
		46,
		132
	},

	{
		"moc_prydn1",
		15351,
		101,
		547,
		"������ ������",
		"nightmare1",
		94,
		98
	},

	{
		"moc_ruins",
		11093,
		101,
		99,
		"Young Man",
		"07rhea_14",
		123,
		154
	},

	{
		"moc_ruins",
		11094,
		101,
		61,
		"Grampa",
		"07rhea_15",
		128,
		153
	},

	{
		"moc_ruins",
		11095,
		101,
		85,
		"Wolf Young Man",
		"07rhea_16",
		132,
		144
	},

	{
		"moc_ruins",
		11096,
		101,
		83,
		"Muka Young Man",
		"07rhea_17",
		115,
		144
	},

	{
		"moc_ruins",
		11097,
		101,
		99,
		"Diamond Young Man",
		"07rhea_18",
		109,
		138
	},

	{
		"moc_ruins",
		11099,
		101,
		48,
		"Pale Looking Young Man",
		"07rhea_22",
		94,
		117
	},

	{
		"moc_ruins",
		11100,
		101,
		703,
		"Little Girl",
		"07rhea_31",
		115,
		82
	},

	{
		"moc_ruins",
		11101,
		101,
		706,
		"Little Boy",
		"07rhea_32",
		118,
		82
	},

	{
		"moc_ruins",
		11102,
		101,
		66,
		"Picky Lady",
		"07rhea_23",
		121,
		116
	},

	{
		"moc_ruins",
		11103,
		101,
		47,
		"Ant Man",
		"07rhea_24",
		155,
		107
	},

	{
		"moc_ruins",
		11104,
		101,
		118,
		"Assassin Boy",
		"07rhea_25",
		143,
		43
	},

	{
		"moc_ruins",
		11105,
		101,
		49,
		"Dimitri",
		"07rhea_26",
		173,
		141
	},

	{
		"moc_ruins",
		11106,
		101,
		54,
		"Fly Man",
		"07rhea_27",
		174,
		120
	},

	{
		"moc_ruins",
		11107,
		101,
		48,
		"Uncle Morroc",
		"07rhea_28",
		173,
		70
	},

	{
		"moc_ruins",
		12526,
		101,
		116,
		"ī���� ��ǥ ȫ�����",
		"morocc",
		104,
		133
	},

	{
		"moc_ruins",
		12568,
		101,
		874,
		"���� ��ǥ ȫ�����",
		"morocc",
		97,
		133
	},

	{
		"moc_ruins",
		13396,
		101,
		880,
		"Foreign Merchant",
		"aru1",
		77,
		167
	},

	{
		"moc_ruins",
		13397,
		101,
		929,
		"Foreign Merchant",
		"aru2",
		101,
		133
	},

	{
		"moc_ruins",
		13446,
		101,
		48,
		"Book-Touching Man",
		"garas",
		137,
		70
	},

	{
		"moc_ruins",
		14106,
		101,
		707,
		"Time-Space Gap Guard",
		"",
		137,
		89
	},

	{
		"moc_ruins",
		15453,
		101,
		114,
		"Kafra Employee",
		"",
		59,
		157
	},

	{
		"moc_ruins",
		15521,
		102,
		93,
		"��������",
		"",
		91,
		128
	},

	{
		"moc_ruins",
		15522,
		102,
		99,
		"��������",
		"",
		114,
		63
	},

	{
		"moc_ruins",
		15523,
		102,
		85,
		"����ǰ����",
		"",
		93,
		53
	},

	{
		"moc_ruins",
		15524,
		102,
		85,
		"����ǰ����",
		"",
		81,
		113
	},

	{
		"moc_ruins",
		15525,
		102,
		102,
		"��������",
		"",
		110,
		105
	},

	{
		"moc_ruins",
		15526,
		102,
		99,
		"��������",
		"",
		52,
		85
	},

	{
		"moc_ruins",
		15527,
		102,
		99,
		"����",
		"",
		113,
		126
	},

	{
		"moc_ruins",
		15528,
		102,
		93,
		"����",
		"",
		131,
		138
	},

	{
		"moc_ruins",
		15529,
		102,
		93,
		"����",
		"",
		71,
		139
	},

	{
		"moc_ruins",
		15530,
		102,
		89,
		"����",
		"",
		125,
		135
	},

	{
		"moc_ruins",
		15531,
		102,
		58,
		"�������",
		"",
		87,
		109
	},

	{
		"moc_ruins",
		15532,
		102,
		99,
		"����",
		"",
		90,
		149
	},

	{
		"moc_ruins",
		15533,
		102,
		125,
		"���ֻ̹���",
		"",
		118,
		170
	},

	{
		"moc_ruins",
		15626,
		102,
		86,
		"�丮������",
		"",
		115,
		123
	},

	{
		"moc_ruins",
		15812,
		101,
		707,
		"Guide",
		"01ruins",
		159,
		53
	},

	{
		"moc_ruins",
		15813,
		101,
		707,
		"Guide",
		"02ruins",
		70,
		164
	},

	{
		"moc_ruins",
		15814,
		101,
		707,
		"Guide",
		"03ruins",
		65,
		44
	},

	{
		"moc_ruins",
		17794,
		101,
		728,
		"Maroll Battle Recruiter",
		"",
		75,
		162
	},

	{
		"moc_ruins",
		18101,
		101,
		89,
		"William",
		"",
		113,
		181
	},

	{
		"moc_ruins",
		18107,
		101,
		64,
		"Alchemist",
		"",
		118,
		176
	},

	{
		"moc_ruins",
		18118,
		101,
		92,
		"Smile Assistance",
		"",
		59,
		154
	},

	{
		"moc_ruins",
		18374,
		101,
		88,
		"Roberto",
		"",
		118,
		99
	},

	{
		"moc_ruins",
		18401,
		101,
		50,
		"Jacob",
		"thai",
		105,
		62
	},

	{
		"moc_ruins",
		18405,
		101,
		716,
		"Tommy",
		"thai",
		107,
		62
	},

	{
		"moc_ruins",
		18437,
		101,
		99,
		"Repairman",
		"",
		107,
		94
	},

	{
		"moc_ruins",
		18491,
		101,
		93,
		"�Ƹ�����Ʈ ����",
		"",
		91,
		150
	},

	{
		"moc_ruins",
		18499,
		101,
		83,
		"������ ���",
		"",
		141,
		125
	},

	{
		"moc_ruins",
		18666,
		101,
		118,
		"�ҷ��غ��̴� û��",
		"1",
		87,
		103
	},

	{
		"moc_ruins",
		19096,
		101,
		82,
		"�ɽ��� ����",
		"nbth01",
		85,
		142
	},

	{
		"moc_ruins",
		19230,
		101,
		86,
		"Leablem",
		"",
		154,
		86
	},

	{
		"moc_ruins",
		19482,
		101,
		732,
		"Ibrahim",
		"",
		152,
		147
	},

	{
		"moc_ruins",
		19494,
		101,
		99,
		"Suspicious Man",
		"1",
		90,
		67
	},

	{
		"moc_ruins",
		19495,
		101,
		99,
		"������ ����",
		"2",
		75,
		171
	},

	{
		"moc_ruins",
		19530,
		101,
		837,
		"Bulletin Board",
		"�Ƕ�̵�",
		61,
		164
	},

	{
		"moc_ruins",
		19563,
		101,
		729,
		"Eden Teleport Officer",
		"2",
		68,
		164
	},

	{
		"moc_ruins",
		19629,
		101,
		89,
		"Dieshin Man",
		"09tuto_rhea03",
		173,
		55
	},

	{
		"monk_in",
		18630,
		101,
		60,
		"Sensei Moohae",
		"1",
		99,
		58
	},

	{
		"monk_test",
		18635,
		101,
		753,
		"Bashu",
		"1",
		329,
		61
	},

	{
		"monk_test",
		18638,
		101,
		110,
		"Apprentice Monk",
		"2",
		386,
		388
	},

	{
		"monk_test",
		18648,
		101,
		52,
		"Tomoon",
		"",
		319,
		139
	},

	{
		"monk_test",
		18651,
		101,
		95,
		"Proctor",
		"btl",
		82,
		85
	},

	{
		"monk_test",
		18654,
		101,
		52,
		"Proctor",
		"btl#2",
		88,
		91
	},

	{
		"monk_test",
		18657,
		101,
		79,
		"Proctor",
		"btl#3",
		95,
		85
	},

	{
		"monk_test",
		19201,
		101,
		823,
		"Monk",
		"",
		316,
		69
	},

	{
		"monk_test",
		19675,
		101,
		412,
		"Friar Patrick",
		"edq",
		309,
		146
	},

	{
		"mora",
		10060,
		101,
		109,
		"���������",
		"",
		113,
		112
	},

	{
		"mora",
		14875,
		101,
		516,
		"����â�� ������",
		"ep14_1_bs",
		185,
		163
	},

	{
		"mora",
		14876,
		101,
		513,
		"�е�",
		"ep14_1_bs",
		35,
		119
	},

	{
		"mora",
		14877,
		101,
		518,
		"�����þ�",
		"ep14_1_bs",
		98,
		66
	},

	{
		"mora",
		14878,
		101,
		515,
		"���",
		"ep14_1_bs",
		139,
		102
	},

	{
		"mora",
		14879,
		101,
		495,
		"��׽�",
		"ep14_1_bs",
		55,
		124
	},

	{
		"mora",
		14884,
		101,
		509,
		"�ڳ���",
		"pa0829",
		133,
		80
	},

	{
		"mora",
		14885,
		101,
		509,
		"��í",
		"pa0829",
		115,
		98
	},

	{
		"mora",
		14886,
		101,
		513,
		"��-��",
		"pa0829",
		119,
		103
	},

	{
		"mora",
		14887,
		101,
		516,
		"��ȭ����",
		"pa0829",
		119,
		118
	},

	{
		"mora",
		14888,
		101,
		514,
		"��-����",
		"pa0829",
		124,
		108
	},

	{
		"mora",
		14889,
		101,
		518,
		"����ǰ����",
		"pa0829",
		127,
		112
	},

	{
		"mora",
		14890,
		101,
		515,
		"��ȥ���ε���",
		"pa0829",
		170,
		101
	},

	{
		"mora",
		14891,
		101,
		520,
		"�߳���մ�",
		"pa0829",
		131,
		165
	},

	{
		"mora",
		14892,
		101,
		520,
		"�߳���մ�",
		"pa0829",
		125,
		174
	},

	{
		"mora",
		14893,
		101,
		520,
		"������",
		"pa0829",
		104,
		172
	},

	{
		"mora",
		14894,
		101,
		525,
		"���ױ��� ��θӸ�",
		"mo",
		118,
		166
	},

	{
		"mora",
		14895,
		101,
		524,
		"���ױ��� �θ�",
		"mo",
		116,
		165
	},

	{
		"mora",
		14896,
		101,
		522,
		"���ױ��� ����",
		"mo",
		114,
		163
	},

	{
		"mora",
		14897,
		101,
		523,
		"���ױ��� ����",
		"mo",
		112,
		161
	},

	{
		"mora",
		14909,
		101,
		516,
		"����",
		"p",
		52,
		138
	},

	{
		"mora",
		14910,
		101,
		517,
		"�۳�",
		"p",
		160,
		123
	},

	{
		"mora",
		14911,
		101,
		514,
		"��ǳ����",
		"podo",
		105,
		104
	},

	{
		"mora",
		14912,
		101,
		518,
		"����",
		"p",
		105,
		100
	},

	{
		"mora",
		14914,
		101,
		515,
		"�ٶ�����",
		"podo",
		99,
		100
	},

	{
		"mora",
		14915,
		101,
		516,
		"�������� ���÷�",
		"podo",
		98,
		104
	},

	{
		"mora",
		14916,
		101,
		517,
		"�ȵ��ϴ� ���÷�",
		"podo",
		102,
		107
	},

	{
		"mora",
		14917,
		101,
		518,
		"�ų��� ���÷�",
		"podo",
		101,
		107
	},

	{
		"mora",
		14918,
		101,
		518,
		"��ź�ϴ� ���÷�",
		"podo",
		103,
		100
	},

	{
		"mora",
		14919,
		101,
		515,
		"����ఴ",
		"podo1",
		123,
		94
	},

	{
		"mora",
		14920,
		101,
		513,
		"����ఴ",
		"podo2",
		155,
		72
	},

	{
		"mora",
		14921,
		101,
		516,
		"�ϲ�",
		"mo1",
		184,
		169
	},

	{
		"mora",
		14922,
		101,
		516,
		"ǲ���� �ϲ�",
		"mo",
		179,
		155
	},

	{
		"mora",
		14923,
		101,
		518,
		"��ū���� �ϲ�",
		"mo",
		177,
		157
	},

	{
		"mora",
		14924,
		101,
		516,
		"�ϲ�",
		"mo4",
		108,
		182
	},

	{
		"mora",
		14925,
		101,
		522,
		"���÷� ������",
		"ep14.1_muk",
		31,
		138
	},

	{
		"mora",
		14926,
		101,
		517,
		"���� �ִ� ���÷�",
		"ep14_1",
		122,
		97
	},

	{
		"mora",
		14927,
		101,
		518,
		"â������ ���÷�",
		"ep14_1",
		174,
		171
	},

	{
		"mora",
		14928,
		101,
		516,
		"å���� ���÷�",
		"ep14_1",
		113,
		185
	},

	{
		"mora",
		14929,
		101,
		516,
		"�ٳ��� ���÷�",
		"ep14_1",
		99,
		65
	},

	{
		"mora",
		14930,
		101,
		514,
		"�޽����� ������",
		"ep14_1",
		30,
		128
	},

	{
		"mora",
		14931,
		101,
		513,
		"�����ִ� ������",
		"ep14_1",
		130,
		96
	},

	{
		"mora",
		14932,
		101,
		517,
		"�λ���� ���÷�",
		"ep14_1",
		43,
		113
	},

	{
		"mora",
		14933,
		101,
		513,
		"â������ ���̺���",
		"ep14_1",
		168,
		161
	},

	{
		"mora",
		14934,
		101,
		518,
		"â������ ������Ÿ",
		"ep14_1",
		175,
		161
	},

	{
		"mora",
		14935,
		101,
		517,
		"���÷� ö����",
		"ep14_1",
		140,
		186
	},

	{
		"mora",
		14936,
		101,
		513,
		"�ú� �Ŵ� ������",
		"ep14_1",
		140,
		72
	},

	{
		"mora",
		14940,
		101,
		513,
		"���� �� ������",
		"ep14_1",
		138,
		72
	},

	{
		"mora",
		14944,
		101,
		513,
		"������ ������",
		"ep14_1",
		139,
		73
	},

	{
		"mora",
		14948,
		101,
		521,
		"������",
		"pa",
		117,
		66
	},

	{
		"mora",
		14949,
		101,
		520,
		"������ ģ��",
		"pa",
		115,
		68
	},

	{
		"mora",
		14950,
		101,
		519,
		"��Ʈ",
		"pa",
		65,
		145
	},

	{
		"mora",
		14952,
		101,
		509,
		"����������",
		"pa0829",
		105,
		176
	},

	{
		"mora",
		14953,
		101,
		509,
		"���Ʈ������",
		"pa0829",
		123,
		177
	},

	{
		"mora",
		14954,
		101,
		509,
		"�߹ٸ�����Ʈ�ĵ�",
		"pa0829",
		134,
		166
	},

	{
		"mora",
		14955,
		101,
		518,
		"��� �ֹ�",
		"sleep5",
		132,
		185
	},

	{
		"mora",
		14956,
		101,
		524,
		"��� �ֹ�",
		"sleep2",
		133,
		185
	},

	{
		"mora",
		14957,
		101,
		525,
		"��� �ֹ�",
		"sleep1",
		134,
		185
	},

	{
		"mora",
		14958,
		101,
		522,
		"��� �ֹ�",
		"sleep6",
		132,
		184
	},

	{
		"mora",
		14959,
		101,
		1162,
		"��� �ֹ�",
		"sleep4",
		133,
		184
	},

	{
		"mora",
		14960,
		101,
		516,
		"��� �ֹ�",
		"sleep3",
		134,
		184
	},

	{
		"mora",
		14961,
		101,
		524,
		"��� �ֹ�",
		"sleep7",
		132,
		183
	},

	{
		"mora",
		14962,
		101,
		518,
		"��� �ֹ�",
		"sleep8",
		133,
		183
	},

	{
		"mora",
		14963,
		101,
		522,
		"��� �ֹ�",
		"sleep9",
		134,
		183
	},

	{
		"mora",
		14964,
		101,
		522,
		"���� ����",
		"mora_inn",
		43,
		127
	},

	{
		"mora",
		14966,
		101,
		516,
		"ȭ���� ����",
		"mora",
		106,
		117
	},

	{
		"mora",
		14968,
		101,
		510,
		"����Ⱑ ���� �ư���",
		"ep14_1",
		46,
		152
	},

	{
		"mora",
		14969,
		101,
		512,
		"��ī�ο� ������ û��",
		"ep14_1",
		48,
		152
	},

	{
		"mora",
		15108,
		101,
		553,
		"������",
		"���",
		57,
		150
	},

	{
		"mora",
		15679,
		102,
		518,
		"�� ����",
		"",
		138,
		110
	},

	{
		"mora",
		15680,
		102,
		517,
		"��������",
		"",
		100,
		118
	},

	{
		"mora",
		15755,
		101,
		700,
		"����Ʈ ����",
		"���",
		115,
		118
	},

	{
		"mora",
		15787,
		101,
		515,
		"������ ��ȣ��",
		"pa0829",
		152,
		97
	},

	{
		"mora",
		15788,
		101,
		521,
		"����������",
		"new10",
		148,
		98
	},

	{
		"mora",
		15858,
		101,
		524,
		"���÷� �ȳ���",
		"��",
		115,
		138
	},

	{
		"mora",
		15859,
		101,
		518,
		"���÷� �ȳ���",
		"��",
		72,
		51
	},

	{
		"mora",
		15860,
		101,
		516,
		"���÷� �ȳ���",
		"��",
		25,
		158
	},

	{
		"mora",
		15861,
		101,
		522,
		"���÷� �ȳ���",
		"��",
		167,
		76
	},

	{
		"morocc",
		10037,
		101,
		109,
		"���������",
		"",
		164,
		255
	},

	{
		"morocc",
		10611,
		101,
		97,
		"Cetsu",
		"",
		281,
		178
	},

	{
		"morocc",
		11078,
		101,
		707,
		"Soldier - Morroc",
		"07rhea_01",
		150,
		120
	},

	{
		"morocc",
		11079,
		101,
		707,
		"���� ����",
		"07rhea_02",
		178,
		122
	},

	{
		"morocc",
		11080,
		101,
		707,
		"���� ����",
		"07rhea_03",
		92,
		177
	},

	{
		"morocc",
		11081,
		101,
		707,
		"���� ����",
		"07rhea_04",
		92,
		168
	},

	{
		"morocc",
		11082,
		101,
		707,
		"���� ����",
		"07rhea_05",
		155,
		233
	},

	{
		"morocc",
		11083,
		101,
		707,
		"���� ����",
		"07rhea_06",
		165,
		233
	},

	{
		"morocc",
		11084,
		101,
		707,
		"���� ����",
		"07rhea_07",
		222,
		191
	},

	{
		"morocc",
		11085,
		101,
		707,
		"���� ����",
		"07rhea_08",
		222,
		180
	},

	{
		"morocc",
		11086,
		101,
		745,
		"Volunteer - Morroc",
		"07rhea_09",
		202,
		244
	},

	{
		"morocc",
		11087,
		101,
		748,
		"Volunteer - Morroc",
		"07rhea_10",
		88,
		133
	},

	{
		"morocc",
		11088,
		101,
		730,
		"Volunteer - Morroc",
		"07rhea_11",
		202,
		110
	},

	{
		"morocc",
		11089,
		101,
		727,
		"Volunteer - Morroc",
		"07rhea_12",
		268,
		287
	},

	{
		"morocc",
		11090,
		101,
		79,
		"Volunteer - Morroc",
		"07rhea_15",
		37,
		287
	},

	{
		"morocc",
		11091,
		101,
		741,
		"Volunteer - Morroc",
		"07rhea_20",
		223,
		102
	},

	{
		"morocc",
		11092,
		101,
		726,
		"Volunteer - Morroc",
		"07rhea_21",
		226,
		102
	},

	{
		"morocc",
		11098,
		101,
		89,
		"Young Man",
		"07rhea_19",
		54,
		251
	},

	{
		"morocc",
		13219,
		101,
		51,
		"Thin-Faced Bard",
		"sch",
		297,
		154
	},

	{
		"morocc",
		13220,
		101,
		899,
		"????",
		"sch1",
		294,
		152
	},

	{
		"morocc",
		13221,
		101,
		899,
		"????",
		"sch2",
		293,
		155
	},

	{
		"morocc",
		13222,
		101,
		899,
		"????",
		"sch3",
		298,
		150
	},

	{
		"morocc",
		13525,
		101,
		754,
		"Continental Official",
		"",
		176,
		103
	},

	{
		"morocc",
		13526,
		101,
		752,
		"Chief Balrog",
		"",
		159,
		113
	},

	{
		"morocc",
		13709,
		101,
		48,
		"Morroc Villager",
		"07russia_25",
		165,
		82
	},

	{
		"morocc",
		14159,
		101,
		82,
		"Sharp-Looking Boy",
		"dan_07",
		43,
		108
	},

	{
		"morocc",
		15100,
		101,
		553,
		"������",
		"����",
		168,
		275
	},

	{
		"morocc",
		15422,
		101,
		114,
		"Kafra",
		"",
		160,
		258
	},

	{
		"morocc",
		15428,
		101,
		113,
		"Kafra Employee",
		"",
		156,
		97
	},

	{
		"morocc",
		15703,
		101,
		99,
		"Educated Traveller",
		"",
		273,
		79
	},

	{
		"morocc",
		15742,
		101,
		877,
		"Poison Herb Salesman",
		"",
		190,
		96
	},

	{
		"morocc",
		15808,
		101,
		707,
		"Guide",
		"01morocc",
		153,
		286
	},

	{
		"morocc",
		15809,
		101,
		707,
		"Guide",
		"02morocc",
		154,
		38
	},

	{
		"morocc",
		15810,
		101,
		707,
		"Guide",
		"03morocc",
		296,
		213
	},

	{
		"morocc",
		15811,
		101,
		707,
		"Guide",
		"04morocc",
		28,
		170
	},

	{
		"morocc",
		18289,
		101,
		99,
		"Zaka",
		"",
		201,
		30
	},

	{
		"morocc",
		18407,
		101,
		86,
		"Young Man",
		"magum1",
		248,
		159
	},

	{
		"morocc",
		18449,
		101,
		92,
		"Citizen",
		"",
		289,
		230
	},

	{
		"morocc",
		18468,
		101,
		837,
		"Bulletin Board",
		"���ũ",
		152,
		110
	},

	{
		"morocc",
		18478,
		101,
		741,
		"Bard",
		"3",
		134,
		111
	},

	{
		"morocc",
		18479,
		101,
		703,
		"Little Girl",
		"�丣Ƽ",
		132,
		111
	},

	{
		"morocc",
		18545,
		101,
		725,
		"Wickebine",
		"BLS",
		27,
		112
	},

	{
		"morocc",
		18849,
		101,
		93,
		"�ް�� �ҳ�",
		"sc00",
		156,
		70
	},

	{
		"morocc",
		19474,
		101,
		84,
		"Seiyablem",
		"",
		51,
		41
	},

	{
		"morocc",
		19477,
		101,
		97,
		"Young Man",
		"",
		60,
		42
	},

	{
		"morocc",
		19496,
		101,
		929,
		"Ragged Man",
		"nd",
		143,
		63
	},

	{
		"morocc",
		19497,
		101,
		98,
		"Man",
		"",
		102,
		298
	},

	{
		"morocc",
		19510,
		101,
		779,
		"Rogue Guild Agent",
		"nd4",
		116,
		39
	},

	{
		"morocc",
		19601,
		101,
		729,
		"������ �����̵���",
		"29",
		161,
		97
	},

	{
		"morocc_in",
		10744,
		101,
		702,
		"Historian",
		"prt02",
		45,
		126
	},

	{
		"morocc_in",
		11866,
		101,
		66,
		"Employee",
		"�ޱ�1",
		146,
		179
	},

	{
		"morocc_in",
		13194,
		101,
		748,
		"ġ�Ȱ���",
		"sch",
		114,
		130
	},

	{
		"morocc_in",
		15363,
		101,
		58,
		"Java Dullihan",
		"",
		146,
		99
	},

	{
		"morocc_in",
		15534,
		102,
		58,
		"�������",
		"",
		141,
		67
	},

	{
		"morocc_in",
		15535,
		102,
		58,
		"������",
		"",
		141,
		60
	},

	{
		"morocc_in",
		15619,
		102,
		99,
		"�������",
		"",
		132,
		57
	},

	{
		"morocc_in",
		15739,
		101,
		82,
		"Trainee",
		"2008hat01",
		137,
		102
	},

	{
		"morocc_in",
		15764,
		101,
		826,
		"����Ʈ��",
		"moc",
		64,
		41
	},

	{
		"morocc_in",
		15765,
		101,
		826,
		"�ƿ콺Ʈ��",
		"",
		60,
		38
	},

	{
		"morocc_in",
		18385,
		101,
		99,
		"Abdula",
		"",
		72,
		32
	},

	{
		"morocc_in",
		18386,
		101,
		99,
		"Sade",
		"",
		63,
		32
	},

	{
		"morocc_in",
		18387,
		101,
		99,
		"Aragham",
		"",
		73,
		38
	},

	{
		"morocc_in",
		18494,
		101,
		86,
		"������",
		"",
		140,
		102
	},

	{
		"morocc_in",
		18709,
		101,
		716,
		"Kid",
		"link1",
		174,
		30
	},

	{
		"morocc_in",
		19175,
		101,
		741,
		"Spiteful-Looking Bard",
		"skill_bard02",
		169,
		72
	},

	{
		"morocc_in",
		19181,
		101,
		54,
		"Customer",
		"bard_skill01",
		178,
		73
	},

	{
		"morocc_in",
		19182,
		101,
		50,
		"Customer",
		"bard_skill02",
		175,
		70
	},

	{
		"morocc_in",
		19183,
		101,
		46,
		"Bartender",
		"bard_qskill",
		166,
		76
	},

	{
		"morocc_in",
		19234,
		101,
		810,
		"Rogue",
		"s",
		115,
		154
	},

	{
		"morocc_in",
		19235,
		101,
		118,
		"Young Man",
		"s",
		114,
		162
	},

	{
		"morocc_in",
		19465,
		101,
		735,
		"Old Scholar Tyus",
		"�︮��",
		116,
		101
	},

	{
		"moscovia",
		10051,
		101,
		109,
		"���������",
		"",
		220,
		191
	},

	{
		"moscovia",
		13597,
		101,
		967,
		"Acorn Dealer",
		"mos",
		208,
		182
	},

	{
		"moscovia",
		13605,
		101,
		966,
		"Soldier",
		"mos_so1",
		253,
		166
	},

	{
		"moscovia",
		13612,
		101,
		968,
		"Berbayeff",
		"npc",
		171,
		71
	},

	{
		"moscovia",
		13613,
		101,
		964,
		"Mr. Ibanoff",
		"npc",
		135,
		49
	},

	{
		"moscovia",
		13634,
		101,
		958,
		"Irina",
		"edq",
		211,
		93
	},

	{
		"moscovia",
		13636,
		101,
		958,
		"A Little Girl",
		"mos1",
		252,
		203
	},

	{
		"moscovia",
		13637,
		101,
		968,
		"A Young Man",
		"mos2",
		233,
		204
	},

	{
		"moscovia",
		13638,
		101,
		964,
		"A Middle-Aged Man",
		"mos3",
		219,
		229
	},

	{
		"moscovia",
		13639,
		101,
		962,
		"A Little Boy",
		"mos4",
		255,
		203
	},

	{
		"moscovia",
		13640,
		101,
		959,
		"A Lady",
		"mos5",
		204,
		188
	},

	{
		"moscovia",
		13641,
		101,
		961,
		"A Lady",
		"mos6",
		167,
		97
	},

	{
		"moscovia",
		13642,
		101,
		962,
		"A Little Boy",
		"mos7",
		202,
		102
	},

	{
		"moscovia",
		13643,
		101,
		968,
		"A Young Man",
		"mos8",
		220,
		172
	},

	{
		"moscovia",
		13644,
		101,
		964,
		"A Man",
		"mos9",
		253,
		175
	},

	{
		"moscovia",
		13645,
		101,
		961,
		"A Lady",
		"mos10",
		168,
		135
	},

	{
		"moscovia",
		13646,
		101,
		959,
		"A Lady",
		"mos11",
		192,
		80
	},

	{
		"moscovia",
		13647,
		101,
		967,
		"A Young Man",
		"mos12",
		211,
		215
	},

	{
		"moscovia",
		13648,
		101,
		964,
		"A Man",
		"mos13",
		149,
		112
	},

	{
		"moscovia",
		13649,
		101,
		968,
		"A Young Man",
		"mos14",
		196,
		71
	},

	{
		"moscovia",
		13650,
		101,
		964,
		"A Man",
		"mos15",
		234,
		168
	},

	{
		"moscovia",
		13651,
		101,
		962,
		"A Little Boy",
		"mos16",
		228,
		80
	},

	{
		"moscovia",
		13681,
		101,
		114,
		"Kafra Staff",
		"",
		223,
		191
	},

	{
		"moscovia",
		13684,
		101,
		960,
		"Moscovia P.R. Officer",
		"1",
		166,
		53
	},

	{
		"moscovia",
		13693,
		101,
		63,
		"The Blacksmith",
		"07russia_06",
		178,
		127
	},

	{
		"moscovia",
		13694,
		101,
		712,
		"Vassili Grandpapa",
		"07russia_07",
		206,
		81
	},

	{
		"moscovia",
		13695,
		101,
		960,
		"Ryubaba",
		"07russia_08",
		213,
		216
	},

	{
		"moscovia",
		13702,
		101,
		962,
		"Little Boy",
		"07russia_09",
		223,
		210
	},

	{
		"moscovia",
		13704,
		101,
		961,
		"Worried Mother",
		"07russia_19",
		166,
		145
	},

	{
		"moscovia",
		13723,
		102,
		968,
		"���ϻ���",
		"",
		152,
		71
	},

	{
		"moscovia",
		13724,
		102,
		959,
		"��������",
		"",
		199,
		110
	},

	{
		"moscovia",
		15846,
		101,
		959,
		"���ں�� ���̵�",
		"01moscovia",
		161,
		76
	},

	{
		"moscovia",
		15847,
		101,
		959,
		"Moscovia Guide",
		"02moscovia",
		226,
		191
	},

	{
		"moscovia",
		19595,
		101,
		729,
		"������ �����̵���",
		"26",
		209,
		197
	},

	{
		"mosk_fild02",
		19551,
		101,
		837,
		"�ָ�",
		"���ں��",
		187,
		251
	},

	{
		"mosk_in",
		13606,
		101,
		966,
		"Soldier",
		"mos_so2",
		113,
		124
	},

	{
		"mosk_in",
		13607,
		101,
		966,
		"Soldier",
		"mos_so3",
		118,
		66
	},

	{
		"mosk_in",
		13608,
		101,
		966,
		"Soldier",
		"mos_so4",
		133,
		110
	},

	{
		"mosk_in",
		13609,
		101,
		966,
		"Soldier",
		"mos_so5",
		133,
		73
	},

	{
		"mosk_in",
		13720,
		102,
		968,
		"��������",
		"",
		21,
		254
	},

	{
		"mosk_in",
		13721,
		102,
		961,
		"������",
		"",
		79,
		178
	},

	{
		"mosk_in",
		13722,
		102,
		968,
		"�������",
		"",
		31,
		180
	},

	{
		"nameless_n",
		13441,
		101,
		97,
		"Larjes",
		"��1",
		259,
		218
	},

	{
		"nameless_n",
		19541,
		101,
		837,
		"�ָ�",
		"������",
		259,
		213
	},

	{
		"nif_in",
		11661,
		101,
		738,
		"Deviruchi",
		"��ȥ",
		190,
		112
	},

	{
		"nif_in",
		15583,
		102,
		801,
		"��������",
		"",
		145,
		23
	},

	{
		"nif_in",
		15584,
		102,
		801,
		"��������",
		"",
		37,
		93
	},

	{
		"nif_in",
		15585,
		102,
		801,
		"������",
		"",
		37,
		84
	},

	{
		"niflheim",
		10055,
		101,
		109,
		"���������",
		"",
		206,
		179
	},

	{
		"niflheim",
		11872,
		101,
		796,
		"Egnigem",
		"",
		109,
		254
	},

	{
		"niflheim",
		15475,
		101,
		791,
		"Kafra Employee",
		"",
		202,
		180
	},

	{
		"niflheim",
		15640,
		102,
		83,
		"�丮������",
		"",
		209,
		180
	},

	{
		"odin_tem01",
		12929,
		101,
		709,
		"Boatman",
		"",
		93,
		146
	},

	{
		"odin_tem01",
		19535,
		101,
		837,
		"�ָ�",
		"�������",
		111,
		141
	},

	{
		"p_track01",
		19432,
		101,
		899,
		"Ticket Helper",
		"single",
		73,
		22
	},

	{
		"p_track01",
		19433,
		101,
		845,
		"Medal Distributor",
		"single",
		67,
		45
	},

	{
		"p_track01",
		19434,
		101,
		798,
		"Exit Guide",
		"single",
		76,
		36
	},

	{
		"p_track01",
		19442,
		101,
		845,
		"Game Guide",
		"single",
		39,
		49
	},

	{
		"p_track01",
		19462,
		101,
		853,
		"Drunkard",
		"single",
		27,
		47
	},

	{
		"p_track01",
		19463,
		101,
		107,
		"Blacksmith Guildsman",
		"single",
		69,
		31
	},

	{
		"p_track01",
		19464,
		101,
		881,
		"Absent Minded Man",
		"single",
		45,
		42
	},

	{
		"p_track02",
		19449,
		101,
		899,
		"Ticket Helper",
		"double",
		73,
		22
	},

	{
		"p_track02",
		19450,
		101,
		845,
		"Game Guide",
		"double",
		39,
		49
	},

	{
		"p_track02",
		19451,
		101,
		845,
		"Medal Distributor",
		"medal",
		67,
		45
	},

	{
		"p_track02",
		19452,
		101,
		798,
		"Exit Guide",
		"double",
		76,
		38
	},

	{
		"p_track02",
		19459,
		101,
		755,
		"Eccentric Scholar",
		"double",
		32,
		45
	},

	{
		"p_track02",
		19460,
		101,
		726,
		"Blacksmith Guildsman",
		"double1",
		69,
		31
	},

	{
		"p_track02",
		19461,
		101,
		733,
		"Valiant Knight",
		"double",
		53,
		45
	},

	{
		"pay_arche",
		11234,
		101,
		88,
		"Archer Joe",
		"",
		77,
		131
	},

	{
		"pay_arche",
		15452,
		101,
		117,
		"ī���� ����",
		"",
		55,
		123
	},

	{
		"pay_arche",
		15731,
		101,
		732,
		"Mercenary Manager",
		"Ȱ",
		99,
		167
	},

	{
		"pay_arche",
		15734,
		101,
		879,
		"Mercenary Merchant",
		"Ȱ",
		102,
		167
	},

	{
		"pay_arche",
		15800,
		101,
		708,
		"Guide",
		"05payon",
		86,
		33
	},

	{
		"pay_arche",
		18462,
		101,
		837,
		"�ָ�",
		"�ü�����",
		79,
		31
	},

	{
		"pay_arche",
		19076,
		101,
		881,
		"�ü���",
		"newbe",
		80,
		89
	},

	{
		"pay_arche",
		19529,
		101,
		837,
		"�ָ�",
		"���̿����",
		39,
		134
	},

	{
		"pay_dun03",
		15695,
		101,
		1180,
		"Nine Tails",
		"���찡�鿩�����",
		48,
		84
	},

	{
		"pay_fild01",
		19075,
		101,
		88,
		"�ü���",
		"newbe",
		339,
		349
	},

	{
		"pay_gld",
		17862,
		101,
		722,
		"Bright Arbor",
		"",
		125,
		236
	},

	{
		"pay_gld",
		17863,
		101,
		722,
		"Bright Arbor",
		"",
		110,
		233
	},

	{
		"pay_gld",
		17864,
		101,
		722,
		"Bright Arbor",
		"",
		116,
		233
	},

	{
		"pay_gld",
		17865,
		101,
		722,
		"Bright Arbor",
		"",
		91,
		239
	},

	{
		"pay_gld",
		17866,
		101,
		722,
		"Holy Shadow",
		"",
		321,
		298
	},

	{
		"pay_gld",
		17867,
		101,
		722,
		"Holy Shadow",
		"",
		321,
		289
	},

	{
		"pay_gld",
		17868,
		101,
		722,
		"Holy Shadow",
		"",
		327,
		304
	},

	{
		"pay_gld",
		17869,
		101,
		722,
		"Holy Shadow",
		"",
		333,
		254
	},

	{
		"pay_gld",
		17870,
		101,
		722,
		"Sacred Altar",
		"",
		137,
		160
	},

	{
		"pay_gld",
		17871,
		101,
		722,
		"Sacred Altar",
		"",
		143,
		160
	},

	{
		"pay_gld",
		17872,
		101,
		722,
		"Sacred Altar",
		"",
		133,
		151
	},

	{
		"pay_gld",
		17873,
		101,
		722,
		"Sacred Altar",
		"",
		153,
		166
	},

	{
		"pay_gld",
		17874,
		101,
		722,
		"Bamboo Grove Hill",
		"",
		208,
		268
	},

	{
		"pay_gld",
		17875,
		101,
		722,
		"Bamboo Grove Hill",
		"",
		199,
		268
	},

	{
		"pay_gld",
		17876,
		101,
		722,
		"Bamboo Grove Hill",
		"",
		190,
		277
	},

	{
		"pay_gld",
		17877,
		101,
		722,
		"Bamboo Grove Hill",
		"",
		187,
		294
	},

	{
		"pay_gld",
		18038,
		101,
		549,
		"�����̼ջ�� ��ũ��",
		"",
		203,
		189
	},

	{
		"pay_gld",
		18039,
		101,
		421,
		"����Ʈ ������",
		"pay_f00",
		206,
		189
	},

	{
		"pay_gld",
		18041,
		101,
		857,
		"������Ȳ�Խ���",
		"fund03",
		200,
		189
	},

	{
		"payon",
		10038,
		101,
		109,
		"���������",
		"",
		184,
		102
	},

	{
		"payon",
		10074,
		101,
		105,
		"������������",
		"���̿�",
		166,
		106
	},

	{
		"payon",
		10093,
		101,
		59,
		"������",
		"valen07",
		163,
		96
	},

	{
		"payon",
		10096,
		101,
		89,
		"������ P��",
		"",
		265,
		160
	},

	{
		"payon",
		10104,
		101,
		831,
		"����Ʈ���� �ȳ���",
		"pay",
		180,
		96
	},

	{
		"payon",
		11223,
		101,
		90,
		"Lady",
		"",
		246,
		154
	},

	{
		"payon",
		11224,
		101,
		59,
		"Young Man",
		"",
		134,
		211
	},

	{
		"payon",
		11225,
		101,
		88,
		"û��",
		"",
		176,
		85
	},

	{
		"payon",
		11227,
		101,
		708,
		"Guardsman",
		"",
		158,
		246
	},

	{
		"payon",
		11229,
		101,
		66,
		"Woman",
		"",
		249,
		156
	},

	{
		"payon",
		11230,
		101,
		66,
		"Woman",
		"",
		246,
		158
	},

	{
		"payon",
		11231,
		101,
		120,
		"Drunkard",
		"",
		210,
		110
	},

	{
		"payon",
		11235,
		101,
		98,
		"Monster Scholar",
		"02",
		132,
		235
	},

	{
		"payon",
		11307,
		101,
		754,
		"Jade",
		"",
		173,
		238
	},

	{
		"payon",
		11878,
		101,
		95,
		"Friar",
		"G5",
		79,
		171
	},

	{
		"payon",
		12540,
		101,
		116,
		"Kafra Voting Staff",
		"payon",
		158,
		182
	},

	{
		"payon",
		12582,
		101,
		874,
		"Cool Event Staff",
		"payon",
		153,
		182
	},

	{
		"payon",
		13522,
		101,
		997,
		"Continental Messenger",
		"payon_edq",
		200,
		113
	},

	{
		"payon",
		13719,
		101,
		78,
		"Broom Grandma",
		"07russia_44",
		65,
		119
	},

	{
		"payon",
		15096,
		101,
		553,
		"������",
		"���",
		200,
		106
	},

	{
		"payon",
		15442,
		101,
		113,
		"Kafra Employee",
		"",
		181,
		104
	},

	{
		"payon",
		15446,
		101,
		116,
		"Kafra Employee",
		"",
		175,
		226
	},

	{
		"payon",
		15547,
		102,
		88,
		"��������",
		"",
		159,
		96
	},

	{
		"payon",
		15548,
		102,
		124,
		"���ֻ̹���",
		"",
		177,
		131
	},

	{
		"payon",
		15625,
		102,
		89,
		"�丮������",
		"",
		206,
		119
	},

	{
		"payon",
		15665,
		102,
		66,
		"Ʈ��������",
		"",
		123,
		109
	},

	{
		"payon",
		15701,
		101,
		725,
		"Neko Neko",
		"",
		115,
		131
	},

	{
		"payon",
		15726,
		101,
		97,
		"Chungwolmang",
		"",
		135,
		320
	},

	{
		"payon",
		15772,
		101,
		105,
		"�ż� ������",
		"���̿�",
		166,
		102
	},

	{
		"payon",
		15796,
		101,
		708,
		"�ȳ����",
		"01payon",
		160,
		67
	},

	{
		"payon",
		15797,
		101,
		708,
		"Guide",
		"02payon",
		151,
		182
	},

	{
		"payon",
		15798,
		101,
		708,
		"Guide",
		"03payon",
		221,
		85
	},

	{
		"payon",
		15799,
		101,
		708,
		"Guide",
		"04payon",
		233,
		324
	},

	{
		"payon",
		17800,
		101,
		728,
		"Maroll Battle Recruiter",
		"",
		189,
		105
	},

	{
		"payon",
		17899,
		101,
		722,
		"Bright Arbor",
		"",
		90,
		322
	},

	{
		"payon",
		17900,
		101,
		722,
		"Scarlet Palace",
		"",
		97,
		322
	},

	{
		"payon",
		17901,
		101,
		722,
		"Holy Shadow",
		"",
		113,
		322
	},

	{
		"payon",
		17902,
		101,
		722,
		"Sacred Altar",
		"",
		118,
		322
	},

	{
		"payon",
		17903,
		101,
		722,
		"Bamboo Grove Hill",
		"",
		123,
		322
	},

	{
		"payon",
		17904,
		101,
		722,
		"Holy Shadow",
		"",
		166,
		177
	},

	{
		"payon",
		17905,
		101,
		722,
		"Scarlet Palace",
		"",
		166,
		173
	},

	{
		"payon",
		17906,
		101,
		722,
		"Sacred Altar",
		"",
		166,
		169
	},

	{
		"payon",
		17907,
		101,
		722,
		"Bamboo Grove Hill",
		"",
		166,
		165
	},

	{
		"payon",
		17908,
		101,
		722,
		"Bright Arbor",
		"",
		166,
		161
	},

	{
		"payon",
		18122,
		101,
		92,
		"Smile Assistance",
		"",
		186,
		104
	},

	{
		"payon",
		18388,
		101,
		88,
		"Hakhim",
		"",
		137,
		178
	},

	{
		"payon",
		18389,
		101,
		88,
		"Begnahd",
		"",
		145,
		178
	},

	{
		"payon",
		18390,
		101,
		88,
		"Antonio",
		"",
		144,
		173
	},

	{
		"payon",
		18435,
		101,
		88,
		"Servant",
		"",
		209,
		127
	},

	{
		"payon",
		18438,
		101,
		88,
		"Repairman",
		"",
		143,
		165
	},

	{
		"payon",
		19097,
		101,
		644,
		"�Ƹ�",
		"1",
		245,
		295
	},

	{
		"payon",
		19227,
		101,
		86,
		"Leablem",
		"",
		236,
		199
	},

	{
		"payon",
		19471,
		101,
		84,
		"Seiyablem",
		"",
		140,
		151
	},

	{
		"payon",
		19476,
		101,
		97,
		"Young Man",
		"",
		143,
		143
	},

	{
		"payon",
		19571,
		101,
		729,
		"Eden Teleport Officer",
		"12",
		177,
		111
	},

	{
		"payon_in01",
		11226,
		101,
		90,
		"Waitress",
		"",
		180,
		7
	},

	{
		"payon_in01",
		11232,
		101,
		88,
		"Archer Zakk",
		"",
		66,
		64
	},

	{
		"payon_in01",
		11233,
		101,
		88,
		"Archer Wolt",
		"",
		47,
		59
	},

	{
		"payon_in01",
		11238,
		101,
		53,
		"Inn Employee",
		"",
		132,
		62
	},

	{
		"payon_in01",
		11308,
		101,
		89,
		"Inventor Jaax",
		"",
		5,
		134
	},

	{
		"payon_in01",
		15549,
		102,
		88,
		"��������",
		"",
		5,
		49
	},

	{
		"payon_in01",
		15550,
		102,
		77,
		"�������",
		"",
		15,
		119
	},

	{
		"payon_in01",
		15551,
		102,
		76,
		"������",
		"",
		7,
		119
	},

	{
		"payon_in01",
		15620,
		102,
		703,
		"�������",
		"",
		5,
		129
	},

	{
		"payon_in01",
		15766,
		101,
		826,
		"����Ʈ��",
		"pay",
		18,
		132
	},

	{
		"payon_in01",
		15767,
		101,
		826,
		"�ƿ콺Ʈ��",
		"",
		14,
		125
	},

	{
		"payon_in01",
		18097,
		101,
		103,
		"Granny",
		"",
		99,
		72
	},

	{
		"payon_in01",
		18099,
		101,
		76,
		"Mystic Lady",
		"",
		18,
		10
	},

	{
		"payon_in01",
		18116,
		101,
		89,
		"Young man",
		"",
		56,
		12
	},

	{
		"payon_in01",
		18206,
		101,
		84,
		"PVPNarrator",
		"",
		142,
		50
	},

	{
		"payon_in01",
		18207,
		101,
		83,
		"Gate Keeper",
		"",
		140,
		53
	},

	{
		"payon_in01",
		19069,
		101,
		564,
		"�ʺ��ڿ� ���Ǳ�",
		"�±ǿ�",
		59,
		20
	},

	{
		"payon_in02",
		15552,
		102,
		75,
		"��������",
		"",
		87,
		34
	},

	{
		"payon_in02",
		18105,
		101,
		86,
		"Boy",
		"",
		25,
		71
	},

	{
		"payon_in02",
		19068,
		101,
		564,
		"�ʺ��ڿ� ���Ǳ�",
		"�ü���",
		71,
		75
	},

	{
		"payon_in02",
		19071,
		101,
		634,
		"�ü� ������",
		"archg",
		62,
		67
	},

	{
		"payon_in02",
		19072,
		101,
		727,
		"���� ȫ�����",
		"newbe",
		58,
		73
	},

	{
		"payon_in02",
		19073,
		101,
		486,
		"�ٵ�� ���� ȫ�����",
		"newbe",
		58,
		71
	},

	{
		"payon_in02",
		19074,
		101,
		77,
		"�������� ��",
		"archg",
		71,
		73
	},

	{
		"payon_in03",
		11228,
		101,
		708,
		"Chief Guardsman",
		"",
		96,
		116
	},

	{
		"payon_in03",
		11236,
		101,
		107,
		"Chief",
		"",
		99,
		190
	},

	{
		"payon_in03",
		11237,
		101,
		708,
		"Guard",
		"",
		102,
		185
	},

	{
		"payon_in03",
		15361,
		101,
		86,
		"Marx Hansen",
		"",
		188,
		146
	},

	{
		"payon_in03",
		15706,
		101,
		77,
		"Nanhyang",
		"",
		8,
		193
	},

	{
		"payon_in03",
		15727,
		101,
		88,
		"Han Garam",
		"",
		139,
		124
	},

	{
		"payon_in03",
		18409,
		101,
		704,
		"Fortune Teller",
		"",
		117,
		128
	},

	{
		"payon_in03",
		18410,
		101,
		704,
		"Poring Fortune Teller",
		"",
		75,
		129
	},

	{
		"payon_in03",
		18411,
		101,
		101,
		"Ascetic",
		"",
		118,
		119
	},

	{
		"payon_in03",
		18555,
		101,
		59,
		"Hunter",
		"htnGM",
		131,
		7
	},

	{
		"payon_in03",
		19237,
		101,
		1170,
		"Maid",
		"1",
		81,
		22
	},

	{
		"payon_in03",
		19238,
		101,
		1404,
		"Maid",
		"2",
		79,
		22
	},

	{
		"payon_in03",
		19239,
		101,
		1170,
		"Maid",
		"3",
		81,
		15
	},

	{
		"payon_in03",
		19240,
		101,
		1404,
		"Maid",
		"4",
		79,
		15
	},

	{
		"payon_in03",
		19241,
		101,
		1416,
		"Maid",
		"5",
		8,
		31
	},

	{
		"payon_in03",
		19242,
		101,
		1416,
		"Maid",
		"6",
		13,
		31
	},

	{
		"payon_in03",
		19486,
		101,
		75,
		"Wola",
		"",
		167,
		149
	},

	{
		"prontera",
		10002,
		101,
		124,
		"Hypnotist",
		"2",
		146,
		232
	},

	{
		"prontera",
		10033,
		101,
		109,
		"���������",
		"",
		146,
		93
	},

	{
		"prontera",
		10063,
		101,
		855,
		"�ɺθ���",
		"",
		204,
		53
	},

	{
		"prontera",
		10072,
		101,
		105,
		"������������",
		"",
		163,
		178
	},

	{
		"prontera",
		10086,
		101,
		733,
		"�̻��� �系",
		"2010hat",
		143,
		125
	},

	{
		"prontera",
		10091,
		101,
		96,
		"���ݶ� �ٽôϿ�",
		"07valen",
		120,
		52
	},

	{
		"prontera",
		10094,
		101,
		875,
		"�ɽ��� ��� L��",
		"",
		68,
		332
	},

	{
		"prontera",
		10101,
		101,
		831,
		"����Ʈ���� �ȳ���",
		"prt",
		149,
		63
	},

	{
		"prontera",
		10132,
		102,
		105,
		"��-����",
		"",
		149,
		234
	},

	{
		"prontera",
		10133,
		102,
		105,
		"��-����",
		"rhea01",
		149,
		236
	},

	{
		"prontera",
		10134,
		102,
		105,
		"��-����",
		"rhea02",
		162,
		236
	},

	{
		"prontera",
		10135,
		102,
		105,
		"��-�Ź�",
		"rhea03",
		149,
		239
	},

	{
		"prontera",
		10136,
		102,
		105,
		"��-��ĥ��",
		"rhea04",
		162,
		239
	},

	{
		"prontera",
		10137,
		102,
		105,
		"��-�׼�����",
		"rhea05",
		149,
		242
	},

	{
		"prontera",
		10138,
		102,
		105,
		"����-��հ�/īŸ��",
		"rhea06",
		162,
		242
	},

	{
		"prontera",
		10139,
		102,
		105,
		"����-�б�/����",
		"rhea07",
		149,
		245
	},

	{
		"prontera",
		10140,
		102,
		105,
		"����-â",
		"rhea08",
		162,
		245
	},

	{
		"prontera",
		10141,
		102,
		105,
		"����-Ȱ",
		"rhea09",
		149,
		248
	},

	{
		"prontera",
		10142,
		102,
		105,
		"ȭ��/źȯ",
		"rhea10",
		162,
		248
	},

	{
		"prontera",
		10143,
		102,
		105,
		"����-�Ѽհ�",
		"rhea11",
		149,
		251
	},

	{
		"prontera",
		10144,
		102,
		105,
		"����-�ܰ�",
		"rhea12",
		162,
		251
	},

	{
		"prontera",
		10145,
		102,
		105,
		"����-å/������/��Ŭ",
		"rhea13",
		149,
		254
	},

	{
		"prontera",
		10146,
		102,
		105,
		"����-�Ǳ�/ä��",
		"rhea14",
		162,
		254
	},

	{
		"prontera",
		10147,
		102,
		105,
		"����-����/�ǽ�����",
		"rhea15",
		149,
		257
	},

	{
		"prontera",
		10148,
		102,
		105,
		"ī��-����",
		"rhea16",
		162,
		257
	},

	{
		"prontera",
		10149,
		102,
		105,
		"ī��-����",
		"rhea17",
		149,
		260
	},

	{
		"prontera",
		10150,
		102,
		105,
		"ī��-��ĥ��",
		"rhea18",
		162,
		260
	},

	{
		"prontera",
		10151,
		102,
		105,
		"ī��-����",
		"rhea19",
		149,
		263
	},

	{
		"prontera",
		10152,
		102,
		105,
		"ī��-�Ź�",
		"rhea20",
		162,
		263
	},

	{
		"prontera",
		10153,
		102,
		105,
		"ī��-����",
		"rhea21",
		149,
		266
	},

	{
		"prontera",
		10154,
		102,
		105,
		"ī��-�׼�����",
		"rhea22",
		162,
		266
	},

	{
		"prontera",
		10155,
		102,
		892,
		"3�� �� ����",
		"",
		165,
		89
	},

	{
		"prontera",
		10156,
		102,
		892,
		"3�� ��� ����",
		"",
		165,
		87
	},

	{
		"prontera",
		10157,
		102,
		892,
		"���� ���� 1��",
		"",
		165,
		85
	},

	{
		"prontera",
		10158,
		102,
		892,
		"���� ���� 2��",
		"",
		165,
		83
	},

	{
		"prontera",
		10159,
		102,
		68,
		"3�� ���� ������ ����",
		"",
		165,
		68
	},

	{
		"prontera",
		10160,
		101,
		888,
		"������ ��ü��",
		"sak",
		165,
		75
	},

	{
		"prontera",
		10162,
		101,
		83,
		"���� ȫ�������",
		"ko",
		168,
		126
	},

	{
		"prontera",
		10164,
		102,
		83,
		"���ڹ������",
		"ko",
		170,
		126
	},

	{
		"prontera",
		10165,
		102,
		83,
		"���ڹ�����",
		"ko",
		172,
		126
	},

	{
		"prontera",
		10166,
		102,
		83,
		"���ڱ�Ÿ����",
		"ko",
		174,
		126
	},

	{
		"prontera",
		10588,
		101,
		105,
		"Guard",
		"",
		160,
		330
	},

	{
		"prontera",
		10589,
		101,
		105,
		"Guard",
		"",
		223,
		99
	},

	{
		"prontera",
		10590,
		101,
		105,
		"Guard",
		"",
		229,
		104
	},

	{
		"prontera",
		10591,
		101,
		105,
		"Guard",
		"",
		47,
		339
	},

	{
		"prontera",
		10592,
		101,
		105,
		"����",
		"",
		52,
		344
	},

	{
		"prontera",
		10593,
		101,
		98,
		"Shuger",
		"",
		101,
		288
	},

	{
		"prontera",
		10594,
		101,
		97,
		"Tono",
		"",
		54,
		240
	},

	{
		"prontera",
		10595,
		101,
		91,
		"Merideth",
		"",
		106,
		116
	},

	{
		"prontera",
		10596,
		101,
		102,
		"YuPi",
		"",
		160,
		133
	},

	{
		"prontera",
		10597,
		101,
		700,
		"YuNa",
		"",
		149,
		202
	},

	{
		"prontera",
		10598,
		101,
		48,
		"Strife",
		"",
		216,
		70
	},

	{
		"prontera",
		12505,
		101,
		116,
		"Kafra Voting Staff",
		"pron",
		164,
		125
	},

	{
		"prontera",
		12519,
		101,
		874,
		"Cool Event Staff",
		"pron",
		147,
		125
	},

	{
		"prontera",
		13520,
		101,
		997,
		"Continental Messenger",
		"pron_edq",
		164,
		304
	},

	{
		"prontera",
		15092,
		101,
		553,
		"������",
		"����",
		114,
		77
	},

	{
		"prontera",
		15355,
		101,
		86,
		"Milk Vendor",
		"",
		73,
		140
	},

	{
		"prontera",
		15362,
		101,
		90,
		"Dairenne",
		"",
		78,
		150
	},

	{
		"prontera",
		15366,
		101,
		105,
		"Peco Peco Breeder",
		"",
		55,
		350
	},

	{
		"prontera",
		15369,
		101,
		116,
		"ī���� ����",
		"",
		248,
		42
	},

	{
		"prontera",
		15371,
		101,
		117,
		"Kafra Employee",
		"",
		146,
		89
	},

	{
		"prontera",
		15378,
		101,
		115,
		"Kafra Employee",
		"",
		151,
		29
	},

	{
		"prontera",
		15385,
		101,
		114,
		"Kafra Employee",
		"",
		282,
		200
	},

	{
		"prontera",
		15392,
		101,
		113,
		"Kafra Employee",
		"",
		29,
		207
	},

	{
		"prontera",
		15399,
		101,
		112,
		"Kafra Employee",
		"",
		152,
		326
	},

	{
		"prontera",
		15499,
		102,
		90,
		"��������",
		"",
		73,
		134
	},

	{
		"prontera",
		15500,
		102,
		102,
		"���ϻ���",
		"",
		104,
		49
	},

	{
		"prontera",
		15501,
		102,
		91,
		"��ä����",
		"",
		48,
		58
	},

	{
		"prontera",
		15502,
		102,
		87,
		"�������",
		"",
		64,
		125
	},

	{
		"prontera",
		15503,
		102,
		96,
		"���Ĵ¼ҳ�",
		"",
		58,
		182
	},

	{
		"prontera",
		15504,
		102,
		90,
		"���Ĵ�ó��",
		"",
		113,
		42
	},

	{
		"prontera",
		15505,
		102,
		91,
		"����ǰ����",
		"",
		105,
		87
	},

	{
		"prontera",
		15506,
		102,
		85,
		"��������",
		"",
		248,
		153
	},

	{
		"prontera",
		15507,
		102,
		125,
		"���ֻ̹���",
		"",
		218,
		211
	},

	{
		"prontera",
		15624,
		102,
		700,
		"�丮������",
		"",
		156,
		212
	},

	{
		"prontera",
		15698,
		101,
		744,
		"Nephia",
		"",
		165,
		232
	},

	{
		"prontera",
		15729,
		101,
		105,
		"Mercenary Manager",
		"â",
		41,
		337
	},

	{
		"prontera",
		15732,
		101,
		700,
		"Mercenary Merchant",
		"â",
		30,
		337
	},

	{
		"prontera",
		15745,
		101,
		853,
		"Rune Salesman",
		"",
		168,
		228
	},

	{
		"prontera",
		15769,
		101,
		105,
		"Riding Creature Master",
		"",
		130,
		213
	},

	{
		"prontera",
		15770,
		101,
		105,
		"Peco Peco Remover",
		"",
		125,
		208
	},

	{
		"prontera",
		15789,
		101,
		105,
		"Guide",
		"01prontera",
		154,
		187
	},

	{
		"prontera",
		15790,
		101,
		105,
		"Guide",
		"02prontera",
		282,
		208
	},

	{
		"prontera",
		15791,
		101,
		105,
		"Guide",
		"03prontera",
		29,
		200
	},

	{
		"prontera",
		15792,
		101,
		105,
		"Guide",
		"04prontera",
		160,
		29
	},

	{
		"prontera",
		15793,
		101,
		105,
		"Guide",
		"05prontera",
		151,
		330
	},

	{
		"prontera",
		17792,
		101,
		728,
		"Maroll Battle Recruiter",
		"",
		123,
		83
	},

	{
		"prontera",
		17894,
		101,
		722,
		"Kriemhild",
		"",
		155,
		190
	},

	{
		"prontera",
		17895,
		101,
		722,
		"Swanhild",
		"",
		146,
		194
	},

	{
		"prontera",
		17896,
		101,
		722,
		"Fadhgridh",
		"",
		143,
		203
	},

	{
		"prontera",
		17897,
		101,
		722,
		"Skoegul",
		"",
		167,
		203
	},

	{
		"prontera",
		17898,
		101,
		722,
		"Gondul",
		"",
		165,
		194
	},

	{
		"prontera",
		18117,
		101,
		92,
		"Smile Assistance",
		"",
		157,
		187
	},

	{
		"prontera",
		18459,
		101,
		837,
		"Bulletin Board",
		"����",
		148,
		49
	},

	{
		"prontera",
		18602,
		101,
		105,
		"Peco Peco Breeder",
		"",
		232,
		318
	},

	{
		"prontera",
		18766,
		101,
		83,
		"�����̻��� ī��",
		"airplane",
		178,
		240
	},

	{
		"prontera",
		18767,
		102,
		83,
		"�Ƹ��� ��������",
		"nin",
		178,
		244
	},

	{
		"prontera",
		19195,
		101,
		733,
		"Grand Master",
		"",
		72,
		352
	},

	{
		"prontera",
		19196,
		101,
		734,
		"Knight",
		"",
		78,
		354
	},

	{
		"prontera",
		19197,
		101,
		734,
		"Knight",
		"",
		73,
		357
	},

	{
		"prontera",
		19198,
		101,
		734,
		"Knight",
		"",
		78,
		357
	},

	{
		"prontera",
		19199,
		101,
		733,
		"Knight",
		"",
		66,
		358
	},

	{
		"prontera",
		19226,
		101,
		73,
		"Apprentice Craftsman",
		"",
		165,
		60
	},

	{
		"prontera",
		19229,
		101,
		86,
		"Leablem",
		"",
		244,
		169
	},

	{
		"prontera",
		19561,
		101,
		729,
		"Eden Teleport Officer",
		"1",
		124,
		76
	},

	{
		"prt_are_in",
		12001,
		101,
		732,
		"Arena Point Manager",
		"",
		103,
		11
	},

	{
		"prt_castle",
		18431,
		101,
		878,
		"Charles Orleans",
		"�丮",
		43,
		30
	},

	{
		"prt_castle",
		18432,
		101,
		886,
		"Madeleine Chu",
		"�丮",
		45,
		35
	},

	{
		"prt_castle",
		18433,
		101,
		877,
		"Child with Cat",
		"�丮",
		45,
		28
	},

	{
		"prt_castle",
		18434,
		101,
		725,
		"Wickebine",
		"�丮",
		44,
		30
	},

	{
		"prt_church",
		10605,
		101,
		67,
		"Garnet",
		"",
		103,
		76
	},

	{
		"prt_church",
		10606,
		101,
		120,
		"Henson",
		"",
		103,
		71
	},

	{
		"prt_church",
		10751,
		101,
		60,
		"Father Bamph",
		"",
		185,
		106
	},

	{
		"prt_church",
		10752,
		101,
		60,
		"Father Biscuss",
		"",
		184,
		110
	},

	{
		"prt_church",
		10762,
		101,
		71,
		"Wedding Staff",
		"",
		97,
		100
	},

	{
		"prt_church",
		10774,
		101,
		71,
		"��ȥ �����",
		"",
		20,
		179
	},

	{
		"prt_church",
		10775,
		101,
		71,
		"��ȥ �����",
		"",
		22,
		179
	},

	{
		"prt_church",
		15509,
		102,
		79,
		"����",
		"",
		108,
		124
	},

	{
		"prt_church",
		18564,
		101,
		60,
		"High Bishop",
		"",
		16,
		41
	},

	{
		"prt_church",
		18565,
		101,
		79,
		"Sister Cecilia",
		"",
		27,
		24
	},

	{
		"prt_church",
		18600,
		101,
		745,
		"Crusader",
		"",
		95,
		127
	},

	{
		"prt_church",
		18787,
		101,
		60,
		"Praying Minister",
		"arch",
		103,
		88
	},

	{
		"prt_church",
		19062,
		101,
		641,
		"���� ��� ������",
		"����������",
		186,
		36
	},

	{
		"prt_church",
		19064,
		101,
		564,
		"�ʺ��ڿ� ���Ǳ�",
		"�����",
		187,
		27
	},

	{
		"prt_fild00",
		19080,
		101,
		123,
		"������ ������ ����",
		"1",
		36,
		123
	},

	{
		"prt_fild01",
		19517,
		101,
		837,
		"�ָ�",
		"���й̱ý�",
		139,
		369
	},

	{
		"prt_fild05",
		10586,
		101,
		105,
		"Culvert Guardian",
		"",
		270,
		212
	},

	{
		"prt_fild05",
		15400,
		101,
		114,
		"Kafra Employee",
		"",
		290,
		224
	},

	{
		"prt_fild05",
		15508,
		102,
		83,
		"��������",
		"",
		290,
		221
	},

	{
		"prt_fild05",
		19082,
		101,
		123,
		"������ ������ ����",
		"3",
		285,
		378
	},

	{
		"prt_fild05",
		19083,
		101,
		123,
		"������ ������ ����",
		"4",
		359,
		213
	},

	{
		"prt_fild05",
		19544,
		101,
		837,
		"Bulletin Board",
		"���ϼ���",
		278,
		220
	},

	{
		"prt_fild08",
		19686,
		101,
		909,
		"Poring War Recruiter",
		"wop",
		159,
		371
	},

	{
		"prt_gld",
		17878,
		101,
		722,
		"Swanhild",
		"",
		244,
		126
	},

	{
		"prt_gld",
		17879,
		101,
		722,
		"Swanhild",
		"",
		244,
		128
	},

	{
		"prt_gld",
		17880,
		101,
		722,
		"Swanhild",
		"",
		236,
		126
	},

	{
		"prt_gld",
		17881,
		101,
		722,
		"Swanhild",
		"",
		236,
		128
	},

	{
		"prt_gld",
		17882,
		101,
		722,
		"Fadhgridh",
		"",
		147,
		140
	},

	{
		"prt_gld",
		17883,
		101,
		722,
		"Fadhgridh",
		"",
		147,
		136
	},

	{
		"prt_gld",
		17884,
		101,
		722,
		"Fadhgridh",
		"",
		158,
		140
	},

	{
		"prt_gld",
		17885,
		101,
		722,
		"Fadhgridh",
		"",
		158,
		136
	},

	{
		"prt_gld",
		17886,
		101,
		722,
		"Skoegul",
		"",
		120,
		243
	},

	{
		"prt_gld",
		17887,
		101,
		722,
		"Skoegul",
		"",
		120,
		236
	},

	{
		"prt_gld",
		17888,
		101,
		722,
		"Skoegul",
		"",
		122,
		243
	},

	{
		"prt_gld",
		17889,
		101,
		722,
		"Skoegul",
		"",
		122,
		236
	},

	{
		"prt_gld",
		17890,
		101,
		722,
		"Gondul",
		"",
		199,
		243
	},

	{
		"prt_gld",
		17891,
		101,
		722,
		"Gondul",
		"",
		199,
		236
	},

	{
		"prt_gld",
		17892,
		101,
		722,
		"Gondul",
		"",
		197,
		243
	},

	{
		"prt_gld",
		17893,
		101,
		722,
		"Gondul",
		"",
		197,
		236
	},

	{
		"prt_gld",
		18028,
		101,
		421,
		"����ǥ���",
		"����1",
		164,
		98
	},

	{
		"prt_gld",
		18042,
		101,
		549,
		"�����̼ջ�� �κ�",
		"",
		158,
		96
	},

	{
		"prt_gld",
		18043,
		101,
		421,
		"����Ʈ ������",
		"prt_f00",
		161,
		96
	},

	{
		"prt_gld",
		18045,
		101,
		857,
		"������Ȳ�Խ���",
		"fund01",
		163,
		99
	},

	{
		"prt_in",
		10581,
		101,
		57,
		"Curator of Library",
		"",
		178,
		92
	},

	{
		"prt_in",
		10582,
		101,
		71,
		"Library Girl",
		"",
		175,
		50
	},

	{
		"prt_in",
		10583,
		101,
		53,
		"Inn Employee",
		"",
		244,
		135
	},

	{
		"prt_in",
		10584,
		101,
		53,
		"Inn Employee",
		"",
		61,
		141
	},

	{
		"prt_in",
		10601,
		101,
		61,
		"Bartender",
		"",
		180,
		20
	},

	{
		"prt_in",
		15510,
		102,
		53,
		"��������",
		"",
		126,
		76
	},

	{
		"prt_in",
		15511,
		102,
		54,
		"�������",
		"",
		172,
		130
	},

	{
		"prt_in",
		15512,
		102,
		47,
		"�������",
		"",
		171,
		140
	},

	{
		"prt_in",
		15513,
		102,
		48,
		"������",
		"",
		172,
		132
	},

	{
		"prt_in",
		15618,
		102,
		66,
		"�������",
		"",
		165,
		140
	},

	{
		"prt_in",
		15659,
		102,
		71,
		"ȥ��ǰ����",
		"",
		211,
		169
	},

	{
		"prt_in",
		15662,
		102,
		66,
		"Ʈ��������",
		"",
		109,
		68
	},

	{
		"prt_in",
		15667,
		102,
		49,
		"�ϰŷ���",
		"",
		175,
		137
	},

	{
		"prt_in",
		15748,
		101,
		700,
		"����Ʈ ����",
		"�����׶�",
		131,
		66
	},

	{
		"prt_in",
		18104,
		101,
		53,
		"Teacher",
		"",
		38,
		108
	},

	{
		"prt_in",
		18202,
		101,
		84,
		"PVPNarrator",
		"",
		56,
		140
	},

	{
		"prt_in",
		18203,
		101,
		83,
		"Gate Keeper",
		"",
		52,
		140
	},

	{
		"prt_in",
		18382,
		101,
		84,
		"Dietrich",
		"",
		63,
		69
	},

	{
		"prt_in",
		18383,
		101,
		86,
		"Vurewell",
		"",
		56,
		68
	},

	{
		"prt_in",
		18384,
		101,
		85,
		"Hollgrehenn",
		"",
		63,
		60
	},

	{
		"prt_in",
		18439,
		101,
		86,
		"Repairman",
		"",
		63,
		54
	},

	{
		"prt_in",
		19473,
		101,
		84,
		"Seiyablem",
		"",
		33,
		70
	},

	{
		"prt_in",
		19475,
		101,
		97,
		"Young Man",
		"",
		31,
		57
	},

	{
		"prt_maze02",
		10607,
		101,
		105,
		"Soldier",
		"",
		100,
		69
	},

	{
		"prt_maze02",
		10608,
		101,
		105,
		"Soldier",
		"",
		110,
		69
	},

	{
		"prt_monk",
		15574,
		102,
		726,
		"�������",
		"",
		135,
		263
	},

	{
		"que_bingo",
		12981,
		101,
		47,
		"Arcade Helper",
		"bingo1",
		49,
		31
	},

	{
		"que_bingo",
		12982,
		101,
		66,
		"Arcade Helper",
		"bingo2",
		42,
		31
	},

	{
		"que_bingo",
		12983,
		101,
		712,
		"Arcade Owner",
		"bingo",
		54,
		17
	},

	{
		"que_bingo",
		12985,
		101,
		778,
		"Eukran",
		"bingo",
		53,
		190
	},

	{
		"ra_fild01",
		19533,
		101,
		837,
		"�ָ�",
		"��������",
		228,
		330
	},

	{
		"ra_fild12",
		13016,
		101,
		934,
		"Airship Guide",
		"fild",
		45,
		230
	},

	{
		"ra_in01",
		15648,
		102,
		919,
		"��������",
		"",
		257,
		269
	},

	{
		"ra_in01",
		15649,
		102,
		931,
		"���ϻ���",
		"",
		254,
		300
	},

	{
		"ra_in01",
		15650,
		102,
		931,
		"�������",
		"",
		176,
		389
	},

	{
		"ra_in01",
		15651,
		102,
		919,
		"������",
		"",
		175,
		364
	},

	{
		"ra_in01",
		15663,
		102,
		66,
		"Ʈ��������",
		"",
		263,
		281
	},

	{
		"ra_in01",
		15668,
		102,
		49,
		"�ϰŷ���",
		"",
		257,
		266
	},

	{
		"rachel",
		10040,
		101,
		109,
		"���������",
		"",
		111,
		143
	},

	{
		"rachel",
		10077,
		101,
		105,
		"������������",
		"����",
		106,
		134
	},

	{
		"rachel",
		10116,
		101,
		831,
		"����Ʈ���� �ȳ���",
		"rah",
		134,
		144
	},

	{
		"rachel",
		13004,
		101,
		921,
		"Citizen",
		"1",
		124,
		132
	},

	{
		"rachel",
		13006,
		101,
		914,
		"Girl",
		"1",
		74,
		150
	},

	{
		"rachel",
		13019,
		101,
		51,
		"Bard",
		"aru",
		197,
		137
	},

	{
		"rachel",
		13059,
		101,
		919,
		"Lachellen",
		"",
		73,
		244
	},

	{
		"rachel",
		13060,
		101,
		921,
		"Kid",
		"",
		196,
		77
	},

	{
		"rachel",
		13061,
		101,
		921,
		"Kid",
		"",
		151,
		155
	},

	{
		"rachel",
		13062,
		101,
		918,
		"Grandma",
		"",
		266,
		35
	},

	{
		"rachel",
		15104,
		101,
		553,
		"������",
		"����",
		121,
		126
	},

	{
		"rachel",
		15487,
		101,
		874,
		"Cool Event Corp. Staff",
		"",
		109,
		138
	},

	{
		"rachel",
		15652,
		102,
		919,
		"��ä����",
		"",
		65,
		80
	},

	{
		"rachel",
		15775,
		101,
		105,
		"�ż� ������",
		"����",
		106,
		130
	},

	{
		"rachel",
		15830,
		101,
		934,
		"Rachel Guide",
		"rachel",
		138,
		146
	},

	{
		"rachel",
		17804,
		101,
		728,
		"Maroll Battle Recruiter",
		"",
		149,
		138
	},

	{
		"rachel",
		19575,
		101,
		729,
		"Eden Teleport Officer",
		"16",
		125,
		144
	},

	{
		"spl_fild02",
		15244,
		101,
		421,
		"������ �����̵��� 3ȣ",
		"",
		53,
		242
	},

	{
		"splendide",
		10058,
		101,
		109,
		"���������",
		"",
		201,
		153
	},

	{
		"splendide",
		10080,
		101,
		105,
		"������������",
		"���ö����",
		180,
		174
	},

	{
		"splendide",
		14384,
		101,
		461,
		"Fairy",
		"",
		159,
		164
	},

	{
		"splendide",
		14385,
		101,
		439,
		"Fairy",
		"",
		229,
		54
	},

	{
		"splendide",
		14386,
		101,
		446,
		"Fairy",
		"",
		89,
		235
	},

	{
		"splendide",
		14387,
		101,
		462,
		"Fairy",
		"",
		245,
		243
	},

	{
		"splendide",
		14388,
		101,
		439,
		"Fairy",
		"",
		230,
		142
	},

	{
		"splendide",
		14389,
		101,
		444,
		"Fairy",
		"",
		274,
		203
	},

	{
		"splendide",
		14390,
		101,
		447,
		"Fairy",
		"",
		275,
		141
	},

	{
		"splendide",
		14391,
		101,
		440,
		"Fairy",
		"",
		224,
		230
	},

	{
		"splendide",
		14392,
		101,
		462,
		"Fairy",
		"",
		223,
		36
	},

	{
		"splendide",
		14393,
		101,
		436,
		"Fairy",
		"",
		305,
		129
	},

	{
		"splendide",
		14394,
		101,
		462,
		"Fairy",
		"",
		142,
		315
	},

	{
		"splendide",
		14395,
		101,
		462,
		"Fairy",
		"",
		181,
		107
	},

	{
		"splendide",
		15760,
		101,
		700,
		"����Ʈ ����",
		"���ö����",
		207,
		160
	},

	{
		"splendide",
		15778,
		101,
		105,
		"�ż� ������",
		"���ö����",
		180,
		169
	},

	{
		"tur_dun01",
		10944,
		101,
		709,
		"Sailor",
		"",
		165,
		29
	},

	{
		"turbo_room",
		11982,
		101,
		115,
		"Kafra Staff",
		"",
		130,
		92
	},

	{
		"turbo_room",
		11983,
		102,
		90,
		"�ͺ�Ʈ�� ����",
		"",
		124,
		86
	},

	{
		"turbo_room",
		11984,
		101,
		124,
		"TBT_Guide",
		"��۰��",
		99,
		120
	},

	{
		"turbo_room",
		11985,
		101,
		857,
		"Hall of Honor",
		"",
		102,
		117
	},

	{
		"turbo_room",
		11986,
		101,
		857,
		"Solo Mode",
		"",
		77,
		115
	},

	{
		"turbo_room",
		11987,
		101,
		857,
		"Normal Mode Record",
		"",
		87,
		114
	},

	{
		"turbo_room",
		11988,
		101,
		857,
		"Expert Mode Record",
		"",
		112,
		114
	},

	{
		"turbo_room",
		11989,
		101,
		857,
		"Hall of Honor",
		"",
		97,
		117
	},

	{
		"turbo_room",
		11990,
		101,
		857,
		"Solo Mode",
		"1",
		75,
		95
	},

	{
		"turbo_room",
		11991,
		101,
		857,
		"Normal Mode Records",
		"1",
		67,
		95
	},

	{
		"turbo_room",
		11992,
		101,
		857,
		"Expert Mode Records",
		"1",
		71,
		95
	},

	{
		"turbo_room",
		11993,
		101,
		125,
		"Point Exchange Helper",
		"",
		93,
		117
	},

	{
		"turbo_room",
		11994,
		101,
		833,
		"Point Manager",
		"",
		106,
		117
	},

	{
		"um_in",
		11586,
		101,
		787,
		"Utan villager",
		"",
		158,
		71
	},

	{
		"um_in",
		15581,
		102,
		788,
		"��������",
		"",
		104,
		124
	},

	{
		"um_in",
		15582,
		102,
		789,
		"�������",
		"",
		160,
		125
	},

	{
		"umbala",
		10056,
		101,
		109,
		"���������",
		"",
		93,
		160
	},

	{
		"umbala",
		11566,
		101,
		785,
		"Utan Man",
		"1",
		140,
		157
	},

	{
		"umbala",
		11567,
		101,
		786,
		"Utan Man",
		"2",
		146,
		157
	},

	{
		"umbala",
		11568,
		101,
		787,
		"Utan Kid",
		"2",
		194,
		104
	},

	{
		"umbala",
		11569,
		101,
		781,
		"Utan Kid",
		"3",
		149,
		165
	},

	{
		"umbala",
		11570,
		101,
		789,
		"Utan Man",
		"3",
		193,
		208
	},

	{
		"umbala",
		11571,
		101,
		787,
		"Utan Kid",
		"1",
		59,
		243
	},

	{
		"umbala",
		11572,
		101,
		785,
		"Utan Man",
		"5",
		139,
		205
	},

	{
		"umbala",
		11581,
		101,
		753,
		"Yuwooki",
		"",
		80,
		146
	},

	{
		"umbala",
		11587,
		101,
		781,
		"Utan Kid",
		"",
		70,
		106
	},

	{
		"umbala",
		11588,
		101,
		97,
		"Pasto",
		"",
		177,
		153
	},

	{
		"umbala",
		11589,
		101,
		785,
		"Bertan",
		"",
		92,
		159
	},

	{
		"umbala",
		15473,
		101,
		721,
		"ī���� ����",
		"",
		87,
		160
	},

	{
		"umbala",
		15631,
		102,
		83,
		"�丮������",
		"",
		102,
		154
	},

	{
		"umbala",
		15853,
		101,
		702,
		"Umbala Guide",
		"01umbala",
		128,
		94
	},

	{
		"umbala",
		15854,
		101,
		702,
		"Umbala Guide",
		"02umbala",
		99,
		158
	},

	{
		"umbala",
		18470,
		101,
		837,
		"Bulletin Board",
		"��߶�",
		137,
		94
	},

	{
		"umbala",
		19605,
		101,
		729,
		"������ �����̵���",
		"31",
		105,
		158
	},

	{
		"ve_fild03",
		19534,
		101,
		837,
		"�ָ�",
		"�丣ȭ��",
		172,
		239
	},

	{
		"ve_in",
		13309,
		101,
		946,
		"Prisoner",
		"",
		119,
		386
	},

	{
		"ve_in",
		13310,
		101,
		946,
		"Ward",
		"",
		111,
		379
	},

	{
		"ve_in",
		13311,
		101,
		946,
		"Ward",
		"",
		126,
		378
	},

	{
		"ve_in",
		13312,
		101,
		943,
		"Towner",
		"",
		101,
		314
	},

	{
		"ve_in",
		13313,
		101,
		849,
		"Towner",
		"",
		90,
		298
	},

	{
		"ve_in",
		13314,
		101,
		849,
		"Towner",
		"",
		361,
		243
	},

	{
		"ve_in",
		13315,
		101,
		849,
		"Towner",
		"",
		242,
		124
	},

	{
		"ve_in",
		13316,
		101,
		946,
		"Towner",
		"",
		180,
		232
	},

	{
		"ve_in",
		13317,
		101,
		940,
		"Towner",
		"",
		163,
		212
	},

	{
		"ve_in",
		13318,
		101,
		946,
		"Towner",
		"",
		190,
		215
	},

	{
		"ve_in",
		13319,
		101,
		943,
		"Towner",
		"",
		318,
		121
	},

	{
		"ve_in",
		13320,
		101,
		943,
		"Towner",
		"",
		222,
		125
	},

	{
		"ve_in",
		13321,
		101,
		940,
		"Towner",
		"",
		222,
		122
	},

	{
		"ve_in",
		13322,
		101,
		946,
		"Towner",
		"",
		232,
		135
	},

	{
		"ve_in",
		13323,
		101,
		946,
		"Towner",
		"",
		239,
		135
	},

	{
		"ve_in",
		13324,
		101,
		943,
		"Towner",
		"",
		232,
		124
	},

	{
		"ve_in",
		13325,
		101,
		946,
		"Towner",
		"",
		234,
		105
	},

	{
		"ve_in",
		13375,
		101,
		947,
		"Bartender",
		"ve",
		235,
		135
	},

	{
		"ve_in",
		13376,
		101,
		940,
		"Female Customer",
		"ve1",
		237,
		131
	},

	{
		"ve_in",
		13377,
		101,
		943,
		"Male Customer",
		"ve2",
		239,
		107
	},

	{
		"ve_in",
		13395,
		101,
		709,
		"Inn Master",
		"veinsin",
		157,
		219
	},

	{
		"ve_in",
		15653,
		102,
		931,
		"�������",
		"",
		386,
		245
	},

	{
		"ve_in",
		15654,
		102,
		931,
		"�������",
		"",
		336,
		243
	},

	{
		"ve_in",
		15655,
		102,
		919,
		"������",
		"",
		374,
		230
	},

	{
		"ve_in",
		15656,
		102,
		943,
		"��������",
		"",
		243,
		303
	},

	{
		"ve_in",
		15657,
		102,
		941,
		"���ϻ���",
		"",
		253,
		304
	},

	{
		"ve_in",
		15658,
		102,
		942,
		"��������",
		"",
		252,
		313
	},

	{
		"veins",
		10043,
		101,
		109,
		"���������",
		"",
		210,
		109
	},

	{
		"veins",
		13280,
		101,
		943,
		"Towner",
		"",
		162,
		34
	},

	{
		"veins",
		13281,
		101,
		940,
		"Towner",
		"",
		148,
		41
	},

	{
		"veins",
		13282,
		101,
		943,
		"Towner",
		"",
		137,
		179
	},

	{
		"veins",
		13283,
		101,
		946,
		"Towner",
		"",
		166,
		91
	},

	{
		"veins",
		13284,
		101,
		941,
		"Kid",
		"",
		138,
		71
	},

	{
		"veins",
		13285,
		101,
		944,
		"Kid",
		"",
		253,
		133
	},

	{
		"veins",
		13286,
		101,
		945,
		"Old Man",
		"",
		270,
		164
	},

	{
		"veins",
		13287,
		101,
		946,
		"Towner",
		"",
		310,
		195
	},

	{
		"veins",
		13288,
		101,
		943,
		"Towner",
		"",
		320,
		254
	},

	{
		"veins",
		13289,
		101,
		940,
		"Towner",
		"",
		333,
		318
	},

	{
		"veins",
		13290,
		101,
		945,
		"Towner",
		"",
		218,
		323
	},

	{
		"veins",
		13291,
		101,
		941,
		"Kid",
		"",
		206,
		275
	},

	{
		"veins",
		13292,
		101,
		943,
		"Towner",
		"",
		171,
		256
	},

	{
		"veins",
		13293,
		101,
		943,
		"Towner",
		"",
		197,
		219
	},

	{
		"veins",
		13294,
		101,
		942,
		"Old lady",
		"",
		232,
		169
	},

	{
		"veins",
		13295,
		101,
		945,
		"Old Man",
		"",
		121,
		199
	},

	{
		"veins",
		13296,
		101,
		943,
		"Towner",
		"",
		111,
		50
	},

	{
		"veins",
		13297,
		101,
		940,
		"Towner",
		"",
		112,
		51
	},

	{
		"veins",
		13298,
		101,
		945,
		"Old Man",
		"",
		191,
		134
	},

	{
		"veins",
		13299,
		101,
		942,
		"Old Lady",
		"",
		177,
		147
	},

	{
		"veins",
		13300,
		101,
		944,
		"Kid",
		"",
		223,
		165
	},

	{
		"veins",
		13301,
		101,
		943,
		"Towner",
		"",
		263,
		153
	},

	{
		"veins",
		13302,
		101,
		940,
		"Towner",
		"",
		296,
		184
	},

	{
		"veins",
		13303,
		101,
		944,
		"Kid",
		"",
		291,
		205
	},

	{
		"veins",
		13304,
		101,
		945,
		"Old Man",
		"",
		291,
		259
	},

	{
		"veins",
		13305,
		101,
		942,
		"Old Lady",
		"",
		291,
		284
	},

	{
		"veins",
		13306,
		101,
		944,
		"Kid",
		"",
		248,
		301
	},

	{
		"veins",
		13307,
		101,
		945,
		"Old Man",
		"",
		161,
		63
	},

	{
		"veins",
		13308,
		101,
		946,
		"Towner",
		"",
		157,
		123
	},

	{
		"veins",
		15489,
		101,
		874,
		"Cool Event Corp. Staff",
		"",
		208,
		128
	},

	{
		"veins",
		15757,
		101,
		700,
		"����Ʈ ����",
		"���ν�",
		202,
		128
	},

	{
		"veins",
		15831,
		101,
		934,
		"Veins Guide",
		"veins01",
		210,
		345
	},

	{
		"veins",
		15832,
		101,
		934,
		"Veins Guide",
		"veins02",
		189,
		101
	},

	{
		"veins",
		19581,
		101,
		729,
		"������ �����̵���",
		"19",
		220,
		109
	},

	{
		"xmas",
		15639,
		102,
		83,
		"�丮������",
		"",
		152,
		137
	},

	{
		"xmas",
		15704,
		101,
		793,
		"Pretty Lindsay",
		"",
		183,
		267
	},

	{
		"xmas",
		15705,
		101,
		712,
		"Fuzzy Fuzz",
		"",
		175,
		156
	},

	{
		"xmas",
		15855,
		101,
		717,
		"Lutie Guide",
		"xmas",
		140,
		137
	},

	{
		"xmas",
		18111,
		101,
		704,
		"Vending Machine Man",
		"",
		117,
		295
	},

	{
		"xmas",
		19524,
		101,
		837,
		"Bulletin Board",
		"�峭������",
		147,
		311
	},

	{
		"xmas_fild01",
		18465,
		101,
		837,
		"Bulletin Board",
		"��Ƽ��",
		75,
		80
	},

	{
		"xmas_in",
		15557,
		102,
		83,
		"��������",
		"",
		40,
		38
	},

	{
		"xmas_in",
		15558,
		102,
		49,
		"�������",
		"",
		174,
		98
	},

	{
		"xmas_in",
		15559,
		102,
		101,
		"������",
		"",
		168,
		104
	},

	{
		"xmas_in",
		15560,
		102,
		702,
		"��������",
		"",
		169,
		34
	},

	{
		"xmas_in",
		15710,
		101,
		797,
		"Hat Merchant",
		"",
		35,
		30
	},

	{
		"xmas_in",
		18240,
		101,
		718,
		"Father Christmas",
		"",
		100,
		96
	},

	{
		"y_airport",
		12073,
		101,
		90,
		"Airport Staff",
		"y_airport1a",
		143,
		43
	},

	{
		"y_airport",
		12076,
		101,
		90,
		"Airport Staff",
		"y_airport1b",
		158,
		43
	},

	{
		"y_airport",
		12079,
		101,
		90,
		"Airport Staff",
		"y_airport1c",
		126,
		43
	},

	{
		"y_airport",
		12085,
		101,
		90,
		"Arrival Staff",
		"y_airport2a",
		143,
		49
	},

	{
		"y_airport",
		12087,
		101,
		90,
		"Arrival Staff",
		"y_airport2b",
		126,
		51
	},

	{
		"y_airport",
		12089,
		101,
		90,
		"Arrival Staff",
		"y_airport2c",
		158,
		50
	},

	{
		"y_airport",
		12091,
		101,
		91,
		"Domestic Boarding",
		"y_airport2d",
		145,
		63
	},

	{
		"y_airport",
		12093,
		101,
		91,
		"International Boarding",
		"y_airport2d",
		140,
		63
	},

	{
		"yuno",
		10044,
		101,
		109,
		"���������",
		"",
		149,
		187
	},

	{
		"yuno",
		10076,
		101,
		105,
		"������������",
		"����",
		167,
		187
	},

	{
		"yuno",
		10777,
		101,
		729,
		"Freidrich",
		"",
		184,
		173
	},

	{
		"yuno",
		10781,
		101,
		103,
		"Juno Granny",
		"",
		337,
		227
	},

	{
		"yuno",
		10782,
		101,
		732,
		"Juno Fighter",
		"",
		328,
		239
	},

	{
		"yuno",
		10783,
		101,
		730,
		"Juno Despot",
		"",
		343,
		68
	},

	{
		"yuno",
		10785,
		101,
		123,
		"Juno Sage",
		"",
		165,
		111
	},

	{
		"yuno",
		10788,
		101,
		54,
		"Juno Artisan",
		"",
		157,
		205
	},

	{
		"yuno",
		10789,
		101,
		852,
		"���뺴��",
		"",
		150,
		283
	},

	{
		"yuno",
		10790,
		101,
		852,
		"���뺴��",
		"",
		165,
		283
	},

	{
		"yuno",
		10791,
		101,
		852,
		"���뺴��",
		"",
		227,
		292
	},

	{
		"yuno",
		10792,
		101,
		852,
		"���뺴��",
		"",
		165,
		228
	},

	{
		"yuno",
		10793,
		101,
		852,
		"���뺴��",
		"",
		150,
		228
	},

	{
		"yuno",
		10794,
		101,
		852,
		"���뺴��",
		"",
		334,
		182
	},

	{
		"yuno",
		10795,
		101,
		852,
		"���뺴��",
		"",
		263,
		320
	},

	{
		"yuno",
		12296,
		101,
		91,
		"Airship Staff",
		"yuno01",
		14,
		262
	},

	{
		"yuno",
		12297,
		101,
		91,
		"Airship Staff",
		"yuno02",
		88,
		263
	},

	{
		"yuno",
		12498,
		101,
		861,
		"Kafra Voting Staff",
		"yuno",
		162,
		191
	},

	{
		"yuno",
		12512,
		101,
		874,
		"Cool Event Staff",
		"yuno",
		153,
		191
	},

	{
		"yuno",
		15102,
		101,
		553,
		"������",
		"����",
		165,
		122
	},

	{
		"yuno",
		15465,
		101,
		860,
		"Kafra Employee",
		"",
		327,
		108
	},

	{
		"yuno",
		15467,
		101,
		861,
		"Kafra Employee",
		"",
		277,
		221
	},

	{
		"yuno",
		15469,
		101,
		860,
		"Kafra Employee",
		"",
		152,
		187
	},

	{
		"yuno",
		15571,
		102,
		84,
		"��������",
		"",
		218,
		97
	},

	{
		"yuno",
		15572,
		102,
		83,
		"��������",
		"",
		226,
		107
	},

	{
		"yuno",
		15573,
		102,
		90,
		"��������",
		"",
		163,
		187
	},

	{
		"yuno",
		15632,
		102,
		83,
		"�丮������",
		"",
		130,
		173
	},

	{
		"yuno",
		15702,
		101,
		813,
		"Old Blacksmith",
		"",
		241,
		52
	},

	{
		"yuno",
		15720,
		101,
		851,
		"Kasis",
		"�߱����佺Ʈ",
		222,
		116
	},

	{
		"yuno",
		15774,
		101,
		105,
		"�ż� ������",
		"����",
		171,
		187
	},

	{
		"yuno",
		15833,
		101,
		700,
		"Juno Guide",
		"yuno01",
		59,
		212
	},

	{
		"yuno",
		15834,
		101,
		700,
		"Juno Guide",
		"yuno02",
		153,
		47
	},

	{
		"yuno",
		17952,
		101,
		722,
		"Himinn",
		"",
		109,
		167
	},

	{
		"yuno",
		17953,
		101,
		722,
		"Andlangr",
		"",
		110,
		171
	},

	{
		"yuno",
		17954,
		101,
		722,
		"Viblainn",
		"",
		111,
		175
	},

	{
		"yuno",
		17955,
		101,
		722,
		"Hljod",
		"",
		112,
		179
	},

	{
		"yuno",
		17956,
		101,
		722,
		"Skidbladnir",
		"",
		114,
		183
	},

	{
		"yuno",
		18467,
		101,
		837,
		"�ָ�",
		"����",
		153,
		113
	},

	{
		"yuno",
		19573,
		101,
		729,
		"Eden Teleport Officer",
		"15",
		144,
		189
	},

	{
		"yuno_fild03",
		19515,
		101,
		837,
		"Bulletin Board",
		"��׷ε�",
		37,
		143
	},

	{
		"yuno_fild08",
		10098,
		101,
		831,
		"����Ʈ���� �ȳ���",
		"yn",
		161,
		192
	},

	{
		"yuno_in01",
		15568,
		102,
		49,
		"�������",
		"",
		103,
		35
	},

	{
		"yuno_in01",
		15569,
		102,
		101,
		"������",
		"",
		112,
		26
	},

	{
		"yuno_in01",
		15570,
		102,
		83,
		"��������",
		"",
		25,
		34
	},

	{
		"yuno_in01",
		18391,
		101,
		88,
		"Delight",
		"",
		164,
		27
	},

	{
		"yuno_in01",
		18392,
		101,
		88,
		"Dilemma",
		"",
		171,
		27
	},

	{
		"yuno_in01",
		18393,
		101,
		88,
		"Lambert",
		"",
		171,
		21
	},

	{
		"yuno_in01",
		18440,
		101,
		86,
		"Repairman",
		"",
		175,
		28
	},

	{
		"yuno_in03",
		10907,
		101,
		67,
		"Museum Guide",
		"",
		32,
		15
	},

	{
		"yuno_in03",
		15707,
		101,
		726,
		"Nehris",
		"",
		20,
		18
	},

	{
		"yuno_in03",
		19204,
		102,
		67,
		"��ũ�ѻ���",
		"yuno03",
		176,
		22
	},

	{
		"yuno_in04",
		12785,
		101,
		83,
		"�缭",
		"",
		34,
		67
	}
}