Navi_Scroll = {

	{
		"Dungeon Teleport Scroll",
		19799,
		-1,
		"mag_dun01",
		125,
		71,
		{ 10820, 376 },
		{ 10821, 376 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19800,
		-1,
		"mjo_dun02",
		80,
		297,
		{ 10457, 398 },
		{ 10458, 398 },
		{ 10460, 398 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19801,
		-1,
		"ein_dun01",
		261,
		262,
		{ 12179, 8 },
		{ 12219, 8 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19802,
		-1,
		"pay_dun03",
		155,
		150,
		{ 10408, 12 },
		{ 10409, 12 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19803,
		-1,
		"xmas_dun01",
		133,
		130,
		{ 18228, 158 },
		{ 18229, 158 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19804,
		-1,
		"gl_prison",
		140,
		15,
		{ 18157, 140 },
		{ 18158, 140 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19805,
		-1,
		"lou_dun03",
		165,
		38,
		{ 11639, 4 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19806,
		-1,
		"gon_dun02",
		251,
		263,
		{ 11459, 73 },
		{ 11474, 73 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19807,
		-1,
		"iz_dun02",
		350,
		335,
		{ 10399, 15 },
		{ 10926, 15 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19808,
		-1,
		"tur_dun02",
		165,
		30,
		{ 10897, 246 },
		{ 10898, 246 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19809,
		-1,
		"alde_dun03",
		275,
		180,
		{ 18130, 296 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19810,
		-1,
		"c_tower3",
		34,
		42,
		{ 18128, 266 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19811,
		-1,
		"gl_sew02",
		292,
		295,
		{ 18163, 865 },
		{ 18164, 865 },
		{ 18165, 865 },
		{ 18166, 865 },
		{ 18167, 865 },
		{ 18168, 865 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19812,
		-1,
		"in_sphinx4",
		120,
		120,
		{ 10427, 471 },
		{ 10428, 471 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19813,
		-1,
		"moc_pryd04",
		195,
		4,
		{ 11001, 216 },
		{ 11003, 216 },
		{ 11005, 216 },
		{ 11007, 216 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19814,
		-1,
		"prt_sewb3",
		20,
		175,
		{ 10256, 530 },
		{ 10257, 530 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19815,
		-1,
		"ama_dun01",
		222,
		144,
		{ 11363, 1298 },
		{ 11428, 1298 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19816,
		-1,
		"lhz_dun01",
		19,
		153,
		{ 12606, 309 },
		{ 12607, 309 },
		{ 12608, 309 },
		{ 12672, 309 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19817,
		-1,
		"ayo_dun02",
		70,
		240,
		{ 11922, 367 },
		{ 11923, 367 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19818,
		-1,
		"thor_v02",
		77,
		208,
		{ 13189, 307 },
		{ 13214, 307 },
		{ 13312, 307 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19819,
		-1,
		"ra_fild01",
		237,
		333,
		{ 13049, 302 },
		{ 13105, 302 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19820,
		-1,
		"ve_fild07",
		127,
		131,
		{ 13194, 376 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19821,
		-1,
		"niflheim",
		206,
		179,
		{ 11573, 188 },
		{ 11574, 188 },
		{ 11575, 188 },
		{ 11576, 188 },
		{ 11577, 188 },
		{ 11578, 188 },
		{ 11579, 188 },
		{ 11580, 188 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19822,
		-1,
		"prt_maze02",
		100,
		174,
		{ 10620, 159 },
		{ 10621, 159 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19823,
		-1,
		"jupe_cave",
		36,
		54,
		{ 12719, 8 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19824,
		-1,
		"anthell02",
		36,
		265,
		{ 10415, 7 },
		{ 19740, 7 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19825,
		-1,
		"yuno_fild08",
		70,
		171,
		{ 10833, 241 },
		{ 10834, 241 },
		{ 10835, 241 },
		{ 10836, 241 },
		{ 10837, 241 },
		{ 10838, 241 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19826,
		-1,
		"hu_fild01",
		140,
		160,
		{ 12736, 279 },
		{ 12812, 279 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19827,
		-1,
		"hu_fild05",
		168,
		302,
		{ 12738, 141 },
		{ 12814, 141 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19828,
		-1,
		"ra_temple",
		117,
		173,
		{ 13042, 8 },
		{ 13060, 8 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19829,
		-1,
		"odin_tem02",
		257,
		374,
		{ 12808, 541 },
		{ 12809, 541 },
		{ 12838, 541 },
		{ 12839, 541 },
		{ 0, 0 }
	},

	{
		"NULL",
		0,
		0,
		"NULL",
		0,
		0,
	}
}