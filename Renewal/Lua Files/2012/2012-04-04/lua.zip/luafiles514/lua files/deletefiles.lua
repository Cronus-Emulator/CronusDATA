DELETE_FILES = {

	"System\\SetupInfo.lua",
	"System\\MsgString.lua",
	"System\\CmdInfo.lub"
}