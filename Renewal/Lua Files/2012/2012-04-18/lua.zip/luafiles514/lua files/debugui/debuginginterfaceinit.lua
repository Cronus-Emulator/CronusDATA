--Function #0
DebugingInterface_UserDefine = function()

end