NpcLocationRadius = {

	[jobtbl.JT_GIOIA] = 1,
	[jobtbl.JT_DAEHYON] = 1,
	[jobtbl.JT_KADES] = 1,
	[jobtbl.JT_E_VADON_X] = 2,
	[jobtbl.JT_E_VADON_X_H] = 2,
	[jobtbl.JT_E_RSX_0805] = 2
}