Navi_Scroll = {

	{
		"Dungeon Teleport Scroll",
		19711,
		-1,
		"mag_dun01",
		125,
		71,
		{ 10869, 376 },
		{ 10870, 376 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19712,
		-1,
		"mjo_dun02",
		80,
		297,
		{ 10506, 398 },
		{ 10507, 398 },
		{ 10509, 398 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19713,
		-1,
		"ein_dun01",
		261,
		262,
		{ 12232, 8 },
		{ 12272, 8 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19714,
		-1,
		"pay_dun03",
		155,
		150,
		{ 10457, 12 },
		{ 10458, 12 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19715,
		-1,
		"xmas_dun01",
		133,
		130,
		{ 18288, 158 },
		{ 18289, 158 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19716,
		-1,
		"gl_prison",
		140,
		15,
		{ 18217, 140 },
		{ 18218, 140 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19717,
		-1,
		"lou_dun03",
		165,
		38,
		{ 11690, 4 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19718,
		-1,
		"gon_dun02",
		251,
		263,
		{ 11510, 73 },
		{ 11525, 73 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19719,
		-1,
		"iz_dun02",
		350,
		335,
		{ 10448, 15 },
		{ 10977, 15 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19720,
		-1,
		"tur_dun02",
		165,
		30,
		{ 10946, 246 },
		{ 10947, 246 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19721,
		-1,
		"alde_dun03",
		275,
		180,
		{ 18190, 296 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19722,
		-1,
		"c_tower3",
		34,
		42,
		{ 18188, 266 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19723,
		-1,
		"gl_sew02",
		292,
		295,
		{ 18223, 865 },
		{ 18224, 865 },
		{ 18225, 865 },
		{ 18226, 865 },
		{ 18227, 865 },
		{ 18228, 865 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19724,
		-1,
		"in_sphinx4",
		120,
		120,
		{ 10476, 471 },
		{ 10477, 471 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19725,
		-1,
		"moc_pryd04",
		195,
		4,
		{ 11052, 216 },
		{ 11054, 216 },
		{ 11056, 216 },
		{ 11058, 216 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19726,
		-1,
		"prt_sewb3",
		20,
		175,
		{ 10305, 530 },
		{ 10306, 530 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19727,
		-1,
		"ama_dun01",
		222,
		144,
		{ 11414, 1298 },
		{ 11479, 1298 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19728,
		-1,
		"lhz_dun01",
		19,
		153,
		{ 12659, 309 },
		{ 12660, 309 },
		{ 12661, 309 },
		{ 12725, 309 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll",
		19729,
		-1,
		"ayo_dun02",
		70,
		240,
		{ 11973, 367 },
		{ 11974, 367 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19730,
		-1,
		"thor_v02",
		77,
		208,
		{ 13242, 307 },
		{ 13267, 307 },
		{ 13365, 307 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19731,
		-1,
		"ra_fild01",
		237,
		333,
		{ 13102, 302 },
		{ 13158, 302 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19732,
		-1,
		"ve_fild07",
		127,
		131,
		{ 13247, 376 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19733,
		-1,
		"niflheim",
		206,
		179,
		{ 11624, 188 },
		{ 11625, 188 },
		{ 11626, 188 },
		{ 11627, 188 },
		{ 11628, 188 },
		{ 11629, 188 },
		{ 11630, 188 },
		{ 11631, 188 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19734,
		-1,
		"prt_maze02",
		100,
		174,
		{ 10669, 159 },
		{ 10670, 159 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19735,
		-1,
		"jupe_cave",
		36,
		54,
		{ 12772, 8 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19736,
		-1,
		"anthell02",
		36,
		265,
		{ 10464, 7 },
		{ 19652, 7 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19737,
		-1,
		"yuno_fild08",
		70,
		171,
		{ 10882, 241 },
		{ 10883, 241 },
		{ 10884, 241 },
		{ 10885, 241 },
		{ 10886, 241 },
		{ 10887, 241 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19738,
		-1,
		"hu_fild01",
		140,
		160,
		{ 12789, 279 },
		{ 12865, 279 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19739,
		-1,
		"hu_fild05",
		168,
		302,
		{ 12791, 141 },
		{ 12867, 141 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19740,
		-1,
		"ra_temple",
		117,
		173,
		{ 13095, 8 },
		{ 13113, 8 },
		{ 0, 0 }
	},

	{
		"Dungeon Teleport Scroll II",
		19741,
		-1,
		"odin_tem02",
		257,
		374,
		{ 12861, 541 },
		{ 12862, 541 },
		{ 12891, 541 },
		{ 12892, 541 },
		{ 0, 0 }
	},

	{
		"NULL",
		0,
		0,
		"NULL",
		0,
		0
	},
}